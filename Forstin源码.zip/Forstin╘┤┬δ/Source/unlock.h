#pragma once
#include"stdafx.h"

namespace UNL
{
	void Unlock_all_arena_war_awards_and_toys();
	void Summer_2020_awards();
	void Unlock_the_awards();
	void Unlock_arcade_trophies_and_toys();
	void Unlock_nightclub_awards();
	void Vanilla_Unicorn_Award();
	void The_flight_school_is_all_cleared();
	void Clear_mind();
	void Clear_report();
	void Unlock_Lots_of_Hats_And_Shirts();
	void Cayo_Perico_Heist();
	void Diamond_Casino_Heist();
	void Doomsday_Heist();
	void Classic_Heist();
	void The_Contract_Agency();
	void Cayo_Perico_Unlockables();
	void Unlock_All_Contacts();
	void Skip_Lamar_Missions_To_The_Last_One();
	void Unlock_Christmas_Content();
}