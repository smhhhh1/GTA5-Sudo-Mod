#pragma once 


namespace Local
{
	void UpdateLoop();
}