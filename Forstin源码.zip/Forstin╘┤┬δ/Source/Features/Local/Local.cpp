#pragma once
#include "../../stdafx.h"

bool FreeCamFeaturedUsed = false;
Cam FreeCamHandle;
int TimePD = 0;
void Local::UpdateLoop()
{
	if (g_Local.GodMode)
	{
		Memory::set_value<bool>({ 0x08 , 0x189 }, 1);
	}
	else { Memory::set_value<bool>({ 0x08 , 0x189 }, 0); }
	if (g_Local.zhengfa)
	{
		globalHandle(2657589 + 1 + PLAYER::PLAYER_ID() * 466 + 213).As<int>() = 1;
		globalHandle(2672505).At(58).As<int>() = NETWORK::GET_NETWORK_TIME() + 10;
	}
	else
	{
		globalHandle(2657589 + 1 + PLAYER::PLAYER_ID() * 466 + 213).As<int>() = 0;
		globalHandle(2672505).At(58).As<int>() = 0;
	}
	if (g_Local.freecambool)
	{
		Memory::set_value<float>({ 0x8,0x30,0x10,0x20,0x70,0x0,0x2C }, -1);
	}
	if (g_Local.FreeCam)
	{
		Vector3 rot = CAM::GET_GAMEPLAY_CAM_ROT(0);
		Vector3 coord = CAM::GET_GAMEPLAY_CAM_COORD();
		Vector3 p_coord = { 0, 0, 0 };

		if (CAM::GET_FOLLOW_PED_CAM_VIEW_MODE() == PedCamViewModes::FirstPerson)
		{
			CAM::SET_FOLLOW_PED_CAM_VIEW_MODE(PedCamViewModes::ThirdPersonMedium);
		}
		FreeCamFeaturedUsed = true;
		if (!CAM::DOES_CAM_EXIST(FreeCamHandle))
		{
			FreeCamHandle = CAM::CREATE_CAM("DEFAULT_SCRIPTED_CAMERA", true);
			CAM::SET_CAM_ROT(FreeCamHandle, rot.x, rot.y, rot.z, 0);
			CAM::SET_CAM_COORD(FreeCamHandle, coord.x, coord.y, coord.z);
		}

		CAM::RENDER_SCRIPT_CAMS(true, true, 700, true, true, false);
		CAM::SET_CAM_ACTIVE(FreeCamHandle, 1);
		CAM::SET_CAM_ROT(FreeCamHandle, rot.x, rot.y, rot.z, 0);

		p_coord = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);

		ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), p_coord.x, p_coord.y, p_coord.z, 0, 0, 0);
		PLAYER::DISABLE_PLAYER_FIRING(PLAYER::PLAYER_PED_ID(), true);
		HUD::HIDE_HUD_AND_RADAR_THIS_FRAME();

		float speed = .5f;
		if (PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_SPRINT))
		{
			speed += .3f;
		}

		if (PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_MOVE_UD))
		{
			speed /= -1;
			Vector3 c = MenuFunctions::AddTwoVectors(&CAM::GET_CAM_COORD(FreeCamHandle), &MenuFunctions::MultiplyVector(&MenuFunctions::RotationToDirection(&rot), speed));
			CAM::SET_CAM_COORD(FreeCamHandle, c.x, c.y, c.z);
		}

		if (PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_MOVE_UP_ONLY))
		{
			Vector3 c = MenuFunctions::AddTwoVectors(&CAM::GET_CAM_COORD(FreeCamHandle), &MenuFunctions::MultiplyVector(&MenuFunctions::RotationToDirection(&rot), speed));
			CAM::SET_CAM_COORD(FreeCamHandle, c.x, c.y, c.z);
		}
	}
	else
	{
		if (FreeCamFeaturedUsed)
		{
			FreeCamFeaturedUsed = false;
			CAM::RENDER_SCRIPT_CAMS(false, true, 10, false, false, false);
			CAM::SET_CAM_ACTIVE(FreeCamHandle, false);
			CAM::DESTROY_CAM(FreeCamHandle, true);
		}
	}
	if (g_Local.noclipv1)
	{
		Ped playerPed = PLAYER::PLAYER_PED_ID();
		Vector3 pos = ENTITY::GET_ENTITY_COORDS(playerPed, false);
		ENTITY::SET_ENTITY_COORDS_NO_OFFSET(playerPed, pos.x, pos.y, pos.z, false, false, false);
		if (GetAsyncKeyState(0x57) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 268)) { //w
			float fivef = 0.5f;
			float heading = ENTITY::GET_ENTITY_HEADING(playerPed);
			float xVec = fivef * sin((heading)) * -1.0f;
			float yVec = fivef * cos((heading));

			ENTITY::GET_ENTITY_HEADING(playerPed);
			pos.x -= xVec, pos.y -= yVec;
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(playerPed, pos.x, pos.y, pos.z, false, false, false);
		}
		if (GetAsyncKeyState(0x53) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 269)) {  //s
			float fivef = 0.5f;
			float heading = ENTITY::GET_ENTITY_HEADING(playerPed);
			float xVec = fivef * sin(MenuFunctions::degToRad(heading)) * -1.0f;
			float yVec = fivef * cos(MenuFunctions::degToRad(heading));
			ENTITY::SET_ENTITY_HEADING(playerPed, heading);

			pos.x += xVec, pos.y += yVec;
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(playerPed, pos.x, pos.y, pos.z, false, false, false);
		}
		if (GetAsyncKeyState(0x41) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 266)) {
			float fivef = 0.5f;
			float heading = ENTITY::GET_ENTITY_HEADING(playerPed);

			ENTITY::SET_ENTITY_HEADING(playerPed, heading + 1.0f);
		}
		if (GetAsyncKeyState(0x44) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 271)) {
			float fivef = 0.5f;
			float heading = ENTITY::GET_ENTITY_HEADING(playerPed);

			ENTITY::SET_ENTITY_HEADING(playerPed, heading - 1.0f);
		}
		if (GetAsyncKeyState(VK_SHIFT) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 206)) {
			float heading = ENTITY::GET_ENTITY_HEADING(playerPed);
			ENTITY::SET_ENTITY_HEADING(playerPed, heading);

			pos.z -= 0.1;
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(playerPed, pos.x, pos.y, pos.z, false, false, false);
		}
		if (GetAsyncKeyState(VK_SPACE) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 205)) {
			float heading = ENTITY::GET_ENTITY_HEADING(playerPed);
			ENTITY::SET_ENTITY_HEADING(playerPed, heading);

			pos.z += 0.1;
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(playerPed, pos.x, pos.y, pos.z, false, false, false);
		}
	}
	if (g_Local.noclipv2)
	{

		static const int controls[] = { 21, 32, 33, 34, 35, 36 };
		static float speed = 20.f;
		static float mult = 0.f;

		static bool bLastNoclip = false;

		static Entity prev = -1;
		static Vector3 rot{};


		bool bNoclip = g_Local.noclipv2;

		Entity ent = PLAYER::PLAYER_PED_ID();
		bool bInVehicle = PED::IS_PED_IN_ANY_VEHICLE(ent, true);
		if (bInVehicle) ent = PED::GET_VEHICLE_PED_IS_IN(ent, false);

		// cleanup when changing entities
		if (prev != ent)
		{
			ENTITY::FREEZE_ENTITY_POSITION(prev, false);
			ENTITY::SET_ENTITY_COLLISION(prev, true, true);

			prev = ent;
		}

		if (bNoclip)
		{
			for (int control : controls)
				PAD::DISABLE_CONTROL_ACTION(0, control, true);

			Vector3 vel = { 0.f, 0.f, 0.f };
			float heading = 0.f;

			// Left Shift
			if (GetAsyncKeyState(VK_SPACE))
				vel.z += speed / 2;
			// Left Control
			if (GetAsyncKeyState(VK_SHIFT))
				vel.z -= speed / 2;
			// Forward
			if (PAD::IS_DISABLED_CONTROL_PRESSED(0, 32))
				vel.y += speed;
			// Backward
			if (PAD::IS_DISABLED_CONTROL_PRESSED(0, 33))
				vel.y -= speed;
			// Left
			if (PAD::IS_DISABLED_CONTROL_PRESSED(0, 34))
				vel.x -= speed;
			// Right
			if (PAD::IS_DISABLED_CONTROL_PRESSED(0, 35))
				vel.x += speed;

			rot = CAM::GET_GAMEPLAY_CAM_ROT(2);
			ENTITY::SET_ENTITY_ROTATION(ent, 0.f, rot.y, rot.z, 2, 0);
			ENTITY::SET_ENTITY_COLLISION(ent, false, false);
			if (vel.x == 0.f && vel.y == 0.f && vel.z == 0.f)
			{
				// freeze entity to prevent drifting when standing still
				ENTITY::FREEZE_ENTITY_POSITION(ent, true);

				mult = 0.f;
			}
			else
			{
				if (mult < 20.f)
					mult += 0.15f;

				ENTITY::FREEZE_ENTITY_POSITION(ent, false);
				Vector3 pos = (ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), 1));
				Vector3 offset = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(ent, vel.x, vel.y, 0.f);
				vel.x = offset.x - pos.x;
				vel.y = offset.y - pos.y;

				ENTITY::SET_ENTITY_VELOCITY(ent, vel.x * mult, vel.y * mult, vel.z * mult);
			}
		}
		else if (bNoclip != bLastNoclip)
		{

			MenuFunctions::requestControlOfEnt(PLAYER::PLAYER_PED_ID());
			ENTITY::FREEZE_ENTITY_POSITION(ent, false);
			ENTITY::SET_ENTITY_COLLISION(ent, true, false);

		}

		bLastNoclip = bNoclip;


	}
	else
	{
		ENTITY::FREEZE_ENTITY_POSITION(PLAYER::PLAYER_PED_ID(), false);
		ENTITY::SET_ENTITY_COLLISION(PLAYER::PLAYER_PED_ID(), true, false);
		ENTITY::FREEZE_ENTITY_POSITION(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), true), false);
		ENTITY::SET_ENTITY_COLLISION(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), true), true, false);
	}
	if (g_Local.noragdoll)
	{
		PED::SET_PED_CAN_RAGDOLL(PLAYER::PLAYER_PED_ID(), false);
		PED::SET_PED_CAN_RAGDOLL_FROM_PLAYER_IMPACT(PLAYER::PLAYER_PED_ID(), false);
		PED::SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE(PLAYER::PLAYER_PED_ID(), false);
		PLAYER::GIVE_PLAYER_RAGDOLL_CONTROL(PLAYER::PLAYER_ID(), false);
		PED::SET_PED_RAGDOLL_ON_COLLISION(PLAYER::PLAYER_PED_ID(), false);
	}
	if (g_Local.pengci) {
		PED::SET_PED_CAN_RAGDOLL(PLAYER::PLAYER_PED_ID(), true);
		PED::SET_PED_CAN_RAGDOLL_FROM_PLAYER_IMPACT(PLAYER::PLAYER_PED_ID(), true);
		PED::SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE(PLAYER::PLAYER_PED_ID(), true);
		PLAYER::GIVE_PLAYER_RAGDOLL_CONTROL(PLAYER::PLAYER_ID(), true);
		PED::SET_PED_RAGDOLL_ON_COLLISION(PLAYER::PLAYER_PED_ID(), true);
	}
	if (g_Local.zhuanquan && !PED::IS_PED_IN_ANY_VEHICLE(PLAYER::PLAYER_PED_ID(), false))
	{
		ENTITY::SET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID(), ENTITY::_GET_ENTITY_PHYSICS_HEADING(PLAYER::PLAYER_PED_ID()) + 5);
	}
	if (g_Local.superjump)
	{
		MISC::SET_SUPER_JUMP_THIS_FRAME(PLAYER::PLAYER_PED_ID());
		MISC::SET_SUPER_JUMP_THIS_FRAME(PLAYER::PLAYER_ID());
	}
	if (g_Local.firebreath)
	{
		float XPos = 0.02, YPos = 0.2, ZPos = 0.0, XOff = 90.0, YOff = -100.0, ZOff = 90.0;

		STREAMING::REQUEST_NAMED_PTFX_ASSET("core");
		GRAPHICS::USE_PARTICLE_FX_ASSET("core");
		if ((timeGetTime() - TimePD) > 200)
		{
			int ptfx = GRAPHICS::START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("ent_sht_flame", PLAYER::PLAYER_PED_ID(), XPos, YPos, ZPos,
				XOff, YOff, ZOff, SKEL_Head, 1, 1, 1, 1);
			TimePD = timeGetTime();
		}
		STREAMING::REMOVE_PTFX_ASSET();
	}
	g_Local.neverwanted ? PLAYER::CLEAR_PLAYER_WANTED_LEVEL(PLAYER::PLAYER_ID()) : NULL;
	if (g_Local.JibBool)
	{
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");// FX Attachment
		GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry2");
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_clown_appears", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 28422, 0.2f, 0, 0, 0);
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");// FX Attachment
		GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry2");
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_clown_appears", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 60309, 0.2f, 0, 0, 0);
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");// FX Attachment
		GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry2");
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_clown_appears", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 31086, 0.3f, 0, 0, 0);
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");// FX Attachment
		GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry2");
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_clown_appears", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 52301, 0.2f, 0, 0, 0);
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");// FX Attachment
		GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry2");
	}
	if (g_Local.JiBool)
	{
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");// FX Attachment
		GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry2");
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("muz_clown", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 28422, 0.3f, 0, 0, 0);
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");// FX Attachment
		GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry2");
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("muz_clown", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 60309, 0.3f, 0, 0, 0);
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");// FX Attachment
		GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry2");
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("muz_clown", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 31086, 0.4f, 0, 0, 0);
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");// FX Attachment
		GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry2");
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("muz_clown", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 52301, 0.3f, 0, 0, 0);
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");// FX Attachment
		GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("muz_clown");
	}
	if (g_Local.gglow)
	{
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry1");// FX Attachment
		GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry1");
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_alien_teleport", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 28422, 0.1f, 0, 0, 0);
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry1");// FX Attachment
		GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry1");
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_alien_teleport", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 60309, 0.1f, 0, 0, 0);
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry1");// FX Attachment
		GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry1");
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_alien_teleport", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 31086, 0.2f, 0, 0, 0);
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry1");// FX Attachment
		GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry1");
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_alien_teleport", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 52301, 0.1f, 0, 0, 0);
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry1");// FX Attachment
		GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry1");
	}
	if (g_Local.chixuranshao)
	{
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_agencyheist");// FX Attachment
		GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_agencyheist");
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_fbi_dd_breach_smoke", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 0, 0.5f, 0, 0, 0);
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_agencyheist");// FX Attachment
		GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_agencyheist");
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_fbi_dd_breach_smoke", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 28422, 0.1f, 0, 0, 0);
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_agencyheist");// FX Attachment
		GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_agencyheist");
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_fbi_dd_breach_smoke", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 60309, 0.1f, 0, 0, 0);
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_agencyheist");// FX Attachment
		GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_agencyheist");
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_fbi_dd_breach_smoke", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 31086, 0.2f, 0, 0, 0);
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_agencyheist");// FX Attachment
		GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_agencyheist");
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_fbi_dd_breach_smoke", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 52301, 0.1f, 0, 0, 0);
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_agencyheist");// FX Attachment
		GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_agencyheist");
		GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_fbi_dd_breach_smoke", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 14201, 0.1f, 0, 0, 0);
	}
	if (g_Local.superman)
	{
		Ped playerPed = PLAYER::PLAYER_PED_ID();
		if (GetAsyncKeyState(VK_SPACE) || PAD::IS_DISABLED_CONTROL_PRESSED(2, ControlFrontendAccept))
		{
			ENTITY::APPLY_FORCE_TO_ENTITY(playerPed, 3, 0.f, 0.f, 2.5f, 0.f, 0.f, 0.f, 0, true, false, true, false, false);
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(playerPed, 0xFBAB5776, 0, true);
			WEAPON::SET_CURRENT_PED_WEAPON(playerPed, 0xFBAB5776, true);
		}
		if (PED::IS_PED_RUNNING_RAGDOLL_TASK(playerPed) && PED::IS_PED_FALLING(playerPed) && PED::IS_PED_IN_PARACHUTE_FREE_FALL(playerPed))
		{
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(playerPed, 0xFBAB5776, 0, true);
			WEAPON::SET_CURRENT_PED_WEAPON(playerPed, 0xFBAB5776, true);
			if (GetAsyncKeyState(VK_KEY_W))
			{
				ENTITY::APPLY_FORCE_TO_ENTITY(playerPed, 3, 0.f, 2.5f, 0.f, 0.f, 0.f, 0.f, 0, true, false, true, false, false);
			}
			if (GetAsyncKeyState(VK_KEY_S))
			{
				ENTITY::APPLY_FORCE_TO_ENTITY(playerPed, 3, 0.f, -2.5f, 0.f, 0.f, 0.f, 0.f, 0, true, false, true, false, false);
			}
			if (GetAsyncKeyState(VK_SHIFT))
			{
				ENTITY::APPLY_FORCE_TO_ENTITY(playerPed, 3, 0.f, 0.f, -2.5f, 0.f, 0.f, 0.f, 0, true, false, true, false, false);
			}
		}
	}
	if (g_Local.walkonwater)
	{
		Player player = PLAYER::PLAYER_ID();
		Ped playerPed = PLAYER::PLAYER_PED_ID();
		DWORD model = ENTITY::GET_ENTITY_MODEL(PLAYER::PLAYER_PED_ID());
		Vector3 pos = ENTITY::GET_ENTITY_COORDS(playerPed, 0);
		float height = 0;
		WATER::_SET_CURRENT_INTENSITY(height);
		Object container = OBJECT::GET_CLOSEST_OBJECT_OF_TYPE(pos.x, pos.y, pos.z, 4.0, MISC::GET_HASH_KEY("prop_container_ld2"), 0, 0, 1);
		if (ENTITY::DOES_ENTITY_EXIST(container) && height > -50.0f)
		{
			Vector3 pRot = ENTITY::GET_ENTITY_ROTATION(playerPed, 0);
			MenuFunctions::requestControlOfEnt(container);
			ENTITY::SET_ENTITY_COORDS(container, pos.x, pos.y, height - 1.5f, 0, 0, 0, 1);
			ENTITY::SET_ENTITY_ROTATION(container, 0, 0, pRot.z, 0, 1);
			Vector3 containerCoords = ENTITY::GET_ENTITY_COORDS(container, 1);
			if (pos.z < containerCoords.z)
			{
				if (!PED::IS_PED_IN_ANY_VEHICLE(playerPed, 0))
				{
					ENTITY::SET_ENTITY_COORDS(playerPed, pos.x, pos.y, containerCoords.z + 2.0f, 0, 0, 0, 1);
				}
				else
				{
					MenuFunctions::requestControlOfEnt(playerPed);
					ENTITY::SET_ENTITY_COORDS(pos.x, pos.y, pos.z, containerCoords.z + 2.0f, 0, 0, 0, 1);
				}
			}
		}
		else
		{
			Hash model = MISC::GET_HASH_KEY("prop_container_ld2");
			STREAMING::REQUEST_MODEL(model);
			while (!STREAMING::HAS_MODEL_LOADED(model))WAIT(0);
			container = OBJECT::CREATE_OBJECT(model, pos.x, pos.y, pos.z, 1, 1, 0);
			MenuFunctions::requestControlOfEnt(container);
			ENTITY::FREEZE_ENTITY_POSITION(container, 1);
			ENTITY::SET_ENTITY_ALPHA(container, 0, 1);
			ENTITY::SET_ENTITY_VISIBLE(container, false, 0);
		}
	}
}

