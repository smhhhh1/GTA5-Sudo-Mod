#pragma once
#include "../../stdafx.h"

void Online::UpdateLoop()
{

}
