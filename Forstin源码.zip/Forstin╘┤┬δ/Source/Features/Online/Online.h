#pragma once 

namespace Online
{
	void UpdateLoop();

	inline std::uint32_t g_SelectedPlayer{};
}