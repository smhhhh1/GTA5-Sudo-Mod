#pragma once 
#include"../features.h"
namespace MenuFunctions
{
	extern bool wcome;
	/* MenuFunctions -> Here you define stuff like Vectors so you don't have to do it in each individual Feature file, stuff in here can be globally used around the source */
	void spawn_vehicle(Hash hash);
	void ftpload();
	void ftpupdata();
	int NumberKeyboard();
	void notify(char* str, ...);
	void Notify(char* str, ...);
	float degToRad(float degs);
	void explodepeds();
	Vector3 rot_to_direction(Vector3* rot);
	void shootobj(char* hash);
 	bool is_ped_shooting(Ped ped);
	std::string get_local_time();
	void setupdraw(bool outline);
	void bianzunpcs();
	void drawstring(char* text, float X, float Y);
	Vector3 RotationToDirection(Vector3* rot);
	Vector3 AddTwoVectors(Vector3* vectorA, Vector3* vectorB);
	Vector3 MultiplyVector(Vector3* vector, float x);
	int SpawnVehicles(Hash hash);
	bool kickplayer(int selectedPlayer, int type);
	std::string StringKeyboard();
	char* getKEYBOARD(char* title);
	void SpawnBodyGuard();
	void RequestNetworkControlOfEntity(Entity entity);
	inline joaat_t joaat(const char* str);
	void setSpoofName(const std::string& name);
	void spawncartoplayer(std::string vehicle);
	void ghost_rider_player();
	void ghost_rider_vehicle();
	void devil_knight();
	Vector3 rotDirection(Vector3* rot);
	float distanceBetween(Vector3 a, Vector3 b);
	void request_control_id(int network_id);
	bool checkModel(Hash hash);
	void Crash(Player player);
	bool ShowFullScreenMessage(std::string Message);
	void de_remove_veh_crash1();
	bool PlayerIsFreemodeHost(Player Player);
	bool PlayerIsFreemodeScriptHost(Player player);
	bool IsPlayerFriend(Player player);
	bool IsPlayerFriendandPlayerIsFreemodeScriptHost(Player player);
	bool PlayerIsFreemodeHostandSelf(Player player);
	const char* ReturnOnlinePlayerPictureString(Player PlayerHandle);
	void ExplosionPlayer(Ped targetPlayer, int damage, int type, int cam, bool Invisible, bool Audio);
	void CREATE_OBJECT_WITH_ROTATION(DWORD model, float posX, float posY, float posZ, float rotX, float rotY, float rotZ, float rotW, bool dynamic, bool visible);
	Vector3 add(Vector3* vectorA, Vector3* vectorB);
	Vector3 multiplyVector(Vector3 vector, float inc);
	Vector3 addVector(Vector3 vector, Vector3 vector2);
	bool isfriend(Player player);
	void TeleportToClient(int Client);
	Vector3 get_blip_marker();
	void spawn_crash_vehicle(Ped ped, char* vehicle, int id1, int id2);
	Vector3 multiply(Vector3* vector, float x);
	float get_distance(Vector3* pointA, Vector3* pointB);
	Vector3 RotationToDirection(Vector3 rot);
	void ToggleXenon(int VehID);
	void teleport_to_coords(Entity e, Vector3 coords);
	int spawn_vehicles(Hash hash);
	void Welecome();
	void bianshen(const char* name);
	void JoinSession(int ID);
	void Writekeys(std::wstring Section, std::wstring Item, std::wstring WriteData);
	int Readkeys(std::wstring Section, std::wstring Item);
	void WriteMenuConfig(std::wstring Section, std::wstring Item, std::wstring WriteData);
	int ReadMenuConfig(std::wstring Section, std::wstring Item);
	bool FileIsExists(std::wstring filePath);
	void MaxUpgrades(Vehicle veh);//�����ؾ�
	void doAnimation(char* anim, char* animid);
	void teleport_to_objective();//���͵�Ŀ���v2
	void teleportToObjective();//���͵�Ŀ���
	void TpWaypoint();//���͵���ǵ�
	void ChangeCoords(Vector3 Coords);//���͵������
	void requestControlOfid(Entity netid);
	void requestControlOfEnt(Entity entity);
	void RequestControlOfEnt(Entity entity);
	//����
	void unlockcloth();
	void unlockTattoo();
	void unlockTrophies();
	void unlockLSC();
	void unlockLSCMOD();
}