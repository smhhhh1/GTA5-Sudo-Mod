#pragma once 

namespace Misc
{
	void UpdateLoop();
}