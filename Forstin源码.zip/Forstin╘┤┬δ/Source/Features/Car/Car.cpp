#pragma once
#include "../../stdafx.h"

void Car::UpdateLoop()
{

}