#pragma once 

namespace Car
{
	void UpdateLoop();
}