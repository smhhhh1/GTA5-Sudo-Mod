#pragma once 

namespace Gun
{
	void UpdateLoop();
}