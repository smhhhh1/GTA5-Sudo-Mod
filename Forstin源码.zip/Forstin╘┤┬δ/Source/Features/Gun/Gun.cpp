#pragma once
#include "../../stdafx.h"

void Gun::UpdateLoop()
{

}