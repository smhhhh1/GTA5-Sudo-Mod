#pragma once
#include "../../stdafx.h"

namespace MenuFunctions
{
	void Notify(char* str, ...)
	{
		using namespace Menu;
		HUD::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
		HUD::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(str);
		HUD::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2("CHAR_LESTER_DEATHWISH", "CHAR_LESTER_DEATHWISH", 1, 4, "", "Forstin֪ͨ��", 1, "", 4, 0);
		HUD::_DRAW_NOTIFICATION(8000, 1);
	}
	void notify(char* str, ...) {
		va_list list;
		char Str[512];
		char Params[512];
		va_start(list, str);
		_vsnprintf_s(Params, sizeof(Params), str, list);
		va_end(list);
		sprintf_s(Str, "%s", Params);
		HUD::SET_TEXT_OUTLINE();
		HUD::BEGIN_TEXT_COMMAND_THEFEED_POST("STRING");
		HUD::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(Str);
		HUD::END_TEXT_COMMAND_THEFEED_POST_TICKER(FALSE, FALSE);

	}
	void bianshen(const char* name)
	{
		*(unsigned short*)hooks.m_model_spawn_bypass = 0x9090;
		Hash hash = MISC::GET_HASH_KEY(name);
		if (STREAMING::IS_MODEL_IN_CDIMAGE(hash) && STREAMING::IS_MODEL_VALID(hash))
		{
			STREAMING::REQUEST_MODEL(hash);
			while (!STREAMING::HAS_MODEL_LOADED(hash)) WAIT(0);
			PLAYER::SET_PLAYER_MODEL(PLAYER::PLAYER_ID(), hash);
			PED::SET_PED_DEFAULT_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID());
			STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(hash);
			ENTITY::SET_ENTITY_MAX_HEALTH(PLAYER::PLAYER_PED_ID(), 328);
			ENTITY::SET_ENTITY_HEALTH(PLAYER::PLAYER_PED_ID(), 328);
		}
		*(unsigned short*)hooks.m_model_spawn_bypass = 0x0574;
	}
	Vehicle spawn_vehicle(Hash hash, Entity on_entity) {

		globalHandle(4533757).As<bool>() = true;
		if (STREAMING::IS_MODEL_VALID(hash)) {
			STREAMING::REQUEST_MODEL(hash);
			while (!STREAMING::HAS_MODEL_LOADED(hash)) 			WAIT(0);
			Vector3 l_coords = ENTITY::GET_ENTITY_COORDS(on_entity, false);
			int net_id = NETWORK::VEH_TO_NET(VEHICLE::CREATE_VEHICLE(hash, l_coords.x, l_coords.y, l_coords.z, ENTITY::GET_ENTITY_HEADING(on_entity), TRUE, FALSE, false));
			NETWORK::SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(net_id, TRUE);
			if (ENTITY::IS_ENTITY_VISIBLE_TO_SCRIPT(NETWORK::NET_TO_VEH(net_id))) {
				DECORATOR::DECOR_SET_INT(NETWORK::NET_TO_VEH(net_id), "MPBitset", (1 << 10));
				return NETWORK::NET_TO_VEH(net_id);
			}
		}
		return NULL;
	}
	bool RequestNetworkControl(UINT vehID)
	{
		int Tries = 0;
		bool
			hasControl = false,
			giveUp = false;
		do
		{
			hasControl = NETWORK::NETWORK_REQUEST_CONTROL_OF_ENTITY(vehID);
			Tries++;
			if (Tries > 300)
				giveUp = true;
		} while (!hasControl && !giveUp);

		if (giveUp)
			return false;
		else return true;
	}
	void MaxUpgrades(Vehicle veh)
	{
		VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
		VEHICLE::SET_VEHICLE_NUMBER_PLATE_TEXT_INDEX(veh, 1);
		VEHICLE::TOGGLE_VEHICLE_MOD(veh, 18, 1);
		VEHICLE::TOGGLE_VEHICLE_MOD(veh, 22, 1);
		VEHICLE::SET_VEHICLE_MOD(veh, 16, 5, 0);
		VEHICLE::SET_VEHICLE_MOD(veh, 12, 2, 0);
		VEHICLE::SET_VEHICLE_MOD(veh, 11, 3, 0);
		VEHICLE::SET_VEHICLE_MOD(veh, 14, 14, 0);
		VEHICLE::SET_VEHICLE_MOD(veh, 15, 3, 0);
		VEHICLE::SET_VEHICLE_MOD(veh, 13, 2, 0);
		VEHICLE::SET_VEHICLE_WHEEL_TYPE(veh, 6);
		VEHICLE::SET_VEHICLE_WINDOW_TINT(veh, 5);
		VEHICLE::SET_VEHICLE_MOD(veh, 23, 19, 1);
		VEHICLE::SET_VEHICLE_MOD(veh, 0, 1, 0);
		VEHICLE::SET_VEHICLE_MOD(veh, 1, 1, 0);
		VEHICLE::SET_VEHICLE_MOD(veh, 2, 1, 0);
		VEHICLE::SET_VEHICLE_MOD(veh, 3, 1, 0);
		VEHICLE::SET_VEHICLE_MOD(veh, 4, 1, 0);
		VEHICLE::SET_VEHICLE_MOD(veh, 5, 1, 0);
		VEHICLE::SET_VEHICLE_MOD(veh, 6, 1, 0);
		VEHICLE::SET_VEHICLE_MOD(veh, 7, 1, 0);
		VEHICLE::SET_VEHICLE_MOD(veh, 8, 1, 0);
		VEHICLE::SET_VEHICLE_MOD(veh, 9, 1, 0);
		VEHICLE::SET_VEHICLE_MOD(veh, 10, 1, 0);
		VEHICLE::_IS_VEHICLE_NEON_LIGHT_ENABLED(veh, 1);
		VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 0, 1);
		VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 1, 1);
		VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 2, 1);
		VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 3, 1);
		VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 4, 1);
		VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 5, 1);
		VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 6, 1);
		VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(veh, 7, 1);
		VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
		VEHICLE::TOGGLE_VEHICLE_MOD(veh, 20, 1);
		VEHICLE::SET_VEHICLE_MOD_KIT(veh, 0);
		VEHICLE::SET_VEHICLE_TYRE_SMOKE_COLOR(veh, 0, 0, 0);
		STREAMING::REQUEST_NAMED_PTFX_ASSET("proj_xmas_firework");
		STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_clown_appears");
	}
	void teleport_to_coords(Entity e, Vector3 coords)
	{
		ENTITY::SET_ENTITY_COORDS_NO_OFFSET(e, coords.x, coords.y, coords.z, 0, 0, 1);
		WAIT(0);
	}
	void offaidrive()
	{
		BRAIN::CLEAR_PED_TASKS(PLAYER::PLAYER_PED_ID());
		/*BRAIN::CLEAR_PED_SECONDARY_TASK(PLAYER::PLAYER_PED_ID());*/
	}
	bool PlayerIsFreemodeScriptHost(Player player)
	{
		if (player == NETWORK::NETWORK_GET_HOST_OF_SCRIPT("Freemode", -1, 0))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	bool PlayerIsFreemodeHost(Player player)
	{
		if (player == NETWORK::NETWORK_GET_HOST_OF_SCRIPT("Freemode", 4294967295, 0))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	bool PlayerIsFreemodeHostandSelf(Player player)
	{
		if (player = PLAYER::PLAYER_ID())
		{
			if (player == NETWORK::NETWORK_GET_HOST_OF_SCRIPT("Freemode", 4294967295, 0))
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
	}
	bool IsPlayerFriendandPlayerIsFreemodeScriptHost(Player player)
	{
		if (player == NETWORK::NETWORK_GET_HOST_OF_SCRIPT("Freemode", 4294967295, 0))
		{
			int handle[76];
			NETWORK::NETWORK_HANDLE_FROM_PLAYER(player, &handle[0], 13);
			if (NETWORK::NETWORK_IS_HANDLE_VALID(&handle[0], 13))
			{
				if (NETWORK::NETWORK_IS_FRIEND(&handle[0]))
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}
		else
		{
			return false;
		}
	}
	bool IsPlayerFriend(Player player)
	{
		int handle[76];
		NETWORK::NETWORK_HANDLE_FROM_PLAYER(player, &handle[0], 13);
		if (NETWORK::NETWORK_IS_HANDLE_VALID(&handle[0], 13))
		{
			if (NETWORK::NETWORK_IS_FRIEND(&handle[0]))
			{
				return true;
			}
		}
		return false;
	}
	Vector3 get_blip_marker()
	{
		static Vector3 zero;
		Vector3 coords;

		bool blipFound = false;
		int blipIterator = HUD::_GET_BLIP_INFO_ID_ITERATOR();
		for (Blip i = HUD::GET_FIRST_BLIP_INFO_ID(blipIterator); HUD::DOES_BLIP_EXIST(i) != 0; i = HUD::GET_NEXT_BLIP_INFO_ID(blipIterator))
		{
			if (HUD::GET_BLIP_INFO_ID_TYPE(i) == 4)
			{
				coords = HUD::GET_BLIP_INFO_ID_COORD(i);
				blipFound = true;
				break;
			}
		}
		if (blipFound)
		{
			return coords;
		}

		return zero;
	}
	Vector3 AddTwoVectors(Vector3* vectorA, Vector3* vectorB)
	{
		Vector3 result;
		result.x = vectorA->x;
		result.y = vectorA->y;
		result.z = vectorA->z;
		result.x += vectorB->x;
		result.y += vectorB->y;
		result.z += vectorB->z;
		return result;
	}
	Vector3 RotationToDirection(Vector3* rot)
	{
		float radiansZ = rot->z * 0.0174532924f;
		float radiansX = rot->x * 0.0174532924f;
		float num = abs((float)cos((double)radiansX));
		Vector3 dir;
		dir.x = (float)((double)((float)(-(float)sin((double)radiansZ))) * (double)num);
		dir.y = (float)((double)((float)cos((double)radiansZ)) * (double)num);
		dir.z = (float)sin((double)radiansX);
		return dir;
	}
	Vector3 MultiplyVector(Vector3* vector, float x)
	{
		Vector3 result;
		result.x = vector->x;
		result.y = vector->y;
		result.z = vector->z;
		result.x *= x;
		result.y *= x;
		result.z *= x;
		return result;
	}
	const char* ReturnOnlinePlayerPictureString(Player PlayerHandle)
	{
		if (NETWORK::NETWORK_IS_SESSION_STARTED())
		{
			int Index = 1660783 + 2;
			for (int x = 0; x <= 150; x += 5)
			{
				int playerId = globalHandle(Index).At(x).As<int>();
				if (playerId == PlayerHandle)
				{
					int PedHeadshotHandle = globalHandle(Index).At(x).At(1).As<int>();
					if (PED::IS_PEDHEADSHOT_VALID(PedHeadshotHandle))
					{
						return PED::GET_PEDHEADSHOT_TXD_STRING(PedHeadshotHandle);
					}
				}
				if (playerId == -1)
				{
					break;
				}
			}
		}
		return "CHAR_DEFAULT";
	}
	std::string get_local_time()
	{
		time_t now = time(0);
		tm* ltm = localtime(&now);

		int nian = 1900 + ltm->tm_year;
		int yue = 1 + ltm->tm_mon;
		int ri = ltm->tm_mday;
		int xs = (ltm->tm_hour + 8) % 24;
		int fz = ltm->tm_min;
		int miao = ltm->tm_sec;
		int hour = hour;
		std::string jg = std::to_string(nian) + "/" + std::to_string(yue) + "/" + std::to_string(ri) + "/" + std::to_string(xs) + ":" + std::to_string(fz) + ":" + std::to_string(miao);
		return jg;
	}
	char* getKEYBOARD(char* title) {

		WAIT(100);
		MISC::DISPLAY_ONSCREEN_KEYBOARD(0, title, "", "", "", "", "", 20);
		while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
		if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return "";
		return StringToChar(MISC::GET_ONSCREEN_KEYBOARD_RESULT());
		WAIT(100);

	}
	void spawncartoplayer(std::string vehicle)
	{
		globalHandle(4270934).As<bool>() = true;
		globalHandle(4268190) = 1;
		globalHandle(1628955 + PLAYER::GET_PLAYER_INDEX()) = (1 << 3);
		Hash model = MISC::GET_HASH_KEY((char*)_strdup(vehicle.c_str()));
		if (STREAMING::IS_MODEL_VALID(model) && STREAMING::IS_MODEL_A_VEHICLE(model))
		{
			STREAMING::REQUEST_MODEL(model);
			while (!STREAMING::HAS_MODEL_LOADED(model)) WAIT(1);
			Vector3 coords = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), 0, 5.0, 1);
			float heading = ENTITY::GET_ENTITY_HEADING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
			Vehicle veh = VEHICLE::CREATE_VEHICLE(model, coords.x, coords.y + 5.0f, coords.z, heading, true, true);
			VEHICLE::SET_VEHICLE_ON_GROUND_PROPERLY(veh);
			ENTITY::SET_ENTITY_CAN_BE_DAMAGED(veh, true);
			STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(model);
		}
	}
	static std::vector<DWORD64> nameAddresses;
	std::vector<DWORD64> getNameAddresses()
	{
		return nameAddresses;
	}
	void allocateNameAddresses() {

		if (nameAddresses.empty())
		{
			std::string currentMask;
			const char* playerName = PLAYER::GET_PLAYER_NAME(PLAYER::PLAYER_ID());
			for (uint8_t i = 0; i < strlen(playerName); i++) currentMask += "x";
			const char* mask = currentMask.c_str();

			for (DWORD64 address : Memory::get_string_addresses(playerName)) {
				nameAddresses.push_back((address));
			}
		}
	}
	void setSpoofName(const std::string& name)
	{
		allocateNameAddresses();
		size_t newLen = name.size() + 1;
		if (newLen <= 1 || newLen > 20)
			return;

		char buffer[0x20] = {};
		char* playerName = (char*)PLAYER::GET_PLAYER_NAME(PLAYER::PLAYER_ID()) + 0x5C;
		size_t curLen = strlen(playerName) + 1;

		strncpy_s(buffer, playerName, curLen);

		for (uint32_t i = 0, found = 0, match = 0; found < 4; ++playerName)
		{
			if (*playerName != buffer[i])
				goto LABEL_RESET;

			if (++match < curLen)
			{
				++i;
				continue;
			}

			strncpy_s(playerName - i, newLen, &name[0], newLen);
			++found;

		LABEL_RESET:
			i = match = 0;
		}

		strncpy((char*)PLAYER::GET_PLAYER_NAME(PLAYER::PLAYER_ID()), name.c_str(), newLen);

		for (DWORD64 Address : getNameAddresses()) {
			strncpy((char*)Address, &name[0], newLen);
		}
	}
	void ghost_rider_vehicle()
	{
		static int timer = 0;
		if (GetTickCount64() - timer >= 500)
		{
			Vehicle veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false);
			if (veh)
			{
				if (ENTITY::GET_ENTITY_MODEL(veh) != 1491277511)
					return;
				Vector3 coords = ENTITY::GET_WORLD_POSITION_OF_ENTITY_BONE(veh, ENTITY::GET_ENTITY_BONE_INDEX_BY_NAME(veh, "wheel_lf"));
				STREAMING::REQUEST_NAMED_PTFX_ASSET("core");
				GRAPHICS::USE_PARTICLE_FX_ASSET("core");
				GRAPHICS::START_NETWORKED_PARTICLE_FX_NON_LOOPED_AT_COORD("ent_sht_petrol_fire", coords.x, coords.y, coords.z, 90.f, -100.f, 90.f, 1.3f, 1, 1, 1);
				STREAMING::REMOVE_PTFX_ASSET();

				coords = ENTITY::GET_WORLD_POSITION_OF_ENTITY_BONE(veh, ENTITY::GET_ENTITY_BONE_INDEX_BY_NAME(veh, "wheel_lr"));
				GRAPHICS::USE_PARTICLE_FX_ASSET("core");
				GRAPHICS::START_NETWORKED_PARTICLE_FX_NON_LOOPED_AT_COORD("ent_sht_petrol_fire", coords.x, coords.y, coords.z, 90.f, -100.f, 90.f, 1.3f, 1, 1, 1);
				STREAMING::REMOVE_PTFX_ASSET();
			}
		}
	}
	void ghost_rider_player()
	{
		float XPos = 0, YPos = 0, ZPos = 0.0, XOff = 90.0, YOff = -100.0, ZOff = 90.0;
		static int timer = 0;
		if (GetTickCount64() - timer >= 3000)//������ֵ����500�����������ｫ��˲���ȼ
		{
			STREAMING::REQUEST_NAMED_PTFX_ASSET("core");
			GRAPHICS::USE_PARTICLE_FX_ASSET("core");
			GRAPHICS::START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("ent_sht_petrol_fire", PLAYER::PLAYER_PED_ID(), XPos, YPos, ZPos, XOff, YOff, ZOff, SKEL_Head, 1, 1, 1, 1);  //ͷ
			STREAMING::REMOVE_PTFX_ASSET();

			STREAMING::REQUEST_NAMED_PTFX_ASSET("core");
			GRAPHICS::USE_PARTICLE_FX_ASSET("core");
			GRAPHICS::START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("ent_sht_petrol_fire", PLAYER::PLAYER_PED_ID(), XPos, YPos, ZPos, XOff, YOff, ZOff, SKEL_L_Foot, 1, 1, 1, 1);  //���
			STREAMING::REMOVE_PTFX_ASSET();

			STREAMING::REQUEST_NAMED_PTFX_ASSET("core");
			GRAPHICS::USE_PARTICLE_FX_ASSET("core");
			GRAPHICS::START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("ent_sht_petrol_fire", PLAYER::PLAYER_PED_ID(), XPos, YPos, ZPos, XOff, YOff, ZOff, SKEL_R_Foot, 1, 1, 1, 1);  //�ҽ�
			STREAMING::REMOVE_PTFX_ASSET();

			STREAMING::REQUEST_NAMED_PTFX_ASSET("core");
			GRAPHICS::USE_PARTICLE_FX_ASSET("core");
			GRAPHICS::START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("ent_sht_petrol_fire", PLAYER::PLAYER_PED_ID(), XPos, YPos, ZPos, XOff, YOff, ZOff, SKEL_R_Hand, 1, 1, 1, 1);  //����
			STREAMING::REMOVE_PTFX_ASSET();

			STREAMING::REQUEST_NAMED_PTFX_ASSET("core");
			GRAPHICS::USE_PARTICLE_FX_ASSET("core");
			GRAPHICS::START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("ent_sht_petrol_fire", PLAYER::PLAYER_PED_ID(), XPos, YPos, ZPos, XOff, YOff, ZOff, SKEL_L_Hand, 1, 1, 1, 1);  //����
			STREAMING::REMOVE_PTFX_ASSET();

			timer = GetTickCount64();

		}
	}

	void devil_knight()
	{
		Hash hash = 1491277511;
		if (STREAMING::IS_MODEL_VALID(hash))
		{
			STREAMING::REQUEST_MODEL(hash);
			while (!STREAMING::HAS_MODEL_LOADED(hash))
				WAIT(0);

			Ped ped = PLAYER::PLAYER_PED_ID();
			Vector3 pos = ENTITY::GET_ENTITY_COORDS(ped, true);
			float forward = 5.f;
			float heading = ENTITY::GET_ENTITY_HEADING(ped);
			float xVector = forward * sin(heading * 3.141592653589793f / 180.f) * -1.f;
			float yVector = forward * cos(heading * 3.141592653589793f / 180.f);
			*(unsigned short*)hooks.m_model_spawn_bypass = 0x9090;
			Vehicle vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x + xVector, pos.y + yVector, pos.z, 0.f, true, false);
			*(unsigned short*)hooks.m_model_spawn_bypass = 0x0574;
			//last_vehicle = vehicle;
			ENTITY::SET_ENTITY_INVINCIBLE(vehicle, true);
			ENTITY::SET_ENTITY_RENDER_SCORCHED(vehicle, true);
		}
		STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(hash);
	}
	bool checkModel(Hash hash) {
		//model_check_bypass(true);
		if (STREAMING::IS_MODEL_IN_CDIMAGE(hash)) {
			if (STREAMING::IS_MODEL_VALID(hash)) {
				STREAMING::REQUEST_MODEL(hash);
				while (!STREAMING::HAS_MODEL_LOADED(hash)) {
					WAIT(0);
				}
				return true;
			}
		}
		return false;
		//model_check_bypass(false);
	}
	void CREATE_OBJECT_WITH_ROTATION(DWORD model, float posX, float posY, float posZ, float rotX, float rotY, float rotZ, float rotW, bool dynamic, bool visible)
	{
		if (STREAMING::IS_MODEL_IN_CDIMAGE(model) && STREAMING::IS_MODEL_VALID(model))
		{
			STREAMING::REQUEST_MODEL(model);
			while (!STREAMING::HAS_MODEL_LOADED(model)) WAIT(0);
			Object obj = OBJECT::CREATE_OBJECT(model, posX, posY, posZ, true, false, dynamic);
			ENTITY::SET_ENTITY_QUATERNION(obj, rotX, rotY, rotZ, rotW);
			ENTITY::SET_ENTITY_AS_MISSION_ENTITY(obj, true, true);
			ENTITY::SET_ENTITY_DYNAMIC(obj, false);
			if (!visible)
			{
				ENTITY::SET_ENTITY_VISIBLE(obj, false, false);
			}
			ENTITY::SET_ENTITY_PROOFS(obj, true, true, true, true, true, true, true, true);
			ENTITY::SET_ENTITY_INVINCIBLE(obj, true);
			WAIT(500);
			STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(model);
		}
	}
	void request_control_id(int network_id)
	{
		int tick = 0;

		while (!NETWORK::NETWORK_HAS_CONTROL_OF_NETWORK_ID(network_id) && tick <= 25)
		{
			NETWORK::NETWORK_REQUEST_CONTROL_OF_NETWORK_ID(network_id);
			tick++;
		}
	}
	void TeleportToClient(int Client)
	{
		Vector3 Coords = ENTITY::GET_ENTITY_COORDS(Client, 1);
		if (PED::IS_PED_SITTING_IN_ANY_VEHICLE(PLAYER::PLAYER_PED_ID()))
		{
			ENTITY::SET_ENTITY_COORDS(PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID()), Coords.x, Coords.y, Coords.z, 1, 0, 0, 1);
		}
		else
		{
			ENTITY::SET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), Coords.x, Coords.y, Coords.z, 1, 0, 0, 1);
		}
	}
	void doAnimation(char* anim, char* animid)
	{
		int pPlayer = PLAYER::PLAYER_PED_ID();
		RequestNetworkControl(pPlayer);
		STREAMING::REQUEST_ANIM_DICT(anim);
		if (STREAMING::HAS_ANIM_DICT_LOADED((anim)))
		{
			BRAIN::TASK_PLAY_ANIM(pPlayer, anim, animid, 8.0f, 0.0f, -1, 9, 0, 0, 0, 0);
		}
	}
	void TpWaypoint()
	{
		Vector3 coords = get_blip_marker();
		if (coords.x == 0 && coords.y == 0)
		{
			Notify("��û�б�ǵ����㣡");
			return;
		}
		Entity e = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID());
		if (PED::IS_PED_IN_ANY_VEHICLE(e, 0))
		{
			e = PED::GET_VEHICLE_PED_IS_USING(e);
		}
		bool groundFound = false;
		static float groundCheckHeight[] =
		{ 100.0, 150.0, 50.0, 0.0, 200.0, 250.0, 300.0, 350.0, 400.0, 450.0, 500.0, 550.0, 600.0, 650.0, 700.0, 750.0, 800.0 };
		for (int i = 0; i < sizeof(groundCheckHeight) / sizeof(float); i++)
		{
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(e, coords.x, coords.y, groundCheckHeight[i], 0, 0, 1);
			WAIT(150);
			if (MISC::GET_GROUND_Z_FOR_3D_COORD(coords.x, coords.y, groundCheckHeight[i], &coords.z, 0))
			{
				groundFound = true;
				coords.z += 3.0;
				break;
			}
		}
		// if ground not found then set Z in air and give player a parachute
		if (!groundFound)
		{
			coords.z = 1000.0;
			WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), 0xFBAB5776, 1, 0);
		}
		//do it
		MenuFunctions::teleport_to_coords(e, coords);
		HUD::SET_WAYPOINT_OFF();

	}
	CBlip* get_blip_objective()
	{
		CBlip* r = nullptr;
		for (int i = 0; i < 0x400; i++)
		{
			if (BlipList* blipList = Hooking::m_blipList)
			{
				if (CBlip* blip = blipList->m_Blips[i])
				{
					auto colour = blip->dwColor;
					auto icon = blip->iIcon;
					if ((colour == ColorYellowMission && icon == SpriteStandard) ||
						(colour == ColorYellowMission2 && icon == SpriteStandard) ||
						(colour == ColorYellow && icon == SpriteStandard) ||
						(colour == ColorWhite && icon == SpriteRaceFinish) ||
						(colour == ColorGreen && icon == SpriteStandard) ||
						(colour == ColorBlue && icon == SpriteStandard) ||
						(icon == SpriteCrateDrop))
					{
						r = blip;
						break;
					}
				}
			}
		}
		return r;
	}
	void teleport_to_coord(Entity e, float x, float y, float z)
	{
		ENTITY::SET_ENTITY_COORDS_NO_OFFSET(e, x, y, z, 0, 0, 1);
		WAIT(0);
	}
	void teleport_to_objective()
	{
		CBlip* blip = get_blip_objective();
		if (blip == nullptr)
			MenuFunctions::Notify("û���ҵ�Ŀ��㣡");
		else
		{
			Entity e = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID());
			if (PED::IS_PED_IN_ANY_VEHICLE(e, 0))
			{
				e = PED::GET_VEHICLE_PED_IS_USING(e);
			}
			teleport_to_coord(e, blip->x, blip->y, blip->z + 0.5f);
		}
	}
	bool wcome = true;
	void Welecome()
	{
		using namespace Menu;
		HUD::_SET_NOTIFICATION_TEXT_ENTRY("STRING");
		HUD::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("��ӭ��ʹ�� ~p~Forstin");
		HUD::_SET_NOTIFICATION_MESSAGE_CLAN_TAG_2("CHAR_LESTER_DEATHWISH", "CHAR_LESTER_DEATHWISH", 1, 4, "", "~g~[Forstinע��ɹ�]", 1, "", 4, 0);
		HUD::_DRAW_NOTIFICATION(8000, 1);
		wcome = true;


	}
	void Writekeys(std::wstring Section, std::wstring Item, std::wstring WriteData)
	{
		WritePrivateProfileStringW(Section.c_str(), Item.c_str(), WriteData.c_str(), L"C:\\Forstin\\Config\\Keys.ini");
	}

	void WriteMenuConfig(std::wstring Section, std::wstring Item, std::wstring WriteData)
	{
		WritePrivateProfileStringW(Section.c_str(), Item.c_str(), WriteData.c_str(), L"C:\\Forstin\\Config\\Menuconfig.ini");
	}

	int ReadMenuConfig(std::wstring Section, std::wstring Item)
	{
		return GetPrivateProfileIntW(Section.c_str(), Item.c_str(), 0, L"C:\\Forstin\\Config\\Menuconfig.ini");
	}

	int Readkeys(std::wstring Section, std::wstring Item)
	{
		return GetPrivateProfileIntW(Section.c_str(), Item.c_str(), 0, L"C:\\Forstin\\Config\\Keys.ini");
	}

	bool FileIsExists(std::wstring filePath)
	{
		return GetFileAttributesW(filePath.c_str()) == INVALID_FILE_ATTRIBUTES ? false : true;
	}
	void JoinSession(int ID) {
		if (ID == -1) {
			globalHandle(1575015 + 2).As<int>() = -1;
			globalHandle(1574589).As<int>() = 1;
		}
		else {
			globalHandle(1575015 + 2).As<int>() = ID;
			globalHandle(1574589).As<int>() = 1;

		}
		WAIT(200);
		globalHandle(1574589).As<int>() = 0;
	}
	void setupdraw(bool outline)
	{
		HUD::SET_TEXT_FONT(1);
		HUD::SET_TEXT_SCALE(0.4f, 0.4f);
		HUD::SET_TEXT_COLOUR(255, 255, 255, 255);
		HUD::SET_TEXT_WRAP(0.0f, 1.0f);
		HUD::SET_TEXT_CENTRE(0);
		HUD::SET_TEXT_DROPSHADOW(0, 0, 0, 0, 0);
		HUD::SET_TEXT_EDGE(0, 0, 0, 0, 0);
		if (outline)
		{
			HUD::SET_TEXT_OUTLINE();
		}
	}
	void drawstring(char* text, float X, float Y)
	{
		HUD::BEGIN_TEXT_COMMAND_DISPLAY_TEXT((char*)"STRING");
		HUD::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text);
		HUD::END_TEXT_COMMAND_DISPLAY_TEXT(X, Y, 0);
	}
	void bianzunpcs()
	{
		const int ElementAmount = 10;
		const int ArrSize = ElementAmount * 2 + 2;

		Ped* peds = new Ped[ArrSize];
		peds[0] = ElementAmount;

		int PedFound = PED::GET_PED_NEARBY_PEDS(PLAYER::PLAYER_PED_ID(), peds, -1);

		for (int i = 0; i < PedFound; i++)
		{
			int OffsetID = i * 2 + 2;
			requestControlOfEnt(peds[OffsetID]);
			if (ENTITY::DOES_ENTITY_EXIST(peds[OffsetID]) && PLAYER::PLAYER_PED_ID() != peds[OffsetID])
			{
				int group = PED::GET_PED_GROUP_INDEX(PLAYER::PLAYER_PED_ID());
				PED::SET_PED_AS_GROUP_MEMBER(peds[OffsetID], group);
				BRAIN::TASK_FOLLOW_TO_OFFSET_OF_ENTITY(peds[OffsetID], PLAYER::PLAYER_PED_ID(), 0, 0, 0, 1, 0, 3.5f, 1);
			}
		}
		delete[]peds;
	}
	bool isfriend(Player player)
	{
		BOOL BplayerFriend = false;
		bool bplayerFriend = false;
		int handle[76]; //var num3 = sub_34009(A_0, (A_1) + 264, (A_1) + 272);
		NETWORK::NETWORK_HANDLE_FROM_PLAYER(player, &handle[0], 13);
		if (NETWORK::NETWORK_IS_HANDLE_VALID(&handle[0], 13))
		{
			BplayerFriend = NETWORK::NETWORK_IS_FRIEND(&handle[0]);
		}
		if (BplayerFriend == 1)
			bplayerFriend = true;
		else
			bplayerFriend = false;

		return bplayerFriend;
	}
	Vector3 rotDirection(Vector3* rot)
	{
		float radianz = rot->z * 0.0174532924f;
		float radianx = rot->x * 0.0174532924f;
		float num = std::abs((float)std::cos((double)radianx));

		Vector3 dir;

		dir.x = (float)((double)((float)(-(float)std::sin((double)radianz))) * (double)num);
		dir.y = (float)((double)((float)std::cos((double)radianz)) * (double)num);
		dir.z = (float)std::sin((double)radianx);

		return dir;
	}
	float distanceBetween(Vector3 a, Vector3 b) {
		return MISC::GET_DISTANCE_BETWEEN_COORDS(a.x, a.y, a.z, b.x, b.y, b.z, 1);
	}
	Vector3 add(Vector3* vectorA, Vector3* vectorB) {
		Vector3 result;
		result.x = vectorA->x;
		result.y = vectorA->y;
		result.z = vectorA->z;
		result.x += vectorB->x;
		result.y += vectorB->y;
		result.z += vectorB->z;
		return result;
	}

	Vector3 multiply(Vector3* vector, float x) {
		Vector3 result;
		result.x = vector->x;
		result.y = vector->y;
		result.z = vector->z;
		result.x *= x;
		result.y *= x;
		result.z *= x;
		return result;
	}
	float get_distance(Vector3* pointA, Vector3* pointB) {
		float a_x = pointA->x;
		float a_y = pointA->y;
		float a_z = pointA->z;
		float b_x = pointB->x;
		float b_y = pointB->y;
		float b_z = pointB->z;
		double x_ba = (double)(b_x - a_x);
		double y_ba = (double)(b_y - a_y);
		double z_ba = (double)(b_z - a_z);
		double y_2 = y_ba * y_ba;
		double x_2 = x_ba * x_ba;
		double sum_2 = y_2 + x_2;
		return(float)sqrt(sum_2 + z_ba);
	}
	Vector3 rot_to_direction(Vector3* rot)
	{
		float radiansZ = rot->z * 0.0174532924f;
		float radiansX = rot->x * 0.0174532924f;
		float num = std::abs((float)std::cos((double)radiansX));
		Vector3 dir;
		dir.x = (float)((double)((float)(-(float)std::sin((double)radiansZ))) * (double)num);
		dir.y = (float)((double)((float)std::cos((double)radiansZ)) * (double)num);
		dir.z = (float)std::sin((double)radiansX);
		return dir;
	}
	Vector3 multiplyVector(Vector3 vector, float inc) {
		vector.x *= inc;
		vector.y *= inc;
		vector.z *= inc;
		vector._paddingx *= inc;
		vector._paddingy *= inc;
		vector._paddingz *= inc;
		return vector;
	}
	void shootobj(char* hash)
	{
		Hash obj = MISC::GET_HASH_KEY(hash);
		Player player_ped = PLAYER::PLAYER_PED_ID();
		STREAMING::REQUEST_MODEL(obj);
		if (ENTITY::DOES_ENTITY_EXIST(player_ped) && PED::IS_PED_SHOOTING_IN_AREA)
		{
			Vector3 pos;
			if (WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(player_ped, &pos))
			{
				OBJECT::CREATE_OBJECT(obj, pos.x, pos.y, pos.z, true, false, false);
			}
		}
	}
	bool is_ped_shooting(Ped ped)
	{
		Vector3 coords = ENTITY::GET_ENTITY_COORDS(ped, 1);
		return PED::IS_PED_SHOOTING_IN_AREA(ped, coords.x, coords.y, coords.z, coords.x, coords.y, coords.z, true, true);
	}
	Vector3 addVector(Vector3 vector, Vector3 vector2) {
		vector.x += vector2.x;
		vector.y += vector2.y;
		vector.z += vector2.z;
		vector._paddingx += vector2._paddingx;
		vector._paddingy += vector2._paddingy;
		vector._paddingz += vector2._paddingz;
		return vector;
	}
	double DegreeToRadian(double n)
	{
		return n * 0.017453292519943295;
	}
	Vector3 RotationToDirection(Vector3 rot) {
		double num = DegreeToRadian(rot.z);
		double num2 = DegreeToRadian(rot.x);
		double val = cos(num2);
		double num3 = abs(val);
		rot.x = (float)(-(float)sin(num) * num3);
		rot.y = (float)(cos(num) * num3);
		rot.z = (float)sin(num2);
		return rot;

	}
	Vector3 get_mission_objective()
	{
		Vector3 blipCoords;

		for (Blip x = HUD::GET_FIRST_BLIP_INFO_ID(1); HUD::DOES_BLIP_EXIST(x) != 0; x = HUD::GET_NEXT_BLIP_INFO_ID(1))
		{
			if (HUD::GET_BLIP_COLOUR(x) == 0x42 || HUD::GET_BLIP_COLOUR(x) == 0x5 || HUD::GET_BLIP_COLOUR(x) == 0x3C || HUD::GET_BLIP_COLOUR(x) == 0x2)
			{
				blipCoords = HUD::GET_BLIP_COORDS(x);
				break;
			}
		}
		for (Blip y = HUD::GET_FIRST_BLIP_INFO_ID(38); HUD::DOES_BLIP_EXIST(y) != 0; y = HUD::GET_NEXT_BLIP_INFO_ID(38))
		{
			if (HUD::GET_BLIP_COLOUR(y) == 0x0)
			{
				blipCoords = HUD::GET_BLIP_COORDS(y);
				break;
			}
		}
		for (Blip z = HUD::GET_FIRST_BLIP_INFO_ID(431); HUD::DOES_BLIP_EXIST(z) != 0; z = HUD::GET_NEXT_BLIP_INFO_ID(431))
		{
			if (HUD::GET_BLIP_COLOUR(z) == 0x3C)
			{
				blipCoords = HUD::GET_BLIP_COORDS(z);
				break;
			}
		}

		return blipCoords;
	}
	void teleportToObjective()
	{
		Vector3 blip = get_mission_objective();
		if (blip.x == 0 && blip.y == 0)
		{
			MenuFunctions::Notify("δ�ҵ������!");
			return;
		}
		Entity e = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID());
		if (PED::IS_PED_IN_ANY_VEHICLE(e, 0))
		{
			e = PED::GET_VEHICLE_PED_IS_USING(e);
		}
		ENTITY::SET_ENTITY_COORDS_NO_OFFSET(e, blip.x, blip.y, blip.z + 0.5f, 0, 0, 1);

	}
	void explodepeds()
	{
		const int ElementAmount = 10;
		const int ArrSize = ElementAmount * 2 + 2;
		Ped* peds = new Ped[ArrSize];
		peds[0] = ElementAmount;
		int PedFound = PED::GET_PED_NEARBY_PEDS(PLAYER::PLAYER_PED_ID(), peds, -1);
		for (int i = 0; i < PedFound; i++)
		{
			int OffsetID = i * 2 + 2;
			//RequestControlOfEntity(peds[OffsetID]);
			if (ENTITY::DOES_ENTITY_EXIST(peds[OffsetID]) && PLAYER::PLAYER_PED_ID() != peds[OffsetID])
			{
				Vector3 pos = ENTITY::GET_ENTITY_COORDS(peds[OffsetID], false);
				FIRE::ADD_EXPLOSION(pos.x, pos.y, pos.z, 0, 1000.f, true, false, 0.f, 0);
			}
		}
		delete peds;
	}
	void ChangeCoords(Vector3 Coords)
	{
		int Handle = PLAYER::PLAYER_PED_ID();
		if (PED::IS_PED_IN_ANY_VEHICLE(Handle, 0))
		{
			ENTITY::SET_ENTITY_COORDS(PED::GET_VEHICLE_PED_IS_IN(Handle, false), Coords.x, Coords.y, Coords.z, 0, 0, 0, 1);
		}
		else
		{
			ENTITY::SET_ENTITY_COORDS(Handle, Coords.x, Coords.y, Coords.z, 0, 0, 0, 1);
		}
	}

	float degToRad(float degs)
	{
		return degs * 3.141592653589793f / 180.f;
	}
	void requestControlOfid(Entity netid)
	{
		int tick = 0;

		while (!NETWORK::NETWORK_HAS_CONTROL_OF_NETWORK_ID(netid) && tick <= 25)
		{
			NETWORK::NETWORK_REQUEST_CONTROL_OF_NETWORK_ID(netid);
			tick++;
		}
	}
	void requestControlOfEnt(Entity entity)
	{
		int tick = 0;
		while (!NETWORK::NETWORK_HAS_CONTROL_OF_ENTITY(entity) && tick <= 25)
		{
			NETWORK::NETWORK_REQUEST_CONTROL_OF_ENTITY(entity);
			tick++;
		}
		if (NETWORK::NETWORK_IS_SESSION_STARTED())
		{
			int netID = NETWORK::NETWORK_GET_NETWORK_ID_FROM_ENTITY(entity);
			requestControlOfid(netID);
			NETWORK::SET_NETWORK_ID_CAN_MIGRATE(netID, 1);
		}
	}
	void RequestControlOfEnt(Entity entity)
	{
		int tick = 0;
		if (!NETWORK::NETWORK_HAS_CONTROL_OF_ENTITY(entity) && tick <= 25)
		{
			NETWORK::NETWORK_REQUEST_CONTROL_OF_ENTITY(entity);
			tick++;
		}
		if (NETWORK::NETWORK_IS_SESSION_STARTED())
		{
			int netID = NETWORK::NETWORK_GET_NETWORK_ID_FROM_ENTITY(entity);

			NETWORK::SET_NETWORK_ID_CAN_MIGRATE(netID, 1);
		}
	}
	void ToggleXenon(int VehID)
	{
		if (g_Vehicle.hasXenon)
		{
			VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
			VEHICLE::TOGGLE_VEHICLE_MOD(VehID, 22, 0);
			g_Vehicle.hasXenon = false;
		}
		else
		{
			VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
			VEHICLE::TOGGLE_VEHICLE_MOD(VehID, 22, 1);
			g_Vehicle.hasXenon = true;
		}
	}
	std::string StringKeyboard() {
		MISC::DISPLAY_ONSCREEN_KEYBOARD(1, "", "", "", "", "", "", 10);
		while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
		if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return 0;
		return MISC::GET_ONSCREEN_KEYBOARD_RESULT();
	}
	int NumberKeyboard() {
		MISC::DISPLAY_ONSCREEN_KEYBOARD(1, "", "", "", "", "", "", 10);
		while (MISC::UPDATE_ONSCREEN_KEYBOARD() == 0) WAIT(0);
		if (!MISC::GET_ONSCREEN_KEYBOARD_RESULT()) return 0;
		return atof(MISC::GET_ONSCREEN_KEYBOARD_RESULT());
	}
	Vehicle last_vehicle{};
	void spawn_vehicle(Hash hash)
	{
		while (!STREAMING::HAS_MODEL_LOADED(hash))
		{
			STREAMING::REQUEST_MODEL(hash);
			WAIT(0);
		}
		auto pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
		*(unsigned short*)hooks.m_model_spawn_bypass = 0x9090;
		Vehicle vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, 0.f, TRUE, FALSE, FALSE);
		*(unsigned short*)hooks.m_model_spawn_bypass = 0x0574;
		WAIT(0);
		STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(hash);
		if (NETWORK::NETWORK_IS_SESSION_STARTED())
		{
			DECORATOR::DECOR_SET_INT(vehicle, "MPBitset", 0);
			ENTITY::_SET_ENTITY_SOMETHING(vehicle, TRUE);
			auto networkId = NETWORK::VEH_TO_NET(vehicle);
			if (NETWORK::NETWORK_GET_ENTITY_IS_NETWORKED(vehicle))
				NETWORK::SET_NETWORK_ID_EXISTS_ON_ALL_MACHINES(networkId, true);
			VEHICLE::SET_VEHICLE_IS_STOLEN(vehicle, FALSE);
		}
		last_vehicle = vehicle;
		if (g_Vehicle.setvehgodmode)
		{
			ENTITY::SET_ENTITY_INVINCIBLE(vehicle, true);
			VEHICLE::SET_VEHICLE_WHEELS_CAN_BREAK(vehicle, false);
		}
		if (g_Vehicle.setpedintocar)
		{
			PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), vehicle, -1);
		}
		if (g_Vehicle.deletelastcar)
		{
			Vehicle veh = VEHICLE::GET_LAST_DRIVEN_VEHICLE();
			VEHICLE::DELETE_VEHICLE(&veh);
		}
		if (g_Vehicle.setcarmax)
		{
			int vehid = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
			MaxUpgrades(vehid);
		}

	}
	int spawn_vehicles(Hash hash)
	{
		if (STREAMING::IS_MODEL_VALID(hash))
		{
			STREAMING::REQUEST_MODEL(hash);
			while (!STREAMING::HAS_MODEL_LOADED(hash))
			{
				WAIT(0);
			}

			Ped ped = PLAYER::PLAYER_PED_ID();
			Vector3 pos = ENTITY::GET_ENTITY_COORDS(ped, true);
			float forward = 5.f;
			float heading = ENTITY::GET_ENTITY_HEADING(ped);
			float xVector = forward * sin(heading * 3.141592653589793f / 180.f) * -1.f;
			float yVector = forward * cos(heading * 3.141592653589793f / 180.f);
			*(unsigned short*)hooks.m_model_spawn_bypass = 0x9090;
			Vehicle vehicle = VEHICLE::CREATE_VEHICLE(hash, pos.x + xVector, pos.y + yVector, pos.z, 0.f, TRUE, FALSE, FALSE);
			*(unsigned short*)hooks.m_model_spawn_bypass = 0x0574;
			last_vehicle = vehicle;

			STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(hash);

			if (g_Vehicle.setvehgodmode)
			{
				ENTITY::SET_ENTITY_INVINCIBLE(vehicle, true);
				VEHICLE::SET_VEHICLE_WHEELS_CAN_BREAK(vehicle, false);
			}
			if (g_Vehicle.setpedintocar)
			{
				PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), vehicle, -1);
			}
			if (g_Vehicle.deletelastcar)
			{
				Vehicle veh = VEHICLE::GET_LAST_DRIVEN_VEHICLE();
				VEHICLE::DELETE_VEHICLE(&veh);
			}
			if (g_Vehicle.setcarmax)
			{
				int vehid = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				MaxUpgrades(vehid);
			}
			return vehicle;
		}
		return 0;
	}
	bool kickplayer(int selectedPlayer, int type)
	{
		if (type == 1)
		{
			DWORD64 args[2] = { 998716537, selectedPlayer };
			SCRIPT::TRIGGER_SCRIPT_EVENT(1, args, 2, 1 << selectedPlayer);
		}
		else if (type == 2)
		{
			DWORD64 args[4] = { 163598572, selectedPlayer };
			SCRIPT::TRIGGER_SCRIPT_EVENT(1, args, 4, 1 << selectedPlayer);
		}
		else if (type == 3)//������
		{
			NETWORK::NETWORK_SESSION_KICK_PLAYER(selectedPlayer);
		}
		else if (type == 4)//off-host kick
		{
			DWORD64 args[2] = { 1152017566 ,selectedPlayer };
			SCRIPT::TRIGGER_SCRIPT_EVENT(1, args, 2, 1 << selectedPlayer);
		}
		else if (type == 5)
		{
			DWORD64 args[2] = { 297770348 ,selectedPlayer };
			SCRIPT::TRIGGER_SCRIPT_EVENT(1, args, 2, 1 << selectedPlayer);
		}
		else if (type == 6)
		{
			DWORD64 args[2] = { -1246838892 ,selectedPlayer };
			SCRIPT::TRIGGER_SCRIPT_EVENT(1, args, 2, 1 << selectedPlayer);
		}
		else if (type == 7)
		{
			DWORD64 args[2] = { -2120750352 ,selectedPlayer };
			SCRIPT::TRIGGER_SCRIPT_EVENT(1, args, 2, 1 << selectedPlayer);
		}
		return true;
	}
	void ExplosionPlayer(Ped targetPlayer, int damage, int type, int cam, bool Invisible, bool Audio) {
		Vector3 coords = ENTITY::GET_ENTITY_COORDS(targetPlayer, true);
		coords.z -= 1;
		FIRE::ADD_EXPLOSION(coords.x, coords.y, coords.z, type, (float)damage, Audio, Invisible, (float)cam);
	}
	void RequestNetworkControlOfEntity(Entity entity)
	{
		int EntityTick = 0;
		int IdTick = 0;
		while (!NETWORK::NETWORK_HAS_CONTROL_OF_ENTITY(entity) && EntityTick <= 25)
		{
			NETWORK::NETWORK_REQUEST_CONTROL_OF_ENTITY(entity);
			EntityTick++;
		}
		if (NETWORK::NETWORK_IS_SESSION_STARTED())
		{
			int netID = NETWORK::NETWORK_GET_NETWORK_ID_FROM_ENTITY(entity);
			while (!NETWORK::NETWORK_HAS_CONTROL_OF_NETWORK_ID(netID) && IdTick <= 25)
			{
				NETWORK::NETWORK_REQUEST_CONTROL_OF_NETWORK_ID(netID);
				IdTick++;
			}
			NETWORK::SET_NETWORK_ID_CAN_MIGRATE(netID, true);
		}
	}
	void unlockcloth()
	{
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_FEET_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_HAIR"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_HAIR_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_HAIR_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_HAIR_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_HAIR_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_HAIR_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_HAIR_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_HAIR_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_JBIB"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_JBIB_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_JBIB_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_JBIB_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_JBIB_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_JBIB_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_JBIB_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_JBIB_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_LEGS"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_LEGS_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_LEGS_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_LEGS_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_LEGS_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_LEGS_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_LEGS_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_LEGS_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_FEET"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_FEET_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_FEET_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_FEET_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_FEET_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_FEET_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_FEET_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_FEET_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_BERD"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_BERD_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_BERD_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_BERD_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_BERD_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_BERD_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_BERD_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_BERD_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_PROPS"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_PROPS_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_PROPS_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_PROPS_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_PROPS_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_PROPS_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_PROPS_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_PROPS_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_PROPS_8"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_PROPS_9"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_PROPS_10"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_OUTFIT"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_HAIR"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_HAIR_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_HAIR_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_HAIR_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_HAIR_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_HAIR_5"), -1, 1);;
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_HAIR_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_HAIR_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_JBIB"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_JBIB_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_JBIB_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_JBIB_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_JBIB_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_JBIB_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_JBIB_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_JBIB_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_LEGS"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_LEGS_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_LEGS_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_LEGS_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_LEGS_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_LEGS_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_LEGS_6"), -1, 1);;
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_LEGS_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_FEET"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_FEET_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_FEET_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_FEET_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_FEET_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_FEET_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_FEET_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_FEET_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_BERD"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_BERD_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_BERD_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_BERD_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_BERD_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_BERD_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_BERD_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_BERD_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_PROPS"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_PROPS_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_PROPS_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_PROPS_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_PROPS_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_PROPS_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_PROPS_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_PROPS_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_PROPS_8"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_PROPS_9"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_PROPS_10"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_OUTFIT"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_TORSO"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_SPECIAL"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_SPECIAL_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_SPECIAL_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_SPECIAL_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_SPECIAL_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_SPECIAL_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_SPECIAL_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_SPECIAL_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_SPECIAL2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_SPECIAL2_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_DECL"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_TEETH"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_TEETH_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_TEETH_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_TORSO"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_SPECIAL"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_SPECIAL_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_SPECIAL_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_SPECIAL_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_SPECIAL_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_SPECIAL_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_SPECIAL_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_SPECIAL_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_SPECIAL2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_SPECIAL2_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_DECL"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_TEETH"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_TEETH_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_ACQUIRED_TEETH_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_0"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_8"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_9"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_10"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_11"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_12"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_13"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_14"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_15"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_16"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_17"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_18"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_19"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_21"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_22"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_23"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_24"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_24"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_25"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_26"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_27"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_28"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_29"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_30"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_31"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_32"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_33"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_34"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_35"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_36"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_37"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_38"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_39"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DLC_APPAREL_ACQUIRED_40"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_ADMIN_CLOTHES_GV_BS_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_ADMIN_CLOTHES_GV_BS_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_ADMIN_CLOTHES_GV_BS_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_ADMIN_CLOTHES_GV_BS_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_ADMIN_CLOTHES_GV_BS_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_ADMIN_CLOTHES_GV_BS_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_ADMIN_CLOTHES_GV_BS_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_ADMIN_CLOTHES_GV_BS_8"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_ADMIN_CLOTHES_GV_BS_9"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_ADMIN_CLOTHES_GV_BS_10"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_ADMIN_CLOTHES_GV_BS_11"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_ADMIN_CLOTHES_GV_BS_12"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_ADMIN_CLOTHES_GV_BS_13"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_ADMIN_CLOTHES_GV_BS_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_ADMIN_CLOTHES_GV_BS_10"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_ADMIN_CLOTHES_GV_BS_11"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_ADMIN_CLOTHES_GV_BS_12"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_HAIR"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_HAIR_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_HAIR_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_HAIR_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_HAIR_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_HAIR_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_HAIR_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CLTHS_AVAILABLE_HAIR_7"), -1, 1);


		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_FEET_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_HAIR"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_HAIR_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_HAIR_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_HAIR_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_HAIR_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_HAIR_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_HAIR_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_HAIR_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_JBIB"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_JBIB_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_JBIB_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_JBIB_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_JBIB_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_JBIB_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_JBIB_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_JBIB_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_LEGS"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_LEGS_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_LEGS_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_LEGS_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_LEGS_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_LEGS_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_LEGS_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_LEGS_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_FEET"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_FEET_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_FEET_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_FEET_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_FEET_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_FEET_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_FEET_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_FEET_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_BERD"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_BERD_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_BERD_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_BERD_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_BERD_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_BERD_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_BERD_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_BERD_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_PROPS"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_PROPS_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_PROPS_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_PROPS_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_PROPS_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_PROPS_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_PROPS_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_PROPS_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_PROPS_8"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_PROPS_9"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_PROPS_10"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_OUTFIT"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_HAIR"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_HAIR_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_HAIR_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_HAIR_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_HAIR_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_HAIR_5"), -1, 1);;
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_HAIR_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_HAIR_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_JBIB"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_JBIB_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_JBIB_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_JBIB_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_JBIB_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_JBIB_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_JBIB_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_JBIB_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_LEGS"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_LEGS_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_LEGS_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_LEGS_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_LEGS_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_LEGS_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_LEGS_6"), -1, 1);;
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_LEGS_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_FEET"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_FEET_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_FEET_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_FEET_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_FEET_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_FEET_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_FEET_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_FEET_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_BERD"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_BERD_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_BERD_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_BERD_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_BERD_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_BERD_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_BERD_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_BERD_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_PROPS"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_PROPS_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_PROPS_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_PROPS_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_PROPS_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_PROPS_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_PROPS_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_PROPS_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_PROPS_8"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_PROPS_9"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_PROPS_10"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_OUTFIT"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_TORSO"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_SPECIAL"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_SPECIAL_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_SPECIAL_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_SPECIAL_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_SPECIAL_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_SPECIAL_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_SPECIAL_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_SPECIAL_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_SPECIAL2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_SPECIAL2_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_DECL"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_TEETH"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_TEETH_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_TEETH_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_TORSO"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_SPECIAL"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_SPECIAL_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_SPECIAL_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_SPECIAL_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_SPECIAL_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_SPECIAL_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_SPECIAL_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_SPECIAL_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_SPECIAL2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_SPECIAL2_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_DECL"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_TEETH"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_TEETH_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_ACQUIRED_TEETH_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_0"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_8"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_9"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_10"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_11"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_12"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_13"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_14"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_15"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_16"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_17"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_18"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_19"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_21"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_22"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_23"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_24"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_24"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_25"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_26"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_27"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_28"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_29"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_30"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_31"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_32"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_33"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_34"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_35"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_36"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_37"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_38"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_39"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DLC_APPAREL_ACQUIRED_40"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_ADMIN_CLOTHES_GV_BS_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_ADMIN_CLOTHES_GV_BS_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_ADMIN_CLOTHES_GV_BS_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_ADMIN_CLOTHES_GV_BS_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_ADMIN_CLOTHES_GV_BS_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_ADMIN_CLOTHES_GV_BS_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_ADMIN_CLOTHES_GV_BS_7"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_ADMIN_CLOTHES_GV_BS_8"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_ADMIN_CLOTHES_GV_BS_9"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_ADMIN_CLOTHES_GV_BS_10"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_ADMIN_CLOTHES_GV_BS_11"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_ADMIN_CLOTHES_GV_BS_12"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_ADMIN_CLOTHES_GV_BS_13"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_ADMIN_CLOTHES_GV_BS_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_ADMIN_CLOTHES_GV_BS_10"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_ADMIN_CLOTHES_GV_BS_11"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_ADMIN_CLOTHES_GV_BS_12"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_HAIR"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_HAIR_1"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_HAIR_2"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_HAIR_3"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_HAIR_4"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_HAIR_5"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_HAIR_6"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CLTHS_AVAILABLE_HAIR_7"), -1, 1);
	}
	void unlockTattoo()
	{
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_DM_WINS"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_TDM_MVP"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_DM_TOTALKILLS"), 500, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMATTGANGHQ"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FMBBETWIN"), 50000, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMWINEVERYGAMEMODE"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMRACEWORLDRECHOLDER"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMFULLYMODDEDCAR"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMMOSTKILLSSURVIVE"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMKILL3ANDWINGTARACE"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FMKILLBOUNTY"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FMREVENGEKILLSDM"), 50, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMKILLSTREAKSDM"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_HOLD_UP_SHOPS"), 20, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_LAPDANCES"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_SECURITY_CARS_ROBBED"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_RACES_WON"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_CAR_BOMBS_ENEMY_KILLS"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_PLAYER_HEADSHOTS"), 500, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DB_PLAYER_KILLS"), 1000, 1);

		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_DM_WINS"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_TDM_MVP"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_DM_TOTALKILLS"), 500, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMATTGANGHQ"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FMBBETWIN"), 50000, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMWINEVERYGAMEMODE"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMRACEWORLDRECHOLDER"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMFULLYMODDEDCAR"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMMOSTKILLSSURVIVE"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMKILL3ANDWINGTARACE"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FMKILLBOUNTY"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FMREVENGEKILLSDM"), 50, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMKILLSTREAKSDM"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_HOLD_UP_SHOPS"), 20, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_LAPDANCES"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_SECURITY_CARS_ROBBED"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_RACES_WON"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_CAR_BOMBS_ENEMY_KILLS"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_PLAYER_HEADSHOTS"), 500, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DB_PLAYER_KILLS"), 1000, 1);
	}
	void unlockTrophies()
	{
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_PLAYER_HEADSHOTS"), 500, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_PISTOL_ENEMY_KILLS"), 500, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_SAWNOFF_ENEMY_KILLS"), 500, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_MICROSMG_ENEMY_KILLS"), 500, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_SNIPERRFL_ENEMY_KILLS"), 100, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_UNARMED_ENEMY_KILLS"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_STKYBMB_ENEMY_KILLS"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_GRENADE_ENEMY_KILLS"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_RPG_ENEMY_KILLS"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CARS_EXPLODED"), 500, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_5STAR_WANTED_AVOIDANCE"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_CAR_BOMBS_ENEMY_KILLS"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_CARS_EXPORTED"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_PASS_DB_PLAYER_KILLS"), 100, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_DM_WINS"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_GOLF_WON"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_GTA_RACES_WON"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_SHOOTRANG_CT_WON"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_SHOOTRANG_RT_WON"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_SHOOTRANG_TG_WON"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_TDM_WINS"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_TENNIS_WON"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_MOST_SPINS_IN_ONE_JUMP"), 5, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MPPLY_AWD_FM_CR_DM_MADE"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FMHORDWAVESSURVIVE"), 10, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_HOLD_UP_SHOPS"), 20, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_ASLTRIFLE_ENEMY_KILLS"), 500, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_MG_ENEMY_KILLS"), 500, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_LAPDANCES"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_MOST_ARM_WRESTLING_WINS"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_NO_HAIRCUTS"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_RACES_WON"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_SECURITY_CARS_ROBBED"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_VEHICLES_JACKEDR"), 500, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_MOST_FLIPS_IN_ONE_JUMP"), 5, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_WIN_AT_DARTS"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_PASSENGERTIME"), 4, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_TIME_IN_HELICOPTER"), 4, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_DM_3KILLSAMEGUY"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_DM_KILLSTREAK"), 100, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_DM_STOLENKILL"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_DM_TOTALKILLS"), 500, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_GOLF_BIRDIES"), 25, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FM_GOLF_HOLE_IN_1"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_RACE_LAST_FIRST"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_RACES_FASTEST_LAP"), 25, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FM_SHOOTRANG_GRAN_WON"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_TDM_MVP"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_TENNIS_ACE"), 25, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FM_TENNIS_STASETWIN"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FM6DARTCHKOUT"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMATTGANGHQ"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_PARACHUTE_JUMPS_20M"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_PARACHUTE_JUMPS_50M"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AIR_LAUNCHES_OVER_40M"), 25, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_BUY_EVERY_GUN"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMWINEVERYGAMEMODE"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FMDRIVEWITHOUTCRASH"), 255, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FMCRATEDROPS"), 25, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FM25DIFFERENTDM"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FM_TENNIS_5_SET_WINS"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MPPLY_AWD_FM_CR_PLAYED_BY_PEEP"), 100, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MPPLY_AWD_FM_CR_RACES_MADE"), 25, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FM25DIFFERENTRACES"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FM25DIFITEMSCLOTHES"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMFULLYMODDEDCAR"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FMKILLBOUNTY"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_KILLS_PLAYERS"), 1000, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMPICKUPDLCCRATE1ST"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FMSHOOTDOWNCOPHELI"), 25, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMKILL3ANDWINGTARACE"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMKILLSTREAKSDM"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMMOSTKILLSGANGHIDE"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMMOSTKILLSSURVIVE"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMRACEWORLDRECHOLDER"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FMRALLYWONDRIVE"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FMRALLYWONNAV"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FMREVENGEKILLSDM"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FMWINAIRRACE"), 25, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMWINCUSTOMRACE"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FMWINRACETOPOINTS"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FMWINSEARACE"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FMBASEJMP"), 25, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_MP0_AWD_FMWINALLRACEMODES"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMTATTOOALLBODYPARTS"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CHAR_WANTED_LEVEL_TIME5STAR"), 2147483647, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MPPLY_HEIST_ACH_TRACKER"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CHAR_FM_VEHICLE_1_UNLCK"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CHAR_FM_VEHICLE_2_UNLCK"), -1, 1);

		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_PLAYER_HEADSHOTS"), 500, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_PISTOL_ENEMY_KILLS"), 500, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_SAWNOFF_ENEMY_KILLS"), 500, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_MICROSMG_ENEMY_KILLS"), 500, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_SNIPERRFL_ENEMY_KILLS"), 100, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_UNARMED_ENEMY_KILLS"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_STKYBMB_ENEMY_KILLS"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_GRENADE_ENEMY_KILLS"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_RPG_ENEMY_KILLS"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CARS_EXPLODED"), 500, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_5STAR_WANTED_AVOIDANCE"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_CAR_BOMBS_ENEMY_KILLS"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_CARS_EXPORTED"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_PASS_DB_PLAYER_KILLS"), 100, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_DM_WINS"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_GOLF_WON"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_GTA_RACES_WON"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_SHOOTRANG_CT_WON"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_SHOOTRANG_RT_WON"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_SHOOTRANG_TG_WON"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_TDM_WINS"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_TENNIS_WON"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_MOST_SPINS_IN_ONE_JUMP"), 5, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MPPLY_AWD_FM_CR_DM_MADE"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FMHORDWAVESSURVIVE"), 10, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_HOLD_UP_SHOPS"), 20, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_ASLTRIFLE_ENEMY_KILLS"), 500, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_MG_ENEMY_KILLS"), 500, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_LAPDANCES"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_MOST_ARM_WRESTLING_WINS"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_NO_HAIRCUTS"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_RACES_WON"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_SECURITY_CARS_ROBBED"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_VEHICLES_JACKEDR"), 500, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_MOST_FLIPS_IN_ONE_JUMP"), 5, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_WIN_AT_DARTS"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_PASSENGERTIME"), 4, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_TIME_IN_HELICOPTER"), 4, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_DM_3KILLSAMEGUY"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_DM_KILLSTREAK"), 100, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_DM_STOLENKILL"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_DM_TOTALKILLS"), 500, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_GOLF_BIRDIES"), 25, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FM_GOLF_HOLE_IN_1"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_RACE_LAST_FIRST"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_RACES_FASTEST_LAP"), 25, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FM_SHOOTRANG_GRAN_WON"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_TDM_MVP"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_TENNIS_ACE"), 25, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FM_TENNIS_STASETWIN"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FM6DARTCHKOUT"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMATTGANGHQ"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_PARACHUTE_JUMPS_20M"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_PARACHUTE_JUMPS_50M"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AIR_LAUNCHES_OVER_40M"), 25, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_BUY_EVERY_GUN"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMWINEVERYGAMEMODE"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FMDRIVEWITHOUTCRASH"), 255, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FMCRATEDROPS"), 25, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FM25DIFFERENTDM"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FM_TENNIS_5_SET_WINS"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MPPLY_AWD_FM_CR_PLAYED_BY_PEEP"), 100, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MPPLY_AWD_FM_CR_RACES_MADE"), 25, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FM25DIFFERENTRACES"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FM25DIFITEMSCLOTHES"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMFULLYMODDEDCAR"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FMKILLBOUNTY"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_KILLS_PLAYERS"), 1000, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMPICKUPDLCCRATE1ST"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FMSHOOTDOWNCOPHELI"), 25, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMKILL3ANDWINGTARACE"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMKILLSTREAKSDM"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMMOSTKILLSGANGHIDE"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMMOSTKILLSSURVIVE"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMRACEWORLDRECHOLDER"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FMRALLYWONDRIVE"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FMRALLYWONNAV"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FMREVENGEKILLSDM"), 50, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FMWINAIRRACE"), 25, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMWINCUSTOMRACE"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FMWINRACETOPOINTS"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FMWINSEARACE"), 25, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FMBASEJMP"), 25, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_MP1_AWD_FMWINALLRACEMODES"), 1, 1);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMTATTOOALLBODYPARTS"), 1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CHAR_WANTED_LEVEL_TIME5STAR"), 2147483647, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MPPLY_HEIST_ACH_TRACKER"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CHAR_FM_VEHICLE_1_UNLCK"), -1, 1);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CHAR_FM_VEHICLE_2_UNLCK"), -1, 1);
	}
	void unlockLSCMOD()
	{
		if (ENTITY::DOES_ENTITY_EXIST(PLAYER::PLAYER_PED_ID())) {
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CHAR_FM_CARMOD_1_UNLCK"), -1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CHAR_FM_CARMOD_2_UNLCK"), -1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CHAR_FM_CARMOD_3_UNLCK"), -1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CHAR_FM_CARMOD_4_UNLCK"), -1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CHAR_FM_CARMOD_5_UNLCK"), -1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CHAR_FM_CARMOD_6_UNLCK"), -1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CHAR_FM_CARMOD_7_UNLCK"), -1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FMRALLYWONDRIVE"), 1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FMRALLYWONNAV"), 1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FMWINSEARACE"), 1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FMWINAIRRACE"), 1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_NUMBER_TURBO_STARTS_IN_RACE"), 50, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_USJS_COMPLETED"), 50, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_RACES_FASTEST_LAP"), 50, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_NUMBER_SLIPSTREAMS_IN_RACE"), 100, 1);

			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CHAR_FM_CARMOD_1_UNLCK"), -1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CHAR_FM_CARMOD_2_UNLCK"), -1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CHAR_FM_CARMOD_3_UNLCK"), -1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CHAR_FM_CARMOD_4_UNLCK"), -1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CHAR_FM_CARMOD_5_UNLCK"), -1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CHAR_FM_CARMOD_6_UNLCK"), -1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CHAR_FM_CARMOD_7_UNLCK"), -1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FMRALLYWONDRIVE"), 1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FMRALLYWONNAV"), 1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FMWINSEARACE"), 1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FMWINAIRRACE"), 1, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_NUMBER_TURBO_STARTS_IN_RACE"), 50, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_USJS_COMPLETED"), 50, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_RACES_FASTEST_LAP"), 50, 1);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_NUMBER_SLIPSTREAMS_IN_RACE"), 100, 1);
		}
	}
	void unlockLSC()
	{
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMRACEWORLDRECHOLDER"), 1, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_ENEMYDRIVEBYKILLS"), 600, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_USJS_COMPLETED"), 50, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_USJS_FOUND"), 50, 0);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMWINALLRACEMODES"), 1, 0);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMWINEVERYGAMEMODE"), 1, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_DB_PLAYER_KILLS"), 1000, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_KILLS_PLAYERS"), 1000, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FMHORDWAVESSURVIVE"), 21, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_CAR_BOMBS_ENEMY_KILLS"), 25, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_TDM_MVP"), 60, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_HOLD_UP_SHOPS"), 20, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_RACES_WON"), 101, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_NO_ARMWRESTLING_WINS"), 21, 0);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMATTGANGHQ"), 1, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FMBBETWIN"), 50000, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_DM_WINS"), 51, 0);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP0_AWD_FMFULLYMODDEDCAR"), 1, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_DM_TOTALKILLS"), 500, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_MPPLY_DM_TOTAL_DEATHS"), 412, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_MPPLY_TIMES_FINISH_DM_TOP_3"), 36, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_PLAYER_HEADSHOTS"), 623, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_DM_WINS"), 63, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_TDM_WINS"), 13, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_GTA_RACES_WON"), 12, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_GOLF_WON"), 2, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_SHOOTRANG_TG_WON"), 2, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_SHOOTRANG_RT_WON"), 2, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_SHOOTRANG_CT_WON"), 2, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_SHOOTRANG_GRAN_WON"), 2, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_FM_TENNIS_WON"), 2, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_MPPLY_TENNIS_MATCHES_WON"), 2, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_MPPLY_TOTAL_TDEATHMATCH_WON"), 63, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_MPPLY_TOTAL_RACES_WON"), 101, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_MPPLY_TOTAL_DEATHMATCH_LOST"), 23, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_MPPLY_TOTAL_RACES_LOST"), 36, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_25_KILLS_STICKYBOMBS"), 50, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_50_KILLS_GRENADES"), 50, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_GRENADE_ENEMY_KILLS "), 50, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_AWD_20_KILLS_MELEE"), 50, 0);

		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMRACEWORLDRECHOLDER"), 1, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_ENEMYDRIVEBYKILLS"), 600, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_USJS_COMPLETED"), 50, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_USJS_FOUND"), 50, 0);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMWINALLRACEMODES"), 1, 0);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMWINEVERYGAMEMODE"), 1, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_DB_PLAYER_KILLS"), 1000, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_KILLS_PLAYERS"), 1000, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FMHORDWAVESSURVIVE"), 21, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_CAR_BOMBS_ENEMY_KILLS"), 25, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_TDM_MVP"), 60, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_HOLD_UP_SHOPS"), 20, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_RACES_WON"), 101, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_NO_ARMWRESTLING_WINS"), 21, 0);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMATTGANGHQ"), 1, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FMBBETWIN"), 50000, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_DM_WINS"), 51, 0);
		STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY("MP1_AWD_FMFULLYMODDEDCAR"), 1, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_DM_TOTALKILLS"), 500, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_MPPLY_DM_TOTAL_DEATHS"), 412, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_MPPLY_TIMES_FINISH_DM_TOP_3"), 36, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_PLAYER_HEADSHOTS"), 623, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_DM_WINS"), 63, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_TDM_WINS"), 13, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_GTA_RACES_WON"), 12, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_GOLF_WON"), 2, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_SHOOTRANG_TG_WON"), 2, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_SHOOTRANG_RT_WON"), 2, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_SHOOTRANG_CT_WON"), 2, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_SHOOTRANG_GRAN_WON"), 2, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_FM_TENNIS_WON"), 2, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_MPPLY_TENNIS_MATCHES_WON"), 2, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_MPPLY_TOTAL_TDEATHMATCH_WON"), 63, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_MPPLY_TOTAL_RACES_WON"), 101, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_MPPLY_TOTAL_DEATHMATCH_LOST"), 23, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_MPPLY_TOTAL_RACES_LOST"), 36, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_25_KILLS_STICKYBOMBS"), 50, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_50_KILLS_GRENADES"), 50, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_GRENADE_ENEMY_KILLS "), 50, 0);
		STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_AWD_20_KILLS_MELEE"), 50, 0);
	}
}