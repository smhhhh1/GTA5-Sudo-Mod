#pragma once
#include "../../stdafx.h"

void Other::UpdateLoop()
{

}