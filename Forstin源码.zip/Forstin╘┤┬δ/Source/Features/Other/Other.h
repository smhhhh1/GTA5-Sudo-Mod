#pragma once 

namespace Other
{
	void UpdateLoop();
}