#pragma once
#include"stdafx.h"
namespace mod_vehicle
{
	extern std::vector<std::string> big_ini_vehicle_list;
	extern std::vector<std::string> small_ini_vehicle_list;
	extern std::vector<std::string> xml_vehicle_list;
	extern std::vector<Ped> last_ped;
	extern std::vector<Vehicle> last_vehicle;
	extern std::vector<Object> last_object;


	void find_big_ini_vehicle();
	void find_small_ini_vehicle();
	bool create_ini_vehicle(const char* vehiclename);

	void find_xml_vehicle();
	void create_xml_vehicle(const char* xml);
}