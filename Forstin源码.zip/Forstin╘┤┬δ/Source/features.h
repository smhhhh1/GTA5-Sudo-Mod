#pragma once
#include"stdafx.h"
namespace Features
{
	void LocalLoop();
	void TeleportLoop();
	void VehicleLoop();
	void WeaponLoop();
	void Plistsloop();
	void Sessionloop();
	void WorldLoop();
	void MiscLoop();
	void UnlockLoop();
	void RecoveryLoop();
	void TaskLoop();
	void SettingsLoop();
}

class ms_Local//����
{
public:
	bool GodMode = false;
	bool noclipv1 = false;
	bool noclipv2 = false;
	bool invisible = false;
	bool superjump = false;
	bool superrun = false;
	bool noragdoll = false;
	bool pengci = false;
	bool FreeCam = false;
	bool superswim = false;
	bool firebreath = false;
	bool superman = false;
	bool tinyplayer = false;
	bool isSlideRun = false;
	bool extremejump = false;
	bool freecambool = false;
	bool neverwanted = false;
	bool walkonwater = false;
	bool chixuranshao = false;
	bool gglow = false;
	bool JibBool = false;
	bool JiBool = false;
	bool zhuanquan = false;

	int tongjidengji = 0;
	int bankval = 0;
	int Face_ = 0;
	int Glasses_ = 0;
	int Ears_ = 0;
	int Mask_ = 0;
	int Hair_ = 0;
	int Torso_ = 0;
	int Legs_ = 0;
	int Hands_ = 0;
	int Shoes_ = 0;
	int Watches_ = 0;
	int Special1_ = 0;
	int Special2_ = 0;
	int Special3_ = 0;
	int Texture_ = 0;
	int Torso2_ = 0;
};
inline ms_Local g_Local;

class m_Vehicle//�ؾ�
{
public:
	bool vehiclegodmode = false;
	bool driveonwater = false;
	bool vehicleboost = false;
	bool anquandai = false;
	bool invisiblecar = false;
	bool flycar = false;
	bool flycarv2 = false;
	bool rainbowcar = false;
	bool rainbowneno = false;
	bool rainbowsmoke = false;
	bool enginealwayson = false;
	bool fixcarloop = false;
	bool setcarmax = false;
	bool setvehgodmode = false;
	bool deletelastcar = false;
	bool setpedintocar = false;
	bool bulletProofTyres = false;
	bool xianxiatichu = false;

	int zuoweihao = 0;

	float aispeed = 40.f;
	//�ĳ���
	bool hasXenon = true;
	bool hasNeons = true;
	int VehID;
	int Spoilers_ = 0;
	int Tint_ = 0;
	int Interior_ = 0;
	int Grill_ = 0;
	int Exhaust_ = 0;
	int Skirts_ = 0;
	int Suspension_ = 0;
	int Hoods_ = 0;
	int Bumpers_ = 0;
	int Transmission_ = 0;
	int Brakes_ = 0;
	int Armor_ = 0;
	int Colour_ = 0;
	int Prim_ = 0;
	int Sec_ = 0;
	int Red_ = 0;
	int Green_ = 0;
	int Blue_ = 0;
	bool rdev;
	int horns = 0;
};
inline m_Vehicle g_Vehicle;

class m_Weapon//����
{
public:
	bool explosiveammo = false;
	bool rapidfire = false;
	bool unlimitedammo = false;
	bool oneshoot = false;
	bool deatheye = false;

	bool kickgun = false;
	bool xiaochouchuxian = false;
	bool chaopiao = false;
	bool xingxing = false;
	bool yanhua = false;
	bool waixingrenwajie = false;
	bool waixingrenchuansong = false;
	bool kachechongzhuang = false;
	bool jujiyingxiang = false;
	bool shuihuafeijian = false;

	bool boxgun = false;
	bool Forstingun = false;
	bool Forstin2gun = false;
	bool containergun = false;
	bool containergun2 = false;
	bool containergun3 = false;
	bool lampgun = false;

	bool zimiaonpc = false;
	bool zimiaowanjia = false;

	bool zaijuqiang = false;
	bool tankeqiang = false;
	bool teleportgun = false;
	bool deletegun = false;
	bool airstrikegun = false;
	bool fireshoot = false;
	bool watershoot = false;
	bool fireworkammo = false;
	bool rainbowgun = false;
	bool firegun = false;
	bool smokegun = false;
	bool grvgun = false;
	bool rocketgun = false;
	bool RPGgun = false;
	bool toucheqiang = false;
	bool xinxiqiang = false;
	bool jiaqiandaiqiang = false;
};
inline m_Weapon g_Weapon;

class m_Teleport//����
{
public:
	bool autoteleport = false;
};
inline m_Teleport g_Teleport;

class m_Task//����
{
public:
	bool daoyuxianjin = false;
	bool daoyuhuangjin = false;
	bool daoyudama = false;
	bool daoyukekaying = false;
	bool daoyuhuazuo = false;
	bool gaichepushouru = false;

	bool quanfushouru = false;
	bool quanfuzhiwensuo = false;
	bool quanfuzuankong = false;

	bool tpyshouru = false;
	bool tpyzhiwensuo = false;
	bool fenhongbaifenbi = false;

	bool mrzhiwensuo = false;

	bool swsshouru = false;
	bool swscisha = false;
	bool swsanbao = false;
};
inline m_Task g_Task;

class m_Plists//���
{
public:
	bool spectate = false;
	bool freezeplayer = false;
	bool fireloop = false;
	bool waterloop = false;
	bool explosionloop = false;
	bool FPSdrop = false;
};
inline m_Plists g_Plists;

class m_Session //ս��
{
public:
	bool frashrun = false;
	bool siwangshexian = false;
	bool elingqishi = false;
	bool ESPname = false;
	bool espbox = false;
	bool espline = false;
	bool pingbiguanggao = false;
	bool tishiguanggaoji = false;
	bool afk = false;
	bool luodi = true;
	bool qingqiujiaru = false;
	bool baobiaogod = false;
	bool bMiscJoinRid = false;
	bool zhengfa = false;

	bool antikick = false;
	bool antiinvite = false;
	bool antigiveweapon = false;
	bool antifreeze = false;
	bool antifire = false;
	bool antiexplosion = false;
	bool antiPTFX = false;
	bool antistar = false;
	bool antiremoveweapon = false;
	bool antirequsetcontrol = false;
	bool blockallnetworkevents = false;
	bool antireport = false;
	bool antistat = false;
	bool antidrop = false;
	bool antivotekick = false;
	bool antiattachment = false;
	bool anticage = false;
	bool blockobjCrash = false;
	bool blockPedCrash = false;
	bool blockvehCrash = false;
	bool SECrashprotex = false;
	bool nonhostkickprotex = false;
	bool antiSPKick = false;
	bool anticeokick = false;
	bool ceo_events = false;
	bool bannerprotex = false;
	bool blackscreen = false;
	bool Transaction_Error = false;
	bool antiapartmenttp = false;
	bool antiremotebounty = false;
	bool antiremotevehkick = false;
	bool load_screen = false;
	bool antiremoteforcemission = false;
	bool blockallentity = false;

	int baobiaowuqihash = 0;
	int mubiaorid = 0;
	const char* baobiaomoxing = "0";

};
inline m_Session g_Session;

class m_World//����
{
public:
	bool gravity = false;
	bool explodnearcar = false;
	bool boostnearcar = false;
	bool deletenearcar = false;
	bool explodnearped = false;
	bool killpeds = false;
	bool deleteNPC = false;
	int timeer = 0;
	int minute = 0;
	int second = 0;
};
inline m_World g_World;

class m_Misc//����
{
public:
	bool disablephone = false;
	bool hidehud = false;
	bool displayfps = false;
	bool displaycoord = false;
	bool aimcross = false;
	bool SpeedoBool = true;
	bool ditudaxiao = false;
};
inline m_Misc g_Misc;

class m_Unlock//�ָ�
{
public:
	bool shengdanjie = false;
	bool duliri = false;
};
inline m_Unlock g_Unlock;

class m_Recovery//�ָ�
{
public:
	bool tianjipaotuikuan = false;
	bool xunhuanshua = false;
	bool qiwuxunhuanshua = false;
	bool jiechulaohuji = false;
};
inline m_Recovery g_Recovery;

class m_Settings//����
{
public:
	bool chuansongdaohangdian = false;
	bool chuansongmubiaodian = false;
	bool chuansongdaohujing = false;
	bool xiangqianchuansong = false;
	bool delzisha = false;
	bool endxiezai = true;
};
inline m_Settings g_Settings;

class m_Bianliang//����
{
public:
	bool xinshou = false;
	std::string rizhisj;
	int buzhou = 0;
};
inline m_Bianliang g_Bianliang;

