#pragma once
extern enum SubMenus;

namespace Menu
{
	class UserInterface
	{
	public:
		bool reggedytd = false;
		bool opened = false;
		bool selectPressed = false;
		bool leftPressed = false;
		bool rightPressed = false;
		bool menusounds = true;
		bool huakuaisihua = true;

		void scroll(int* prev, const int cur);
		void Description(const char* text);
		bool Option(const char* option, const char* tishi);
		bool Option(const char* option, const char* tishi, std::function<void()> function);
		bool SubMenu(const char* option, const char* tishi, SubMenus newSub);
		bool SubMenu(const char* option, const char* tishi, SubMenus newSub, std::function<void()> function);
		bool Bool(const char* option, const char* tishi, bool& b00l);
		bool Int(const char* option, const char* tishi, int& _int, int min, int max);
		bool Int(const char* option, const char* tishi, int& _int, int min, int max, int step);
		bool Float(const char* option, const char* tishi, float& _float, int min, int max);
		bool Float(const char* option, const char* tishi, float& _float, int min, int max, int step);
		bool IntVector(const char* option, const char* tishi, std::vector<int> Vector, int& position);
		bool FloatVector(const char* option, const char* tishi, std::vector<float> Vector, int& position);
		bool StringVector(const char* option, const char* tishi, std::vector<std::string> Vector, int& position);
		bool StringVector(const char* option, const char* tishi, std::vector<char*> Vector, int& position);
		bool stringvector(const char* option, const char* tishi, std::vector<char*> Vector, int& position);
	public:
		int textureID;
		int maxVisOptions = 12;
		int currentOption = 1;
		int optionCount = 0;
		int tishicount = 0;
		int menuLevel = 0;
		int optionsArray[1000];

		int keyPressDelay = 140;
		int keyPressPreviousTick = GetTickCount();
		int openKey = VK_F8;
		int backKey = VK_BACK;
		int upKey = VK_UP;
		int downKey = VK_DOWN;
		int leftKey = VK_LEFT;
		int rightKey = VK_RIGHT;
		int selectKey = VK_RETURN;
	public:
		SubMenus currentMenu;
		SubMenus menusArray[1000];
	public:
		float menuX = 0.15f;
		float menuWidth = 0.21f;
	public:
		RGBA titlerect = { 248, 225, 5, 255 };
		RGBA optionrect = { 0, 0, 0, 130 };
		RGBA scroller = { 132, 211, 214, 150 };
	public:
		RGBAF titletext = { 255, 255, 255, 255, 7 };
		RGBAF optiontext = { 255, 255, 255, 255, 6 };
	public:
		void Keys();
		void GetKeys();
		void MoveMenu(SubMenus menu);
		void BackMenu();
		void FPS(std::string text, RGBAF rgbaf, VECTOR2 position, VECTOR2_2 size, bool center, bool Outline);
		void Title(const char* title);
		void End();
	};
	inline UserInterface gui;

	class Drawing
	{
	public:
		void Text(const char* text, RGBAF rgbaf, VECTOR2 position, VECTOR2_2 size, bool center);
		void Rect(RGBA rgba, VECTOR2 position, VECTOR2_2 size);
		void Sprite(std::string Streamedtexture, std::string textureName, float x, float y, float width, float height, float rotation, int r, int g, int b, int a);
	};
	inline Drawing draw;
}