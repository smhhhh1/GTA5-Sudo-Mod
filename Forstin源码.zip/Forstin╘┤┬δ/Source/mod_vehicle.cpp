#include"mod_vehicle.h"
#include"pugixml/src/pugixml.hpp"
namespace mod_vehicle
{
	struct modEntity
	{
		Entity e;
		int type;
		Hash hash;
		Entity initialHandle;
		bool isAttached;
		Entity attachTo;
		Vector3 AttachmentArgs;
		Vector3 AttachmentArgsRotation;
		int BoneIndex;
	};
	std::vector<Ped> last_ped;
	std::vector<Vehicle> last_vehicle;
	std::vector<Object> last_object;
	std::vector<std::string> big_ini_vehicle_list;
	std::vector<std::string> small_ini_vehicle_list;
	std::vector<std::string> xml_vehicle_list;
	std::vector<std::string> ASI_list;
	void request_control_of_id(Entity netid)
	{
		int tick = 0;

		while (!NETWORK::NETWORK_HAS_CONTROL_OF_NETWORK_ID(netid) && tick <= 25)
		{
			NETWORK::NETWORK_REQUEST_CONTROL_OF_NETWORK_ID(netid);
			tick++;
		}
	}

	void request_control_of_ent(Entity entity)
	{
		int tick = 0;
		while (!NETWORK::NETWORK_HAS_CONTROL_OF_ENTITY(entity) && tick <= 25)
		{
			NETWORK::NETWORK_REQUEST_CONTROL_OF_ENTITY(entity);
			tick++;
		}
		if (NETWORK::NETWORK_IS_SESSION_STARTED())
		{
			int netID = NETWORK::NETWORK_GET_NETWORK_ID_FROM_ENTITY(entity);
			request_control_of_id(netID);
			NETWORK::SET_NETWORK_ID_CAN_MIGRATE(netID, 1);
		}
	}

	void find_xml_vehicle()
	{
		std::string path = "C:\\Forstin\\Vehicle\\xml\\";
		for (const auto& entry : std::filesystem::directory_iterator(path))
		{
			std::string str = entry.path().generic_u8string();
			if (str.find(".xml") != std::string::npos)
			{
				std::size_t found = str.find_last_of(".xml");
				str = str.substr(0, found - 3);

				found = str.find_last_of("/\\");
				str = str.substr(found + 1);
				xml_vehicle_list.push_back(str);
			}
		}
	}

	void find_small_ini_vehicle()
	{
		std::string path = "C:\\Forstin\\Vehicle\\ini\\small\\";
		for (const auto& entry : std::filesystem::directory_iterator(path))
		{
			std::string str = entry.path().generic_u8string();
			if (str.find(".ini") != std::string::npos)
			{
				std::size_t found = str.find_last_of(".ini");
				str = str.substr(0, found - 3);

				found = str.find_last_of("/\\");
				str = str.substr(found + 1);
				small_ini_vehicle_list.push_back(str);
			}
		}
	}

	void find_big_ini_vehicle()
	{
		std::string path = "C:\\Forstin\\Vehicle\\ini\\big\\";
		for (const auto& entry : std::filesystem::directory_iterator(path))
		{
			std::string str = entry.path().generic_u8string();
			if (str.find(".ini") != std::string::npos)
			{
				std::size_t found = str.find_last_of(".ini");
				str = str.substr(0, found - 3);

				found = str.find_last_of("/\\");
				str = str.substr(found + 1);
				big_ini_vehicle_list.push_back(str);
			}
		}
	}

	bool create_ini_vehicle(const char* vehiclename)
	{
		//deleteLastEntity();
		int allObjectsCount = INI::GetInt(vehiclename, "AllObjects", "Count");
		int allVehicleCount = INI::GetInt(vehiclename, "AllVehicles", "Count");
		int AllPedCount = INI::GetInt(vehiclename, "AllPeds", "Count");

		Vector3 ourCoords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);

		std::vector<mod_vehicle::modEntity>entityList;

		//loadVehicle
		for (int i = 0; i < allVehicleCount; i++)
		{
			mod_vehicle::modEntity temp;
			temp.hash = atoll(INI::GetString(vehiclename, ("Vehicle" + std::to_string(i)).c_str(), "Hash").c_str());
			temp.type = 0;
			if (STREAMING::IS_MODEL_VALID(temp.hash))
			{
				STREAMING::REQUEST_MODEL(temp.hash);
				while (!STREAMING::HAS_MODEL_LOADED(temp.hash)) {
					WAIT(0);
				}
				entityList.push_back(temp);
			}
			else
			{
				//g_gui.SendNotification("INI�ؾ�", StringToChar("����:" + std::to_string(temp.hash) + "ģ����Ч"));
				for (int i = 0; i < entityList.size(); i++)
				{
					STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(entityList[i].hash);
				}
				return false;
			}
		}

		//loadObject
		for (int i = 0; i < allObjectsCount; i++)
		{
			mod_vehicle::modEntity temp{};
			temp.hash = atoll(INI::GetString(vehiclename, ("Object" + std::to_string(i)).c_str(), "Hash").c_str());
			temp.type = 1;
			if (STREAMING::IS_MODEL_VALID(temp.hash))
			{
				STREAMING::REQUEST_MODEL(temp.hash);
				while (!STREAMING::HAS_MODEL_LOADED(temp.hash)) {
					WAIT(0);
				}
				entityList.push_back(temp);
			}
			else
			{
				//g_gui.SendNotification("INI�ؾ�", StringToChar("����:" + std::to_string(temp.hash) + "ģ����Ч"));
				for (int i = 0; i < entityList.size(); i++)
				{
					STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(entityList[i].hash);
				}
				return false;
			}
		}
		//��������
		for (int i = 0; i < allVehicleCount && entityList[i].type == 0; i++)
		{
			entityList[i].BoneIndex = atoi(INI::GetString(vehiclename, ("Vehicle" + std::to_string(i)).c_str(), "Bone").c_str());
			entityList[i].initialHandle = INI::GetInt(vehiclename, ("Vehicle" + std::to_string(i)).c_str(), "SelfNumeration");
			entityList[i].attachTo = INI::GetInt(vehiclename, ("Vehicle" + std::to_string(i)).c_str(), "AttachNumeration");
			entityList[i].AttachmentArgs.x = INI::GetFloat(vehiclename, ("Vehicle" + std::to_string(i)).c_str(), "OffsetX");
			entityList[i].AttachmentArgs.y = INI::GetFloat(vehiclename, ("Vehicle" + std::to_string(i)).c_str(), "OffsetY");
			entityList[i].AttachmentArgs.z = INI::GetFloat(vehiclename, ("Vehicle" + std::to_string(i)).c_str(), "OffsetZ");
			entityList[i].AttachmentArgsRotation.x = INI::GetFloat(vehiclename, ("Vehicle" + std::to_string(i)).c_str(), "Pitch");
			entityList[i].AttachmentArgsRotation.y = INI::GetFloat(vehiclename, ("Vehicle" + std::to_string(i)).c_str(), "Roll");
			entityList[i].AttachmentArgsRotation.z = INI::GetFloat(vehiclename, ("Vehicle" + std::to_string(i)).c_str(), "Yaw");
			*(unsigned short*)hooks.m_model_spawn_bypass = 0x9090;
			last_vehicle.push_back(entityList[i].e = VEHICLE::CREATE_VEHICLE(entityList[i].hash, ourCoords.x, ourCoords.y, ourCoords.z, ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID()), 1, 0, 0));
			*(unsigned short*)hooks.m_model_spawn_bypass = 0x0574;
			mod_vehicle::request_control_of_ent(entityList[i].e);
			ENTITY::SET_ENTITY_INVINCIBLE(entityList[i].e, INI::GetBool(vehiclename, ("Vehicle" + std::to_string(i)).c_str(), "Invincible"));
			ENTITY::SET_ENTITY_ALPHA(entityList[i].e, INI::GetInt(vehiclename, ("Vehicle" + std::to_string(i)).c_str(), "Alpha"), 1);
			ENTITY::FREEZE_ENTITY_POSITION(entityList[i].e, INI::GetBool(vehiclename, ("Vehicle" + std::to_string(i)).c_str(), "Freeze"));
			ENTITY::SET_ENTITY_VISIBLE(entityList[i].e, INI::GetBool(vehiclename, ("Vehicle" + std::to_string(i)).c_str(), "Visible"), 1);
			DECORATOR::DECOR_SET_INT(entityList[i].e, "MPBitset", 0);
			ENTITY::SET_ENTITY_INVINCIBLE(entityList[i].e, 1);
			VEHICLE::SET_VEHICLE_COLOURS(entityList[i].e, atoi(INI::GetString(vehiclename, ("Vehicle" + std::to_string(i) + "VehicleColors").c_str(), "Primary").c_str()), atoi(INI::GetString(vehiclename, ("Vehicle" + std::to_string(i) + "VehicleColors").c_str(), "Secondary").c_str()));
			VEHICLE::_SET_VEHICLE_NEON_LIGHTS_COLOUR(entityList[i].e, atoi(INI::GetString(vehiclename, ("Vehicle" + std::to_string(i) + "NeonColor").c_str(), "R").c_str()), atoi(INI::GetString(vehiclename, ("Vehicle" + std::to_string(i) + "NeonColor").c_str(), "G").c_str()), atoi(INI::GetString(vehiclename, ("Vehicle" + std::to_string(i) + "NeonColor").c_str(), "B").c_str()));
			STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(entityList[i].hash);
		}

		//��������
		for (int i = 0; i < allObjectsCount && entityList[i].type == 1; i++)
		{
			entityList[i].BoneIndex = INI::GetInt(vehiclename, ("Object" + std::to_string(i)).c_str(), "Bone");
			entityList[i].initialHandle = atoi(INI::GetString(vehiclename, ("Object" + std::to_string(i)).c_str(), "SelfNumeration").c_str());
			entityList[i].attachTo = atoi(INI::GetString(vehiclename, ("Object" + std::to_string(i)).c_str(), "AttachNumeration").c_str());
			entityList[i].AttachmentArgs.x = INI::GetFloat(vehiclename, ("Object" + std::to_string(i)).c_str(), "OffsetX");
			entityList[i].AttachmentArgs.y = INI::GetFloat(vehiclename, ("Object" + std::to_string(i)).c_str(), "OffsetY");
			entityList[i].AttachmentArgs.z = INI::GetFloat(vehiclename, ("Object" + std::to_string(i)).c_str(), "OffsetZ");
			entityList[i].AttachmentArgsRotation.x = INI::GetFloat(vehiclename, ("Object" + std::to_string(i)).c_str(), "Pitch");
			entityList[i].AttachmentArgsRotation.y = INI::GetFloat(vehiclename, ("Object" + std::to_string(i)).c_str(), "Roll");
			entityList[i].AttachmentArgsRotation.z = INI::GetFloat(vehiclename, ("Object" + std::to_string(i)).c_str(), "Yaw");
			*(unsigned short*)hooks.m_model_spawn_bypass = 0x9090;
			last_object.push_back(entityList[i].e = OBJECT::CREATE_OBJECT(entityList[i].hash, ourCoords.x, ourCoords.y, ourCoords.z, 1, 1, INI::GetBool(vehiclename, ("Object" + std::to_string(i)).c_str(), "Dynamic")));
			*(unsigned short*)hooks.m_model_spawn_bypass = 0x0574;
			mod_vehicle::request_control_of_ent(entityList[i].e);
			ENTITY::SET_ENTITY_INVINCIBLE(entityList[i].e, INI::GetBool(vehiclename, ("Object" + std::to_string(i)).c_str(), "Invincible"));
			ENTITY::SET_ENTITY_ALPHA(entityList[i].e, INI::GetInt(vehiclename, ("Object" + std::to_string(i)).c_str(), "Alpha"), 1);
			ENTITY::FREEZE_ENTITY_POSITION(entityList[i].e, INI::GetBool(vehiclename, ("Object" + std::to_string(i)).c_str(), "Freeze"));
			ENTITY::SET_ENTITY_VISIBLE(entityList[i].e, INI::GetBool(vehiclename, ("Object" + std::to_string(i)).c_str(), "Visible"), 1);
			STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(entityList[i].hash);
		}

		//����
		for (mod_vehicle::modEntity& me : entityList)
		{
			for (mod_vehicle::modEntity& me2 : entityList)
			{
				if (me.initialHandle == me2.attachTo)
				{
					ENTITY::ATTACH_ENTITY_TO_ENTITY(me2.e, me.e, me2.BoneIndex, me2.AttachmentArgs.x, me2.AttachmentArgs.y, me2.AttachmentArgs.z, me2.AttachmentArgsRotation.x, me2.AttachmentArgsRotation.y, me2.AttachmentArgsRotation.z, 0, 1, 1, 0, 2, 1);
				}
			}
		}
		return true;
	}

	void create_xml_vehicle(const char* xml)
	{
		pugi::xml_document doc;
		if (doc.load_file(xml).status != pugi::status_ok)
			return;

		auto& node_vehicle = doc.child("Vehicle");
		Hash model_hash = node_vehicle.child("ModelHash").text().as_uint();

		if (STREAMING::IS_MODEL_VALID(model_hash))
		{
			STREAMING::REQUEST_MODEL(model_hash);
			while (!STREAMING::HAS_MODEL_LOADED(model_hash)) WAIT(0);
		}
		else return;

		std::vector<modEntity> entity_list;
		modEntity vehicle;
		*(unsigned short*)hooks.m_model_spawn_bypass = 0x9090;
		vehicle.e = MenuFunctions::spawn_vehicles(model_hash);
		*(unsigned short*)hooks.m_model_spawn_bypass = 0x0574;
		last_vehicle.push_back(vehicle.e);
		entity_list.push_back(vehicle);
		entity_list[0].initialHandle = node_vehicle.child("InitialHandle").text().as_int();
		entity_list[0].isAttached = false;

		auto& vehicle_properties = node_vehicle.child("VehicleProperties");

		VEHICLE::SET_VEHICLE_LIVERY(vehicle.e, vehicle_properties.child("Livery").text().as_int());

		auto& node_vehicle_colours = vehicle_properties.child("Colours");
		int mod1a = node_vehicle_colours.child("Mod1_a").text().as_int();
		int mod1b = node_vehicle_colours.child("Mod1_b").text().as_int();
		int mod1c = node_vehicle_colours.child("Mod1_c").text().as_int();
		VEHICLE::SET_VEHICLE_MOD_COLOR_1(vehicle.e, mod1a, mod1b, mod1c);

		int mod2a = node_vehicle_colours.child("Mod2_a").text().as_int();
		int mod2b = node_vehicle_colours.child("Mod2_b").text().as_int();
		VEHICLE::SET_VEHICLE_MOD_COLOR_2(vehicle.e, mod2a, mod2b);

		int primary = node_vehicle_colours.child("Primary").text().as_int();
		int secondary = node_vehicle_colours.child("Secondary").text().as_int();
		VEHICLE::SET_VEHICLE_COLOURS(vehicle.e, primary, secondary);

		int pearl = node_vehicle_colours.child("Pearl").text().as_int();
		int rim = node_vehicle_colours.child("Rim").text().as_int();
		VEHICLE::SET_VEHICLE_EXTRA_COLOURS(vehicle.e, pearl, rim);

		bool is_primary_colour_custom = node_vehicle_colours.child("IsPrimaryColourCustom").text().as_bool();
		bool is_secondary_colour_custom = node_vehicle_colours.child("IsSecondaryColourCustom").text().as_bool();
		if (is_primary_colour_custom)
		{
			RGB cust1;
			cust1.r = node_vehicle_colours.child("Cust1_R").text().as_int();
			cust1.g = node_vehicle_colours.child("Cust1_G").text().as_int();
			cust1.b = node_vehicle_colours.child("Cust1_B").text().as_int();
			VEHICLE::SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(vehicle.e, cust1.r, cust1.g, cust1.b);
		}
		if (is_secondary_colour_custom)
		{
			RGB cust2;
			cust2.r = node_vehicle_colours.child("Cust2_R").text().as_int();
			cust2.g = node_vehicle_colours.child("Cust2_G").text().as_int();
			cust2.b = node_vehicle_colours.child("Cust2_B").text().as_int();
			VEHICLE::SET_VEHICLE_CUSTOM_SECONDARY_COLOUR(vehicle.e, cust2.r, cust2.g, cust2.b);
		}

		RGB tyre_smoke_rgb;
		tyre_smoke_rgb.r = node_vehicle_colours.child("tyreSmoke_R").text().as_int();
		tyre_smoke_rgb.g = node_vehicle_colours.child("tyreSmoke_G").text().as_int();
		tyre_smoke_rgb.b = node_vehicle_colours.child("tyreSmoke_B").text().as_int();
		VEHICLE::SET_VEHICLE_TYRE_SMOKE_COLOR(vehicle.e, tyre_smoke_rgb.r, tyre_smoke_rgb.g, tyre_smoke_rgb.b);

		VEHICLE::_SET_VEHICLE_INTERIOR_COLOR(vehicle.e, node_vehicle_colours.child("LrInterior").text().as_int());
		VEHICLE::_SET_VEHICLE_DASHBOARD_COLOR(vehicle.e, node_vehicle_colours.child("LrDashboard").text().as_int());
		VEHICLE::_SET_VEHICLE_XENON_LIGHTS_COLOR(vehicle.e, node_vehicle_colours.child("LrXenonHeadlights").text().as_int());

		int opacity_level = node_vehicle.child("OpacityLevel").text().as_int();
		if (opacity_level < 255) ENTITY::SET_ENTITY_ALPHA(vehicle.e, opacity_level, false);
		ENTITY::SET_ENTITY_VISIBLE(vehicle.e, opacity_level, false);

		node_vehicle.child("IsOnFire").text().as_bool() ? FIRE::START_ENTITY_FIRE(vehicle.e) : FIRE::STOP_ENTITY_FIRE(vehicle.e);

		ENTITY::SET_ENTITY_INVINCIBLE(vehicle.e, node_vehicle.child("IsInvincible").text().as_bool());

		auto& nod_attachments = node_vehicle.child("SpoonerAttachments");
		for (auto& nod_attachment = nod_attachments.first_child(); nod_attachment; nod_attachment = nod_attachment.next_sibling())
		{
			modEntity e;
			Hash eModel = nod_attachment.child("ModelHash").text().as_uint();

			int type = nod_attachment.child("Type").text().as_int();
			bool dynamic = nod_attachment.child("Dynamic").text().as_bool();
			e.initialHandle = nod_attachment.child("InitialHandle").text().as_int();

			auto& node_entity_pos_rot = nod_attachment.child("PositionRotation");
			Vector3 placing_epos;
			placing_epos.x = node_entity_pos_rot.child("X").text().as_float();
			placing_epos.y = node_entity_pos_rot.child("Y").text().as_float();
			placing_epos.z = node_entity_pos_rot.child("Z").text().as_float();
			Vector3 placing_erot;
			placing_erot.x = node_entity_pos_rot.child("Pitch").text().as_float();
			placing_erot.y = node_entity_pos_rot.child("Roll").text().as_float();
			placing_erot.z = node_entity_pos_rot.child("Yaw").text().as_float();

			if (STREAMING::IS_MODEL_VALID(eModel))
			{
				STREAMING::REQUEST_MODEL(eModel);
				while (!STREAMING::HAS_MODEL_LOADED(eModel)) WAIT(0);
			}
			else
			{
				for (int i = 0; i < entity_list.size(); i++)
				{
					STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(entity_list[i].hash);
				}
				return;
			}

			if (type == 3)
			{
				*(unsigned short*)hooks.m_model_spawn_bypass = 0x9090;
				e.e = OBJECT::CREATE_OBJECT(eModel, placing_epos.x, placing_epos.y, placing_epos.z, true, true, false);
				*(unsigned short*)hooks.m_model_spawn_bypass = 0x0574;
			}
			else if (type == 1)
			{
				*(unsigned short*)hooks.m_model_spawn_bypass = 0x9090;
				e.e = PED::CREATE_PED(26, eModel, placing_epos.x, placing_epos.y, placing_epos.z, placing_erot.z, true, true);
				*(unsigned short*)hooks.m_model_spawn_bypass = 0x0574;
				last_ped.push_back(e.e);
			}
			else if (type == 2)
			{
				*(unsigned short*)hooks.m_model_spawn_bypass = 0x9090;
				e.e = VEHICLE::CREATE_VEHICLE(eModel, placing_epos.x, placing_epos.y, placing_epos.z, placing_erot.z, true, true);
				*(unsigned short*)hooks.m_model_spawn_bypass = 0x0574;
				auto& node_vehicle_stuff = nod_attachment.child("VehicleProperties");

				VEHICLE::SET_VEHICLE_LIVERY(e.e, node_vehicle_stuff.child("Livery").text().as_int());

				auto& nodeVehicleColours = node_vehicle_stuff.child("Colours");
				int mod1a = nodeVehicleColours.child("Mod1_a").text().as_int();
				int mod1b = nodeVehicleColours.child("Mod1_b").text().as_int();
				int mod1c = nodeVehicleColours.child("Mod1_c").text().as_int();
				VEHICLE::SET_VEHICLE_MOD_COLOR_1(e.e, mod1a, mod1b, mod1c);
				int mod2a = nodeVehicleColours.child("Mod2_a").text().as_int();
				int mod2b = nodeVehicleColours.child("Mod2_b").text().as_int();
				VEHICLE::SET_VEHICLE_MOD_COLOR_2(e.e, mod2a, mod2b);

				int Primary = nodeVehicleColours.child("Primary").text().as_int();
				int Secondary = nodeVehicleColours.child("Secondary").text().as_int();
				VEHICLE::SET_VEHICLE_COLOURS(e.e, Primary, Secondary);

				int Pearl = nodeVehicleColours.child("Pearl").text().as_int();
				int Rim = nodeVehicleColours.child("Rim").text().as_int();
				VEHICLE::SET_VEHICLE_EXTRA_COLOURS(e.e, Pearl, Rim);
				bool isPrimaryColourCustom = nodeVehicleColours.child("IsPrimaryColourCustom").text().as_bool();
				bool isSecondaryColourCustom = nodeVehicleColours.child("IsSecondaryColourCustom").text().as_bool();
				if (isPrimaryColourCustom)
				{
					RGB cust1;
					cust1.r = nodeVehicleColours.child("Cust1_R").text().as_int();
					cust1.g = nodeVehicleColours.child("Cust1_G").text().as_int();
					cust1.b = nodeVehicleColours.child("Cust1_B").text().as_int();
					VEHICLE::SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(e.e, cust1.r, cust1.g, cust1.b);
				}
				if (isSecondaryColourCustom)
				{
					RGB cust2;
					cust2.r = nodeVehicleColours.child("Cust2_R").text().as_int();
					cust2.g = nodeVehicleColours.child("Cust2_G").text().as_int();
					cust2.b = nodeVehicleColours.child("Cust2_B").text().as_int();
					VEHICLE::SET_VEHICLE_CUSTOM_SECONDARY_COLOUR(e.e, cust2.r, cust2.g, cust2.b);
				}
				RGB tyreSmokeRgb;
				tyreSmokeRgb.r = nodeVehicleColours.child("tyreSmoke_R").text().as_int();
				tyreSmokeRgb.g = nodeVehicleColours.child("tyreSmoke_G").text().as_int();
				tyreSmokeRgb.b = nodeVehicleColours.child("tyreSmoke_B").text().as_int();
				VEHICLE::SET_VEHICLE_TYRE_SMOKE_COLOR(e.e, tyreSmokeRgb.r, tyreSmokeRgb.g, tyreSmokeRgb.b);
			}
			last_object.push_back(e.e);

			ENTITY::FREEZE_ENTITY_POSITION(e.e, nod_attachment.child("FrozenPos").text().as_bool(!dynamic));

			ENTITY::SET_ENTITY_HAS_GRAVITY(e.e, nod_attachments.child("HasGravity").text().as_bool(true));

			nod_attachment.child("IsOnFire").text().as_bool() ? FIRE::START_ENTITY_FIRE(e.e) : FIRE::STOP_ENTITY_FIRE(e.e);
			ENTITY::SET_ENTITY_INVINCIBLE(e.e, nod_attachment.child("IsInvincible").text().as_bool());
			ENTITY::SET_ENTITY_COLLISION(e.e, true, false);
			ENTITY::SET_ENTITY_ONLY_DAMAGED_BY_PLAYER(e.e, nod_attachment.child("IsOnlyDamagedByPlayer").text().as_bool());
			ENTITY::SET_ENTITY_VISIBLE(e.e, nod_attachment.child("IsVisible").text().as_bool(), false);

			auto& node_entity_attachment = nod_attachment.child("Attachment");
			e.isAttached = node_entity_attachment.attribute("isAttached").as_bool();
			if (e.isAttached)
			{
				std::string attachedToHandleStr = node_entity_attachment.child("AttachedTo").text().as_string();
				if (attachedToHandleStr == "PLAYER")
				{
					e.attachTo = PLAYER::PLAYER_PED_ID();
				}
				else if (attachedToHandleStr == "VEHICLE")
				{
					if (ENTITY::DOES_ENTITY_EXIST(vehicle.e)) e.attachTo = vehicle.e;
					else e.isAttached = false;
				}
				else
				{
					e.attachTo = node_entity_attachment.child("AttachedTo").text().as_int();
				}
				e.BoneIndex = node_entity_attachment.child("BoneIndex").text().as_int();

				e.AttachmentArgs.x = node_entity_attachment.child("X").text().as_float();
				e.AttachmentArgs.y = node_entity_attachment.child("Y").text().as_float();
				e.AttachmentArgs.z = node_entity_attachment.child("Z").text().as_float();

				e.AttachmentArgsRotation.x = node_entity_attachment.child("Pitch").text().as_float();
				e.AttachmentArgsRotation.y = node_entity_attachment.child("Roll").text().as_float();
				e.AttachmentArgsRotation.z = node_entity_attachment.child("Yaw").text().as_float();
			}
			entity_list.push_back(e);
			STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(eModel);
		}

		for (modEntity& me : entity_list)
		{
			if (me.isAttached)
			{
				request_control_of_ent(me.e);
				bool bHasCollision = !ENTITY::_GET_ENTITY_COLLISON_DISABLED(me.e);
				if (me.attachTo == PLAYER::PLAYER_PED_ID())
				{
					ENTITY::ATTACH_ENTITY_TO_ENTITY(me.e, PLAYER::PLAYER_PED_ID(), me.BoneIndex, me.AttachmentArgs.x, me.AttachmentArgs.y, me.AttachmentArgs.z, me.AttachmentArgsRotation.x, me.AttachmentArgsRotation.y, me.AttachmentArgsRotation.z, FALSE, FALSE, bHasCollision, FALSE, 2, TRUE);
				}
				else if (me.attachTo == PLAYER::PLAYER_PED_ID())
				{
				}
				else
				{
					for (modEntity& me2 : entity_list)
					{
						if (me.attachTo == me2.initialHandle)
						{
							ENTITY::ATTACH_ENTITY_TO_ENTITY(me.e, me2.e, me.BoneIndex, me.AttachmentArgs.x, me.AttachmentArgs.y, me.AttachmentArgs.z, me.AttachmentArgsRotation.x, me.AttachmentArgsRotation.y, me.AttachmentArgsRotation.z, FALSE, FALSE, bHasCollision, FALSE, 2, TRUE);
						}
					}
				}
			}
		}
	}
}