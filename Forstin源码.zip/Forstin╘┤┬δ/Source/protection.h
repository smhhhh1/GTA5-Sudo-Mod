#pragma once
class feat
{
public:
	bool m_bRestored = true;
	feat();
	virtual			~feat();
};

static std::vector<Hash> blacklistedObjects = {
    0x9CF21E0F ,0x34315488,//need 2 of this obj , 
    0x6A27FEB1, 0xCB2ACC8,
    0xC6899CDE, 0xD14B5BA3,
    0xD9F4474C, 0x32A9996C,
    0x69D4F974, 0xCAFC1EC3,
    0x79B41171, 0x1075651,
    0xC07792D4, 0x781E451D,
    0x762657C6, 0xC2E75A21,
    0xC3C00861, 0x81FB3FF0,
    0x45EF7804, 0xE65EC0E4,
    0xE764D794, 0xFBF7D21F,
    0xE1AEB708, 0xA5E3D471,
    0xD971BBAE, 0xCF7A9A9D,
    0xC2CC99D8, 0x8FB233A4,
    0x24E08E1F, 0x337B2B54,
    0xB9402F87, 0x4F2526DA,
    0xD75E01A6, 0xB015923B,
    0xC4C9551E,0x1AD51F27,
    0x675D244E,0x68E49D4D,
    122627294, 29828513,
    2180726768,2041844081,
    2783171697,2015249693,
    1781006001,2250084685,
    3864969444,3284142177,
    3330907358,3656664908,
    213036232,1173321732,
    875648136,3480918685,
    2889736519,3305783941,
    1481697203,3854081329,
    2761316604,2494305715
};

static std::vector<Hash> PedProtex =
{
    0x9B22DBAF,0x9B810FA2,0x0D7114C9,
    0x92991B72,0xD266D9D6
};

static std::vector<Hash> blacklistveh = {
    0x82CAC433,0x4FAF0D70,
    0xF337AB36,0x6827CF72,
    0xFCFCB68B,0x60A7EA10,
    0x53174EEF,0x78BC1A3C,
    0x810369E2,0xD6BC7523,
    0x81BD2ED0,0xFE0A508C,
    0x15F27762,0x1AAD0DED,
    0x761E2AD3,0x7BE032C6,
    0x6A59902D,0x7CAB34D0,
    0xB12314E0,0xE5A2D6C6,
    0x46699F47,0x3E48BF23,
    0xA09E15FD,0x7074F39D,
    0xD36A4B44,0x9441D8D5,
    3872089630,1257886169,
    0x71D3B6F0,0x287FA449,
    0xD039510B,0x6827CF72
};

static std::vector<char*> objects = {
"prop_bskball_01","prop_flag_japan","prop_flag_us","prop_flag_canada","prop_flag_scotland_s","prop_flag_russia","prop_flag_german","prop_flag_uk_s","prop_flag_france","prop_acc_guitar_01_d1","PROP_MP_RAMP_03", "PROP_MP_RAMP_02", "PROP_MP_RAMP_01", "PROP_JETSKI_RAMP_01", "PROP_WATER_RAMP_03","prop_mp_ramp_03","PROP_VEND_SNAK_01", "PROP_TRI_START_BANNER", "PROP_TRI_FINISH_BANNER", "PROP_TEMP_BLOCK_BLOCKER", "PROP_UICEGATEL", "PROP_SKIP_08A", "PROP_SAM_01", "PROP_RUB_CONT_01B", "PROP_ROADCONE01A", "PROP_MP_ARROW_Forstin_01", "PROP_HOTEL_CLOCK_01",
"PROP_LIFEBLURB_02", "PROP_COFFIN_02B", "PROP_MP_NUM_1", "PROP_MP_NUM_2", "PROP_MP_NUM_3", "PROP_MP_NUM_4", "PROP_MP_NUM_5", "PROP_MP_NUM_6", "PROP_MP_NUM_7", "PROP_MP_NUM_8", "PROP_MP_NUM_9", "prop_xmas_tree_int", "prop_bumper_car_01", "prop_beer_neon_01", "prop_space_rifle", "prop_dummy_01", "prop_rub_trolley01a", "prop_wheelchair_01_s", "PROP_CS_KATANA_01", "PROP_CS_DILDO_01", "prop_armchair_01", "prop_bin_04a",
"prop_chair_01a", "prop_dog_cage_01", "prop_dummy_plane", "prop_golf_bag_01", "prop_arcade_01",
"hei_prop_heist_emp", "prop_alien_egg_01", "prop_air_towbar_01", "hei_prop_heist_tug", "prop_air_luggtrolley", "PROP_CUP_SAUCER_01", "prop_wheelchair_01", "prop_ld_toilet_01", "prop_acc_guitar_01", "prop_bank_vaultdoor", "p_v_43_safe_s", "p_spinning_anus_s", "prop_can_canoe", "prop_air_woodsteps",
"Prop_weed_01", "prop_a_trailer_door_01", "prop_apple_box_01", "prop_air_fueltrail1", "prop_barrel_02a", "prop_barrel_float_1", "prop_Forstin_wat_03b", "prop_air_fueltrail2", "prop_air_propeller01", "prop_windmill_01", "prop_Ld_ferris_wheel", "p_tram_crash_s", "p_oil_slick_01", "p_ld_stinger_s", "p_ld_soc_ball_01", "prop_juicestand", "p_oil_pjack_01_s",
"prop_barbell_01", "prop_barbell_100kg", "p_parachute1_s", "p_cablecar_s", "prop_beach_fire", "prop_lev_des_barge_02","prop_lev_des_barge_01", "prop_a_base_bars_01", "prop_beach_bars_01", "prop_air_bigradar", "prop_weed_pallet", "prop_artifact_01", "prop_attache_case_01", "prop_large_gold", "prop_roller_car_01", "prop_water_corpse_01", "prop_water_corpse_02",
"prop_dummy_01", "prop_atm_01", "hei_prop_carrier_docklight_01", "hei_prop_carrier_liferafts", "hei_prop_carrier_ord_03", "hei_prop_carrier_defense_02", "hei_prop_carrier_defense_01", "hei_prop_carrier_radar_1",
"hei_prop_carrier_radar_2", "hei_prop_hei_bust_01", "hei_prop_wall_alarm_on", "hei_prop_wall_light_10a_cr", "prop_afsign_amun", "prop_afsign_vbike", "prop_aircon_l_01", "prop_aircon_l_02", "prop_aircon_l_03", "prop_aircon_l_04", "prop_airhockey_01", "prop_air_bagloader", "prop_air_blastfence_01", "prop_air_blastfence_02", "prop_air_cargo_01a", "prop_air_chock_01", "prop_air_chock_03", "prop_air_gasbogey_01", "prop_air_generator_03",
"prop_air_stair_02", "prop_amb_40oz_02", "prop_amb_40oz_03", "prop_amb_beer_bottle", "prop_amb_donut", "prop_amb_handbag_01", "prop_amp_01", "prop_anim_cash_pile_02", "prop_asteroid_01", "prop_arm_wrestle_01", "prop_ballistic_shield", "prop_bank_shutter", "prop_barier_conc_02b", "prop_barier_conc_05a", "prop_barrel_01a", "prop_bar_stool_01", "prop_basejump_target_01"
};

void AntiCeoKick(bool t);
void AntiSPKick(bool t);
void AntiApartmentTP(bool t);
void AntiRemoteBounty(bool t);
void antiRemoteVehicleKick(bool t);
void antiRemoteForceMission(bool t);
void AntiReport(bool t);
void AntiKick(bool t);
void AntiFreeze(bool t);
void AntiAttachment(bool toggle);
void AntiExplosion(bool t);
void AntiSound(bool t);
void AntiStars(bool t);
void AntiStat(bool t);
void AntiGiveWeapon(bool t);
void AntiRemoveWeapon(bool t);
void AntiFire(bool t);
void AntiDrop(bool t);
void AntiPTFX(bool t);
void AntiInvite(bool t);
void BlockAllNetEvents(bool t);
void AntiVoteKick(bool t);
void AntiRequestControl(bool t);
void AntiCage(bool toggle);
void AntiCargonplane(bool toggle);
void BlockAllEntity(bool toggle);
void BlockObjectCrash(bool toggle);
void BlockPedCrash(bool toggle);
void BlockVehicleCrash(bool toggle);