#pragma once
#include "stdafx.h"
#include "UserInterface.h"
#include"features.h"
#include"list.h"
#include"script_local.h"
#include"unlock.h"
#include"config.h"
#include"mod_vehicle.h"
#pragma execution_character_set("utf-8")

//�Զ���ʻ
std::vector<char*> u_drivetype = { "Ĭ�Ϸ��","��·ɱ��","ֱ����ʻ","���ٵ���" };
//ˢ���ؾ�
int fhtime, gunrunningDLC1, sportSeries1, smugglersDLC1, arenaWarDLC1, aispeed1, doomsdayDLC1, casinoHeistDLC1, tunersDLC1, industrial1, emergency1, coupes1, compacts1, Super1, sports1, sportsClassics1, sedans1, sUVs1, offRoad1, muscle1, military1, cycles1, planes1, helicopters1, motorcycles1, boats1, services1, trailer1, trains1, vans1, utility1, commercial1 = 0;
//����ѡ��
int tongjidengji1 = 0;
std::vector<char*> tongjidengji = { "���ͨ��", "����1��","����2��","����3��" ,"����4��" ,"����5��" };
//�ĳ�����
int qiangjiefangshi1, qiangjiemubiao1, qiangshoudengji1, cheshoudengji1, heikedengji1, zhuyaomubiao1, ruqinwuqi1, yunhuokache1, gaichepuqianzhi1 = 0;
std::vector<char*> qiangjiefangshi = { "����Ǳ��","������թ","��������" };
std::vector<char*> qiangjiemubiao = { "�ֽ�","�ƽ�","����","��ʯ" };
std::vector<char*> qiangshoudengji = { "�","����","����" };
std::vector<char*> cheshoudengji = { "�","����","����" };
std::vector<char*> heikedengji = { "�","����","����" };
//����Ƶ�
std::vector<char*> zhuyaomubiao = { "��������","�챦ʯ����","����ծȯ","�ۺ���ʯ","���������ļ�","�Ա�����" };
std::vector<char*> ruqinwuqi = { "����ǹ��װ","���ò�ǹ��װ","���;ѻ���ǹ��װ","MK2���ǹ��װ","MK2ͻ����ǹ��װ" };
std::vector<char*> yunhuokache = { "����","������","����ͷ","����ͷ" };
std::vector<char*> gaichepuqianzhi = { "����ǰ��","�󳮽���","���к�Լ","��ص�Ԫ","������Լ","IAA����","���ݺ�Լ","Ħ�аｻ��" };

void script_global(std::vector<int> index, std::string p1 = "")
{
	switch (index.size())
	{
	case 1:
		globalHandle(index[0]).As<std::string>() = p1;
		break;
	case 2:
		globalHandle(index[0]).At(index[1]).As<std::string>() = p1;
		break;
	case 3:
		globalHandle(index[0]).At(index[1]).At(index[2]).As<std::string>() = p1;
		break;
	}
}
void script_global(std::vector<int> index, float p1 = 0.0f)
{
	switch (index.size())
	{
	case 1:
		globalHandle(index[0]).As<float>() = p1;
		break;
	case 2:
		globalHandle(index[0]).At(index[1]).As<float>() = p1;
		break;
	case 3:
		globalHandle(index[0]).At(index[1]).At(index[2]).As<float>() = p1;
		break;
	}
}
void script_global(std::vector<int> index, int p1 = 0)
{
	switch (index.size())
	{
	case 1:
		globalHandle(index[0]).As<int>() = p1;
		break;
	case 2:
		globalHandle(index[0]).At(index[1]).As<int>() = p1;
		break;
	case 3:
		globalHandle(index[0]).At(index[1]).At(index[2]).As<int>() = p1;
		break;
	}

}
void script_global(std::vector<int> index, __int64 p1 = 0)
{
	switch (index.size())
	{
	case 1:
		globalHandle(index[0]).As<__int64>() = p1;
		break;
	case 2:
		globalHandle(index[0]).At(index[1]).As<__int64>() = p1;
		break;
	case 3:
		globalHandle(index[0]).At(index[1]).At(index[2]).As<__int64>() = p1;
		break;
	}
}
bool checkModel(Hash hash) {
	//model_check_bypass(true);
	if (STREAMING::IS_MODEL_IN_CDIMAGE(hash)) {
		if (STREAMING::IS_MODEL_VALID(hash)) {
			STREAMING::REQUEST_MODEL(hash);
			while (!STREAMING::HAS_MODEL_LOADED(hash)) {
				WAIT(0);
			}
			return true;
		}
	}
	return false;
	//model_check_bypass(false);
}

void ScriptMain() {
	srand(GetTickCount64());
	using namespace Menu;
	gui.GetKeys();
	mod_vehicle::find_big_ini_vehicle();
	mod_vehicle::find_small_ini_vehicle();
	mod_vehicle::find_xml_vehicle();
	PlaySound(TEXT("C:\\Forstin\\Music\\zhuru.wav"), NULL, SND_FILENAME | SND_ASYNC);
	while (true) {
		hooks.m_register_file(&gui.textureID, "C:\\Forstin\\Textures\\Forstin.ytd", true, "Forstin.ytd", false); // Load YTD  /* https://www.unknowncheats.me/forum/3158178-post18.html */
		gui.Keys();
		Features::LocalLoop();//localѭ��
		Features::TeleportLoop();//teleportѭ��
		Features::VehicleLoop();//vehicleѭ��
		Features::WeaponLoop();//weaponѭ��
		Features::Plistsloop();//plistsѭ��
		Features::Sessionloop();//sessionѭ��
		Features::WorldLoop();//worldѭ��
		Features::MiscLoop();//miscѭ��
		Features::RecoveryLoop();//recoveryѭ��
		Features::TaskLoop();//taskѭ��
		Features::SettingsLoop();//settingsѭ��

		switch (gui.currentMenu) {

		case MAINMENU:
		{
			gui.Title("Forstin menu");

			gui.SubMenu("����ѡ��", NULL, self);
			gui.SubMenu("����ѡ��", NULL, weapon);
			gui.SubMenu("�ؾ�ѡ��", NULL, vehicle);
			gui.SubMenu("���͹���", NULL, teleport);
			gui.SubMenu("������", NULL, task);
			gui.SubMenu("Σ�չ���", NULL, recovery);
			gui.SubMenu("ս��ѡ��", NULL, conversation);
			gui.SubMenu("����ѡ��", NULL, protection);
			gui.SubMenu("ģ��ѡ��", NULL, modelchanger);
			gui.SubMenu("����ѡ��", NULL, misc);
			gui.SubMenu("������", NULL, save);
			gui.SubMenu("GTA-Onlineѡ��", NULL, word);
			gui.SubMenu("MENU����", NULL, settings);
		}
		break;
		case modveh:
		{
			gui.Title("ģ���ؾ�");
			gui.SubMenu("��������", NULL, spanwsetting);
			gui.SubMenu("ini�ؾ�", NULL, iniveh);
			gui.SubMenu("xml�ؾ�", NULL, xmlveh);
		}
		break;
		case xmlveh:
		{
			gui.Title("xml�ؾ�");
			if (mod_vehicle::xml_vehicle_list.size() == NULL)
			{
				gui.Option("δ�ҵ�����ļ�", NULL);
			}
			else
			{
				for (std::string str : mod_vehicle::xml_vehicle_list)
				{
					if (gui.Option(str.c_str(), NULL))
					{
						std::string file = std::string("C:\\Forstin\\Vehicle\\xml\\" + str + ".xml");
						mod_vehicle::create_xml_vehicle(file.c_str());
					}
				}
			}
		}
		break;
		case iniveh:
		{
			gui.Title("ģ���ؾ�");
			gui.SubMenu("����ini�ؾ�", NULL, bigini);
			gui.SubMenu("С��ini�ؾ�", NULL, smallini);
		}
		break;
		case bigini:
		{
			gui.Title("����ini�ؾ�");
			if (mod_vehicle::big_ini_vehicle_list.size() == NULL)
			{
				gui.Option("δ�ҵ�����ļ�", NULL);
			}
			else
			{
				for (std::string str : mod_vehicle::big_ini_vehicle_list)
				{
					if (gui.Option(str.c_str(), NULL))
					{
						std::string file = std::string("C:\\Forstin\\Vehicle\\ini\\big\\" + str + ".ini");
						mod_vehicle::create_ini_vehicle(file.c_str());
						MenuFunctions::Notify("ִ�гɹ����Ѿ�������ɣ�");
					}
				}
			}
		}
		break;
		case smallini:
		{
			gui.Title("С��ini�ؾ�");
			if (mod_vehicle::small_ini_vehicle_list.size() == NULL)
			{
				gui.Option("δ�ҵ�����ļ�", NULL);
			}
			else
			{
				for (std::string str : mod_vehicle::small_ini_vehicle_list)
				{
					if (gui.Option(str.c_str(), NULL))
					{
						std::string file = std::string("C:\\Forstin\\Vehicle\\ini\\small\\" + str + ".ini");
						mod_vehicle::create_ini_vehicle(file.c_str());
						MenuFunctions::Notify("ִ�гɹ����Ѿ�������ɣ�");
					}
				}
			}
		}
		break;
		case settings:
		{
			gui.Title("MENUѡ��");
			gui.SubMenu("��ݼ�", NULL, kuaijiejian);
			gui.Float("�˵�X��", NULL, gui.menuX, 0.05, 1, 0.05);
			gui.Int("�����ӳ�", NULL, gui.keyPressDelay, 1, 200);
			if (gui.Option("�˳��˵�", "��ȫ�˳��˵�����Ӱ����Ϸ")) { g_running = false; }
			if (gui.Option("�˳���Ϸ", "�����˳���Ϸ��һ������")) { exit(0); }
			if (gui.Option("�رտ���̨", "�رպ���޷��˳��˵������������Ϸ"))
			{
				fclose(stdout);
				fclose(stdin);
				fclose(stderr);
				FreeConsole();
			}
		}
		break;
		case save:
		{
			gui.Title("������");
			if (gui.Option("С��", NULL));
			MenuFunctions::Notify("С��-Forstin Menu�ٷ�������/�ٷ��г��ල ��ϵQQ��2404134030");
		}
		break;
		case kuaijiejian:
		{
			gui.Title("��ݼ�");
			gui.Bool("F3��ǰ����", NULL, g_Settings.xiangqianchuansong);
			gui.Bool("F4���͵�Ŀ���", NULL, g_Settings.chuansongmubiaodian);
			gui.Bool("F5���͵�������", NULL, g_Settings.chuansongdaohangdian); 
			gui.Bool("F6���͵�����", "��Ҫ�Ⱥ�������", g_Settings.chuansongdaohujing);
			gui.Bool("F7ǿ�����", "����ʱ����F7��ǿ�����", g_Session.luodi);
			gui.Bool("DEL��������ɱ", NULL, g_Settings.delzisha);
			gui.Bool("END��ж�ز˵�", "��������END�����ɿ���ж�ز˵�", g_Settings.endxiezai);
		}
		break;
		case protection:
		{
			gui.Title("����ѡ��");
			gui.SubMenu("�ű��¼�", NULL, scriptprotection);
			gui.SubMenu("�����¼�", NULL, networkprotection);
			gui.SubMenu("��������", NULL, crashprotection);
			gui.SubMenu("��������", NULL, otherprotection);
			if (gui.Option("�������б���", NULL))
			{
				g_Session.antikick = true;
				g_Session.antiinvite = true;
				g_Session.antigiveweapon = true;
				g_Session.antifreeze = true;
				g_Session.antifire = true;
				g_Session.antiexplosion = true;
				g_Session.antiPTFX = true;
				g_Session.antistar = true;
				g_Session.antiremoveweapon = true;
				g_Session.antirequsetcontrol = true;
				g_Session.blockallnetworkevents = true;
				g_Session.antireport = true;
				g_Session.antistat = true;
				g_Session.antidrop = true;
				g_Session.antivotekick = true;
				g_Session.antiattachment = true;
				g_Session.anticage = true;
				g_Session.blockobjCrash = true;
				g_Session.blockPedCrash = true;
				g_Session.blockvehCrash = true;
				g_Session.SECrashprotex = true;
				g_Session.nonhostkickprotex = true;
				g_Session.antiSPKick = true;
				g_Session.anticeokick = true;
				g_Session.ceo_events = true;
				g_Session.bannerprotex = true;
				g_Session.blackscreen = true;
				g_Session.Transaction_Error = true;
				g_Session.antiapartmenttp = true;
				g_Session.antiremotebounty = true;
				g_Session.antiremotevehkick = true;
				g_Session.load_screen = true;
				g_Session.antiremoteforcemission = true;
				MenuFunctions::Notify("�������Ա���ִ�гɹ���");
			}
			if (gui.Option("�ر����б���", NULL))
			{
				g_Session.antikick = false;
				g_Session.antiinvite = false;
				g_Session.antigiveweapon = false;
				g_Session.antifreeze = false;
				g_Session.antifire = false;
				g_Session.antiexplosion = false;
				g_Session.antiPTFX = false;
				g_Session.antistar = false;
				g_Session.antiremoveweapon = false;
				g_Session.antirequsetcontrol = false;
				g_Session.blockallnetworkevents = false;
				g_Session.antireport = false;
				g_Session.antistat = false;
				g_Session.antidrop = false;
				g_Session.antivotekick = false;
				g_Session.antiattachment = false;
				g_Session.anticage = false;
				g_Session.blockobjCrash = false;
				g_Session.blockPedCrash = false;
				g_Session.blockvehCrash = false;
				g_Session.SECrashprotex = false;
				g_Session.nonhostkickprotex = false;
				g_Session.antiSPKick = false;
				g_Session.anticeokick = false;
				g_Session.ceo_events = false;
				g_Session.bannerprotex = false;
				g_Session.blackscreen = false;
				g_Session.Transaction_Error = false;
				g_Session.antiapartmenttp = false;
				g_Session.antiremotebounty = false;
				g_Session.antiremotevehkick = false;
				g_Session.load_screen = false;
				g_Session.antiremoteforcemission = false;
				MenuFunctions::Notify("�ر����Ա���ִ�гɹ���");
			}
		}
		break;
		case scriptprotection:
		{
			gui.Title("�ű��¼�");
			gui.Bool("�ű���", NULL, g_Session.antikick);
			gui.Bool("��������", NULL, g_Session.nonhostkickprotex);
			gui.Bool("�ߵ�����ģʽ", NULL, g_Session.antiSPKick);
			gui.Bool("CEO��", NULL, g_Session.anticeokick);
			gui.Bool("CEO����", NULL, g_Session.ceo_events);
			gui.Bool("�պ��", NULL, g_Session.bannerprotex);
			gui.Bool("���޺���", NULL, g_Session.blackscreen);
			gui.Bool("���״���", NULL, g_Session.Transaction_Error);
			gui.Bool("��Ԣ����", NULL, g_Session.antiapartmenttp);
			gui.Bool("��������", NULL, g_Session.antiremotebounty);
			gui.Bool("�߳��ؾ�", NULL, g_Session.antiremotevehkick);
			gui.Bool("���޼�����Ļ", NULL, g_Session.load_screen);
			gui.Bool("ǿ��ִ������", NULL, g_Session.antiremoteforcemission);
		}
		break;
		case networkprotection:
		{
			gui.Title("�����¼�");
			gui.Bool("����", NULL, g_Session.antifreeze);
			gui.Bool("����", NULL, g_Session.antifire);
			gui.Bool("��ը", NULL, g_Session.antiexplosion);
			gui.Bool("����", NULL, g_Session.antiinvite);
			gui.Bool("������Ч", NULL, g_Session.antiPTFX);
			gui.Bool("��������", NULL, g_Session.antigiveweapon);
			gui.Bool("�Ƴ�����", NULL, g_Session.antiremoveweapon);
			gui.Bool("�������", NULL, g_Session.antirequsetcontrol);
			gui.Bool("����ͨ���ȼ�", NULL, g_Session.antistar);
			gui.Bool("�������������¼�", NULL, g_Session.blockallnetworkevents);
		}
		break;
		case otherprotection:
		{
			gui.Title("��������");
			gui.Bool("���ؾٱ�", NULL, g_Session.antireport);
			gui.Bool("����ͳ��", NULL, g_Session.antistat);
			gui.Bool("���ص���", NULL, g_Session.antidrop);
			gui.Bool("��������", NULL, g_Session.anticage);
			gui.Bool("����ͶƱ��", NULL, g_Session.antivotekick);
		}
		break;
		case crashprotection:
		{
			gui.Title("��������");
			gui.Bool("��ֹ��Чģ�ͱ���", NULL, g_Session.blockobjCrash);
			gui.Bool("��ֹ��ЧPED����", NULL, g_Session.blockPedCrash);
			gui.Bool("��ֹ��Ч�ؾ߱���", NULL, g_Session.blockvehCrash);
			gui.Bool("��ֹ�ű��¼�����", NULL, g_Session.SECrashprotex);
			gui.Bool("~r~��ֹ�������忿��", NULL, g_Session.blockallentity);
		}
		break;
		case modelchanger:
		{
			gui.Title("ģ��ѡ��");
			gui.SubMenu("����ģ��", NULL, onlinemodel);
			gui.SubMenu("����ģ��", NULL, animalmodel);
			gui.SubMenu("����ģ��", NULL, pedmodel);
		}
		break;
		case animalmodel:
		{
			gui.Title("����ģ��");
			for (auto model : Ped_List_animal) {
				if (gui.Option(model, NULL)) MenuFunctions::bianshen(model);
			}
		}
		break;
		case pedmodel:
		{
			gui.Title("����ģ��");
			for (auto model : pedModels) {
				if (gui.Option(model, NULL)) MenuFunctions::bianshen(model);
			}
		}
		break;
		case onlinemodel:
		{
			gui.Title("����ģ��");
			if (gui.Option("����Ĭ���н�ɫ", NULL))
			{
				Hash hash = 0x705E61F2;
				if (checkModel(hash))
				{
					PLAYER::SET_PLAYER_MODEL(PLAYER::PLAYER_ID(), hash);
				}
			}
			if (gui.Option("����Ĭ��Ů��ɫ", NULL))
			{
				Hash hash = 0x9C9EFFD8;
				if (checkModel(hash))
				{
					PLAYER::SET_PLAYER_MODEL(PLAYER::PLAYER_ID(), hash);
				}
			}
		}
		break;
		case misc:
		{
			gui.Title("����ѡ��");
			gui.Bool("�����ֻ�", NULL, g_Misc.disablephone);
			gui.Bool("����HUD", NULL, g_Misc.hidehud);
			gui.Bool("��ʾFPS", NULL, g_Misc.displayfps);
			gui.Bool("��ʾ����", NULL, g_Misc.displaycoord);
			gui.Bool("����ʮ��׼��", NULL, g_Misc.aimcross);
			gui.Bool("���ٱ�", "��Ҫ����ڳ��ϲ�����ʾ", g_Misc.SpeedoBool);
			gui.Bool("��ͼ��С", NULL, g_Misc.ditudaxiao);
			if (gui.Option("ˢ��С��ͼ", NULL))
			{
				HUD::FLASH_MINIMAP_DISPLAY();
			}
			if (gui.Option("�������Ͻ̳�", NULL))
			{
				if (NETWORK::NETWORK_IS_IN_TUTORIAL_SESSION())
				{
					NETWORK::NETWORK_END_TUTORIAL_SESSION();
				}
			}
			if (gui.Option("�������Ϲ�������", "�����������ڲ��ŵľ��鶯��")) {
				if (NETWORK::NETWORK_IS_IN_TUTORIAL_SESSION())
				{
					NETWORK::NETWORK_END_TUTORIAL_SESSION();
				}

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_FM_CUT_DONE"), -1, 1);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_FM_CUT_DONE_2"), -1, 1);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_FM_CUT_DONE"), -1, 1);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_FM_CUT_DONE_2"), -1, 1);

				CUTSCENE::STOP_CUTSCENE_IMMEDIATELY();
				CAM::DO_SCREEN_FADE_IN(1000);
			}

		}
		break;
		case word:
		{
			gui.Title("GTA-onlineѡ��");
			gui.SubMenu("��������", NULL, weatherchange);
			gui.SubMenu("����ʱ��", NULL, kongzhishijian);
			gui.SubMenu("�ؾ�", NULL, shijiezaiju);
			gui.SubMenu("NPC", NULL, shijienpc);
			gui.Bool("ʧ��", NULL, g_World.gravity);
			if (gui.Option("���ò���ǿ��", NULL))
			{
				WATER::_RESET_CURRENT_INTENSITY;
			}
			if (gui.Option("�������", NULL))
			{
				Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), 1);
				MISC::CLEAR_AREA(coords.x, coords.y, coords.z, 200, true, false, false, false);
				MISC::_CLEAR_AREA_OF_EVERYTHING(coords.x, coords.y, coords.z, 200, false, false, false, false);
			}
			float speed;
			if (gui.Float("���ٵ���", NULL, speed, 0, 12))
			{
				MISC::SET_WIND(speed);
				MISC::SET_WIND_SPEED(speed);
			}
			float direction;
			if (gui.Float("�������", NULL, direction, 0, 7))
			{
				MISC::SET_WIND_DIRECTION(direction);
			}
			if (gui.Option("ǿ������", NULL))
			{
				MISC::FORCE_LIGHTNING_FLASH();
			}
		}
		break;
		case weatherchange:
		{
			gui.Title("��������");
			if (gui.Option("�������~e~[����]", NULL))
			{
				MISC::SET_RANDOM_WEATHER_TYPE();
			}
			if (gui.Option("����", NULL))
			{
				MISC::SET_OVERRIDE_WEATHER("CLEAR");
				MISC::SET_WEATHER_TYPE_NOW("CLEAR");
				MISC::SET_WEATHER_TYPE_NOW_PERSIST("CLEAR");
			}
			if (gui.Option("��������", NULL))
			{
				MISC::SET_OVERRIDE_WEATHER("EXTRASUNNY");
				MISC::SET_WEATHER_TYPE_NOW("EXTRASUNNY");
				MISC::SET_WEATHER_TYPE_NOW_PERSIST("EXTRASUNNY");
			}
			if (gui.Option("����", NULL))
			{
				MISC::SET_OVERRIDE_WEATHER("CLOUDS");
				MISC::SET_WEATHER_TYPE_NOW("CLOUDS");
				MISC::SET_WEATHER_TYPE_NOW_PERSIST("CLOUDS");
			}
			if (gui.Option("����", NULL))
			{
				MISC::SET_OVERRIDE_WEATHER("OVERCAST");
				MISC::SET_WEATHER_TYPE_NOW("OVERCAST");
				MISC::SET_WEATHER_TYPE_NOW_PERSIST("OVERCAST");
			}
			if (gui.Option("����", NULL))
			{
				MISC::SET_OVERRIDE_WEATHER("RAIN");
				MISC::SET_WEATHER_TYPE_NOW("RAIN");
				MISC::SET_WEATHER_TYPE_NOW_PERSIST("RAIN");
			}
			if (gui.Option("̫����", NULL))
			{
				MISC::SET_OVERRIDE_WEATHER("CLEARING");
				MISC::SET_WEATHER_TYPE_NOW("CLEARING");
				MISC::SET_WEATHER_TYPE_NOW_PERSIST("CLEARING");
			}
			if (gui.Option("������", NULL))
			{
				MISC::SET_OVERRIDE_WEATHER("THUNDER");
				MISC::SET_WEATHER_TYPE_NOW("THUNDER");
				MISC::SET_WEATHER_TYPE_NOW_PERSIST("THUNDER");
			}
			if (gui.Option("ɳ����", NULL))
			{
				MISC::SET_OVERRIDE_WEATHER("Neutral");
				MISC::SET_WEATHER_TYPE_NOW("Neutral");
				MISC::SET_WEATHER_TYPE_NOW_PERSIST("Neutral");
			}
			if (gui.Option("������", NULL))
			{
				MISC::SET_OVERRIDE_WEATHER("SMOG");
				MISC::SET_WEATHER_TYPE_NOW("SMOG");
				MISC::SET_WEATHER_TYPE_NOW_PERSIST("SMOG");
			}
			if (gui.Option("������", NULL))
			{
				MISC::SET_OVERRIDE_WEATHER("FOGGY");
				MISC::SET_WEATHER_TYPE_NOW("FOGGY");
				MISC::SET_WEATHER_TYPE_NOW_PERSIST("FOGGY");
			}
			if (gui.Option("��ѩ", NULL))
			{
				MISC::SET_OVERRIDE_WEATHER("SNOWLIGHT");
				MISC::SET_WEATHER_TYPE_NOW("SNOWLIGHT");
				MISC::SET_WEATHER_TYPE_NOW_PERSIST("SNOWLIGHT");
			}
			if (gui.Option("��ѩ", NULL))
			{
				MISC::SET_OVERRIDE_WEATHER("BLIZZARD");
				MISC::SET_WEATHER_TYPE_NOW("BLIZZARD");
				MISC::SET_WEATHER_TYPE_NOW_PERSIST("BLIZZARD");
			}
			if (gui.Option("��ʥ��", NULL))
			{
				MISC::SET_OVERRIDE_WEATHER("Halloween");
				MISC::SET_WEATHER_TYPE_NOW("Halloween");
				MISC::SET_WEATHER_TYPE_NOW_PERSIST("Halloween");
			}
		}
		break;
		case kongzhishijian:
		{
			gui.Title("����ʱ��");
			int sample_hour = CLOCK::GET_CLOCK_HOURS();
			if (gui.Int("Сʱ", NULL, g_World.timeer, 0, 24))
			{
				NETWORK::NETWORK_OVERRIDE_CLOCK_TIME(g_World.timeer, g_World.minute, g_World.second);
			}
			if (gui.Int("����", NULL, g_World.minute, 0, 60))
			{
				NETWORK::NETWORK_OVERRIDE_CLOCK_TIME(g_World.timeer, g_World.minute, g_World.second);
			}
			if (gui.Int("��", NULL, g_World.second, 0, 60))
			{
				NETWORK::NETWORK_OVERRIDE_CLOCK_TIME(g_World.timeer, g_World.minute, g_World.second);
			}
			if (gui.Option("ǰ��һСʱ", NULL))
			{
				if (sample_hour + 1 == 24)NETWORK::NETWORK_OVERRIDE_CLOCK_TIME(0, 1, 1);
				else NETWORK::NETWORK_OVERRIDE_CLOCK_TIME((sample_hour + 1), 0, 59);
			}
			if (gui.Option("����һСʱ", NULL))
			{
				if (sample_hour - 1 == -1)NETWORK::NETWORK_OVERRIDE_CLOCK_TIME(22, 59, 0);
				else NETWORK::NETWORK_OVERRIDE_CLOCK_TIME((sample_hour - 1), 0, 1);
			}
			if (gui.Option("ͬ��ϵͳʱ��", NULL))
			{
				int year; int month; int day; int hour; int minute; int second;
				CLOCK::GET_POSIX_TIME(&year, &month, &day, &hour, &minute, &second);
				CLOCK::GET_LOCAL_TIME(&year, &month, &day, &hour, &minute, &second);
				CLOCK::SET_CLOCK_TIME(hour, minute, second);
			}
			if (gui.Option("����ʱ��", NULL))
			{
				NETWORK::NETWORK_CLEAR_CLOCK_TIME_OVERRIDE();
			}

		}
		break;
		case shijienpc:
		{
			gui.Title("NPC");
			gui.Bool("��ը����NPC", NULL, g_World.explodnearped);
			gui.Bool("ɱ������NPC", NULL, g_World.killpeds);
			gui.Bool("ɾ������NPC", NULL, g_World.deleteNPC);
			if (gui.Option("��������", NULL))
			{
				const int ElementAmount = 20;
				const int ArrSize = ElementAmount * 2 + 2;

				Ped* peds = new Ped[ArrSize];
				peds[0] = ElementAmount;

				int PedFound = PED::GET_PED_NEARBY_PEDS(PLAYER::PLAYER_PED_ID(), peds, -1);

				for (int i = 0; i < PedFound; i++)
				{
					int OffsetID = i * 2 + 2;
					MenuFunctions::requestControlOfEnt(peds[OffsetID]);
					if (ENTITY::DOES_ENTITY_EXIST(peds[OffsetID]) && PLAYER::PLAYER_PED_ID() != peds[OffsetID])
					{
						BRAIN::TASK_HANDS_UP(peds[OffsetID], 10000, PLAYER::PLAYER_PED_ID(), true, true);
					}
				}
			}
			if (gui.Option("վ�ű�", NULL))
			{
				const int ElementAmount = 10;
				const int ArrSize = ElementAmount * 2 + 2;

				Ped* peds = new Ped[ArrSize];
				peds[0] = ElementAmount;

				int PedFound = PED::GET_PED_NEARBY_PEDS(PLAYER::PLAYER_PED_ID(), peds, -1);

				for (int i = 0; i < PedFound; i++)
				{
					int OffsetID = i * 2 + 2;
					MenuFunctions::requestControlOfEnt(peds[OffsetID]);
					if (ENTITY::DOES_ENTITY_EXIST(peds[OffsetID]) && PLAYER::PLAYER_PED_ID() != peds[OffsetID])
					{
						BRAIN::TASK_STAND_STILL(peds[OffsetID], 10000);
					}
				}
			}
			if (gui.Option("������Ծ", NULL))
			{
				const int ElementAmount = 10;
				const int ArrSize = ElementAmount * 2 + 2;

				Ped* peds = new Ped[ArrSize];
				peds[0] = ElementAmount;

				int PedFound = PED::GET_PED_NEARBY_PEDS(PLAYER::PLAYER_PED_ID(), peds, -1);

				for (int i = 0; i < PedFound; i++)
				{
					int OffsetID = i * 2 + 2;
					MenuFunctions::requestControlOfEnt(peds[OffsetID]);
					if (ENTITY::DOES_ENTITY_EXIST(peds[OffsetID]) && PLAYER::PLAYER_PED_ID() != peds[OffsetID])
					{
						BRAIN::TASK_JUMP(peds[OffsetID], true, 0, 0);
					}
				}
			}
			if (gui.Option("�߳�����˾��", NULL))
			{
				const int ElementAmount = 10;
				const int ArrSize = ElementAmount * 2 + 2;

				Ped* peds = new Ped[ArrSize];
				peds[0] = ElementAmount;

				int PedFound = PED::GET_PED_NEARBY_PEDS(PLAYER::PLAYER_PED_ID(), peds, -1);

				for (int i = 0; i < PedFound; i++)
				{
					int OffsetID = i * 2 + 2;
					MenuFunctions::requestControlOfEnt(peds[OffsetID]);
					if (ENTITY::DOES_ENTITY_EXIST(peds[OffsetID]) && PLAYER::PLAYER_PED_ID() != peds[OffsetID])
					{
						BRAIN::TASK_LEAVE_ANY_VEHICLE(peds[OffsetID], true, true);
					}
				}
			}
			if (gui.Option("����NPC���͵��Լ�", NULL))
			{
				Vector3 myPos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), 1);
				const int ElementAmount = 10;
				const int ArrSize = ElementAmount * 2 + 2;
				Ped* peds = new Ped[ArrSize];
				peds[0] = ElementAmount;
				int PedFound = PED::GET_PED_NEARBY_PEDS(PLAYER::PLAYER_PED_ID(), peds, -1);
				for (int i = 0; i < PedFound; i++)
				{
					int OffsetID = i * 2 + 2;
					if (ENTITY::DOES_ENTITY_EXIST(peds[OffsetID]) && PLAYER::PLAYER_PED_ID() != peds[OffsetID])
					{
						MenuFunctions::requestControlOfEnt(peds[OffsetID]);
						ENTITY::SET_ENTITY_COORDS(peds[OffsetID], myPos.x, myPos.y, myPos.z, false, false, false, false);
					}
				}
				delete[] peds;
			}
		}
		break;
		case shijiezaiju:
		{
			gui.Title("�ؾ�");
			gui.Bool("��ը�����ؾ�", NULL, g_World.explodnearcar);
			gui.Bool("���ٸ����ؾ�", NULL, g_World.boostnearcar);
			gui.Bool("ɾ�������ؾ�", NULL, g_World.deletenearcar);
			if (gui.Option("���������ؾ�", NULL))
			{
				const int ElementAmount = 20;
				const int ArrSize = ElementAmount * 2 + 2;

				Vehicle* vehs = new Vehicle[ArrSize];
				vehs[0] = ElementAmount;
				int VehFound = PED::GET_PED_NEARBY_VEHICLES(PLAYER::PLAYER_PED_ID(), vehs);

				for (int i = 0; i < VehFound; i++)
				{
					int OffsetID = i * 2 + 2;
					if (vehs[OffsetID] != PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false))
					{
						MenuFunctions::requestControlOfEnt(vehs[OffsetID]);
						VEHICLE::SET_VEHICLE_MOD_KIT(vehs[OffsetID], 0);
						for (int i = 0; i < 50; i++)
						{
							VEHICLE::SET_VEHICLE_MOD(vehs[OffsetID], i, VEHICLE::GET_NUM_VEHICLE_MODS(vehs[OffsetID], i) - 1, false);
						}
					}
				}
				delete[] vehs;
			}
			if (gui.Option("����˾����������", NULL))
			{
				int WaypointHandle = HUD::GET_FIRST_BLIP_INFO_ID(8);
				Ped Driver = PLAYER::PLAYER_PED_ID();
				Vector3 waypoint1 = HUD::GET_BLIP_COORDS(WaypointHandle);
				const int ElementAmount = 10;
				const int ArrSize = ElementAmount * 2 + 2;

				Ped* peds = new Ped[ArrSize];
				peds[0] = ElementAmount;

				int PedFound = PED::GET_PED_NEARBY_PEDS(PLAYER::PLAYER_PED_ID(), peds, -1);

				for (int i = 0; i < PedFound; i++)
				{
					int OffsetID = i * 2 + 2;
					MenuFunctions::requestControlOfEnt(peds[OffsetID]);
				}
				for (int i = 0; i < PedFound; i++)
				{
					int OffsetID = i * 2 + 2;
					MenuFunctions::requestControlOfEnt(peds[OffsetID]);
					Vehicle veh = PED::GET_VEHICLE_PED_IS_USING(peds[OffsetID]);
					if (ENTITY::DOES_ENTITY_EXIST(peds[OffsetID]) && PLAYER::PLAYER_PED_ID() != peds[OffsetID])
					{
						BRAIN::TASK_VEHICLE_DRIVE_TO_COORD(peds[OffsetID], veh, waypoint1.x, waypoint1.y, waypoint1.z, 40, 1, ENTITY::GET_ENTITY_MODEL(veh), 7, 6, -1);
					}
				}

			}
		}
		break;
		case recovery:
		{
			gui.Title("Σ�չ���");
			gui.SubMenu("ˢ����", "��Ϊ����ѡ��-����ʹ��", jinqian);
			gui.SubMenu("��ɫ����", NULL, attributes);
			gui.SubMenu("����ѡ��", NULL, unlocks);
			gui.SubMenu("�Զ����ʲ�����", NULL, assetmanager);
			gui.SubMenu("�칫��ѡ��", NULL, CEO);
			gui.SubMenu("�ر�ѡ��", NULL, dibao);
			gui.SubMenu("����������", NULL, arenaWareditor);
			gui.SubMenu("�ȼ�ѡ��", NULL, RP);
		}
		break;
		case unlocks:
		{
			gui.Title("����ѡ��");
			gui.SubMenu("DLC����", NULL, unlock_dlc);
			gui.SubMenu("�ʲ�", NULL, unlock_zc);
			gui.SubMenu("����", NULL, unlock_qj);
			gui.SubMenu("����", NULL, unlock_rw);
			gui.SubMenu("��װ", NULL, unlock_fz);
			gui.SubMenu("����", NULL, unlock_ws);
			gui.SubMenu("�ؾ�", NULL, unlock_zj);
			gui.SubMenu("��������", NULL, unlock_wq);
			gui.SubMenu("����ļ�����", NULL, unlock_ts);
			if (gui.Option("�����ع���ҽ���", NULL))
			{
				script_global({ 103635 }, 1);
				script_global({ 152523 }, 2);
				MenuFunctions::Notify("�ѽ����ع���ҽ���");
			}
			if (gui.Option("������ݶ����޴�", NULL))
			{
				UNL::Vanilla_Unicorn_Award();
				MenuFunctions::Notify("�ѽ�����ݶ����޴�");
			}
			if (gui.Option("���������ȴ", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ORBITAL_CANNON_COOLDOWN"), 0, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_ORBITAL_CANNON_COOLDOWN"), 0, 0);
				MenuFunctions::Notify("������������ȴʱ��!");
			}
			if (gui.Option("���м�Уȫ��ͨ��", NULL))
			{
				UNL::The_flight_school_is_all_cleared();
				MenuFunctions::Notify("���м�Уȫ��ͨ�����!");
			}
			if (gui.Option("�������״̬", NULL))
			{
				UNL::Clear_mind();
				MenuFunctions::Notify((char*)"�������״̬���!");
			}
			if (gui.Option("����ٱ�", NULL))
			{
				UNL::Clear_report();
				MenuFunctions::Notify((char*)"����ٱ��ɹ�!");
			}
			if (gui.Option("������Ǯ", NULL)) {
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("SP0_TOTAL_CASH"), 2147483647, 1);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("SP1_TOTAL_CASH"), 2147483647, 1);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("SP2_TOTAL_CASH"), 2147483647, 1);
				MenuFunctions::Notify((char*)"�ѳɹ���������������ɫ��Ǯ!");
			}
		}
		break;
		case unlock_wq:
		{
			gui.Title("��������");
			if (gui.Option("��ʽ����ǹ", NULL))
			{
				script_global({ 262145 + 32865 }, 1);
				MenuFunctions::Notify("�ѽ�����ʽ����ǹ");
			}
			if (gui.Option("ʯ��", NULL))
			{
				STATS::STAT_SET_MASKED_INT(MISC::GET_HASH_KEY((char*)"MP_NGDLCPSTAT_INT0"), 5, 16, 1, 1);
				STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY((char*)"MPPLY_MELEECHLENGECOMPLETED"), 1, true);
				MenuFunctions::Notify("�ѽ���ʯ��,��ս����Ч");
			}
			if (gui.Option("˫��ʽ������ǹ", NULL))
			{
				STATS::STAT_SET_MASKED_INT(MISC::GET_HASH_KEY((char*)"GANGOPSPSTAT_INT102"), 3, 24, 1, 1);
				STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY((char*)"MPPLY_HEADSHOTCHLENGECOMPLETED"), 1, true);
				MenuFunctions::Notify("�ѽ���˫��ʽ������ǹ,��ս����Ч");
			}
			if (gui.Option("����������ǹ", NULL))
			{
				STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY((char*)"MPPLY_NAVYREVOLVERCOMPLETED"), 1, true);
				MenuFunctions::Notify("�ѽ�������������ǹ");
			}
			if (gui.Option("�մ���ǹ", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_CAS_HEIST_FLOW"), 4096, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_CAS_HEIST_FLOW"), 4096, true);
				MenuFunctions::Notify("�ѽ����մ���ǹ");
			}
			if (gui.Option("ԭ����ǹ", NULL))
			{
				script_global({ 103634 }, 90);
				MenuFunctions::Notify("�ѽ���ԭ����ǹ");
			}
		}
		break;
		case unlock_zj:
		{
			gui.Title("�ؾ�");
			//if (gui.Option("����һЩ�����ۿ�", NULL))
			//{
			//	UNL::Unlock_Lots_of_Hats_And_Shirts();
			//	MenuFunctions::Notify("�ѽ���һЩ�����ۿ�");
			//}
			if (gui.Option("���⳵�Ʒ�", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_AWD_TAXIDRIVER"), 100, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_AWD_TAXIDRIVER"), 100, true);
				MenuFunctions::Notify("�ѽ������⳵�Ʒ�");
			}
			if (gui.Option("����ʥ̫��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_CRDEADLINE"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_CRDEADLINE"), -1, true);
				MenuFunctions::Notify("�ѽ���ʥ̫��");
			}
		}
		break;
		case unlock_ws:
		{
			gui.Title("����");
			//if (gui.Option("����һЩ����", NULL))
			//{
			//	UNL::Unlock_Lots_of_Hats_And_Shirts();
			//	MenuFunctions::Notify("�ѽ���һЩ����");
			//}
			if (gui.Option("��������������", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TATTOO_FM_CURRENT_32"), 32768, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TATTOO_FM_CURRENT_32"), 67108864, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TATTOO_FM_CURRENT_32"), 32768, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TATTOO_FM_CURRENT_32"), 67108864, true);
				MenuFunctions::Notify("�ѽ���������������������ս����Ч");
			}
		}
		break;
		case unlock_fz:
		{
			gui.Title("��װ");
			if (gui.Option("�����ܶ�ñ�Ӻͳ���", NULL))
			{
				UNL::Unlock_Lots_of_Hats_And_Shirts();
				MenuFunctions::Notify("�ѽ����ܶ�ñ�Ӻͳ���");
			}
			if (gui.Option("�������Ұ��װ��", NULL))
			{
				globalHandle(262145).At(32938).As<int>() = 1;
				MenuFunctions::Notify("�ѽ������Ұ��װ��");
			}
			if (gui.Option("����Don't Cross The Line Tee", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_DCTL_WINS"), 500, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_DCTL_PLAY_COUNT"), 750, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_DCTL_WINS"), 500, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_DCTL_PLAY_COUNT"), 750, true);
				MenuFunctions::Notify("�ѽ���Don't Cross The Line Tee");
			}
		}
		break;
		case unlock_ts:
		{
			gui.Title("����ļ�����");
			gui.SubMenu("ʥ���ڷ�װ", NULL, sdj_dlc);
			gui.Bool("������", "����Ҫ��������ʹ�ö����յ�һЩ����", g_Unlock.duliri);
			if (gui.Option("�������˽�", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TURN_ON_VALENTINE_WEAPON"), 12030, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TURN_ON_VALENTINE_CLOTHING"), 12034, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TURN_ON_VALENTINE_2016_CLOTHING"), 13396, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TURN_ON_VALENTINE_2016_VEHICLE"), 13397, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TURN_ON_VALENTINE_WEAPON"), 12030, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TURN_ON_VALENTINE_CLOTHING"), 12034, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TURN_ON_VALENTINE_2016_CLOTHING"), 13396, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TURN_ON_VALENTINE_2016_VEHICLE"), 13397, true);
				globalHandle(262145).At(7059).As<int>() = 1;
				MenuFunctions::Notify("�ѽ������˽�");
			}
		}
		break;
		case sdj_dlc:
		{
			gui.Title("ʥ���ڷ�װ");
			gui.Bool("�ƹ�ʥ���ڷ�װ", "����Ҫ�����������ʥ���ڷ�װ", g_Unlock.shengdanjie);
			if (gui.Option("����ʥ����װ", NULL))
			{
				for (int i = 0; i < 20; i++)
				{
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MPPLY_XMASLIVERIES"), i, true);
				}
				MenuFunctions::Notify("�ѽ���ʥ����װ");
			}
			if (gui.Option("����ʥ���ڵ�����", NULL))
			{
				UNL::Unlock_Christmas_Content();
				MenuFunctions::Notify("�ѽ���ʥ���ڵ�����");
			}
		}
		break;
		case unlock_rw:
		{
			gui.Title("����");
			if (gui.Option("��������Ƶ�����", NULL))
			{
				UNL::Cayo_Perico_Unlockables();
				MenuFunctions::Notify("�ѽ�������Ƶ�����");
			}
			if (gui.Option("�������⳵����", NULL))
			{
				script_global({ 262145 + 33770 }, 1);
				MenuFunctions::Notify("�ѽ������⳵����");
			}
			if (gui.Option("������ͧ����", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_YACHT_MISSION_PROG"), 0, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_YACHT_MISSION_FLOW"), 21845, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_CASINO_DECORATION_GIFT_1"), -1, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_YACHT_MISSION_PROG"), 0, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_YACHT_MISSION_FLOW"), 21845, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_CASINO_DECORATION_GIFT_1"), -1, true);
				MenuFunctions::Notify("�ѽ�����ͧ����");
			}
			if (gui.Option("����������ϵ��", NULL))
			{
				UNL::Unlock_All_Contacts();
				MenuFunctions::Notify("�ѽ���������ϵ��");
			}
			if (gui.Option("������������ֱ�����һ��", NULL))
			{
				UNL::Skip_Lamar_Missions_To_The_Last_One();
				MenuFunctions::Notify("��������������ֱ�����һ��");
			}
		}
		break;
		case unlock_qj:
		{
			gui.Title("����");
			if (gui.Option("����Ƶ�����", NULL))
			{
				UNL::Cayo_Perico_Heist();
				MenuFunctions::Notify("�ѽ�������Ƶ�����");
			}
			if (gui.Option("����ĳ�����", NULL))
			{
				UNL::Diamond_Casino_Heist();
				MenuFunctions::Notify("�ѽ�������ĳ�����");
			}
			if (gui.Option("ĩ�պ���", NULL))
			{
				UNL::Doomsday_Heist();
				MenuFunctions::Notify("�ѽ���ĩ�պ���");
			}
			if (gui.Option("��Ԣ������", NULL))
			{
				UNL::Classic_Heist();
				MenuFunctions::Notify("�ѽ�����Ԣ������");
			}
			if (gui.Option("��������ͬ", NULL))
			{
				UNL::The_Contract_Agency();
				MenuFunctions::Notify("�ѽ�����������ͬ");
			}
		}
		break;
		case unlock_zc:
		{
			gui.Title("�ʲ�");
			gui.SubMenu("��Ϸ������", NULL, yxt_dlc);
			if (gui.Option("�»ü�ʵ�����豸����", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_AWD_CALLME"), 10, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_AWD_CALLME"), 10, true);
				MenuFunctions::Notify("�ѽ����»ü�ʵ�����豸����");
			}
			if (gui.Option("����ҹ�ܻά��", NULL))
			{
				UNL::Unlock_nightclub_awards();
				MenuFunctions::Notify("�ѽ���ҹ�ܻά��");
			}
			if (gui.Option("�����ĳ��̵��˿����", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_VC_ACE_OF_SPADES"), 27530, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_VC_ACE_OF_DIAMONDS"), 27533, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_VC_ACE_OF_SPADES"), 27530, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_VC_ACE_OF_DIAMONDS"), 27533, true);
				MenuFunctions::Notify("�ѽ����ĳ��̵��˿����");
			}
			if (gui.Option("���칫��/Ħ�а�����װ��", NULL))
			{
				MenuFunctions::Notify("�Ѹ��칫��/Ħ�а�����װ��");
			}
		}
		break;
		case yxt_dlc:
		{
			gui.Title("��Ϸ������");
			if (gui.Option("������Ϸ�����������", NULL))
			{
				UNL::Unlock_arcade_trophies_and_toys();
				MenuFunctions::Notify("�ѽ�����Ϸ�����������");
			}
			if (gui.Option("������װ", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_STREET_CRIMES_BOXART_TEE"), 28316, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_RED_FAME_OR_SHAME_KRONOS"), 28336, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_STREET_CRIMES_BOXART_TEE"), 28316, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_RED_FAME_OR_SHAME_KRONOS"), 28336, true);
				MenuFunctions::Notify("�ѽ�����װ");
			}
		}
		break;
		case unlock_dlc:
		{

			gui.Title("DLC����");
			gui.SubMenu("������DLC", NULL, jjc_dlc);
			gui.SubMenu("2020������DLC", NULL, xt_dlc);
			gui.SubMenu("���ѻ�DLC", NULL, cyh_dlc);
			gui.SubMenu("The Contract DLC", NULL, tc_dlc);
			gui.SubMenu("���Ｏ��DLC", NULL, fzjt_dlc);
			gui.SubMenu("��ƷվDLC", NULL, dpz_dlc);
		}
		break;
		case dpz_dlc:
		{
			gui.Title("��ƷվDLC");
			if (gui.Option("������װ", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_EVENT_LOGIN_DLC22022_ICE_VINYL_JACKET_3"), 33973, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_EVENT_LOGIN_DLC22022_ICE_VINYL_JACKET_3"), 33973, true);
				STATS::STAT_SET_INT(-711496356, 34112, true);
				MenuFunctions::Notify("�ѽ�����װ");
			}
		}
		break;
		case fzjt_dlc:
		{
			gui.Title("���Ｏ��DLC");
			if (gui.Option("�п�/ë��/��ñ��/����", NULL))
			{
				STATS::STAT_SET_INT(-1967834023, 32907, true);
				STATS::STAT_SET_INT(-1263992372, 32914, true);
				STATS::STAT_SET_INT(-206691492, 32930, true);
				STATS::STAT_SET_INT(-1577621449, 32935, true);
				MenuFunctions::Notify("�ѽ����п�/ë��/��ñ��/����");
			}
			if (gui.Option("����/�Ʒ�ñ/ñ��", NULL))
			{
				STATS::STAT_SET_INT(638571354, 32917, true);
				STATS::STAT_SET_INT(96152168, 32919, true);
				STATS::STAT_SET_INT(-2120678580, 32936, true);
				STATS::STAT_SET_INT(-1003907171, 32937, true);
				STATS::STAT_SET_INT(191276118, 32988, true);
				STATS::STAT_SET_INT(-1484490421, 33001, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_SUM2_CHRISTMAS_BEERHAT_LEMON"), 33654, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_SUM2_CHRISTMAS_BEERHAT_RED_REINDEER"), 33662, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_SUM2_CHRISTMAS_BEERHAT_LEMON"), 33654, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_SUM2_CHRISTMAS_BEERHAT_RED_REINDEER"), 33662, true);
				script_global({ 262145 + 32913 }, 1);
				MenuFunctions::Notify("�ѽ�������/�Ʒ�ñ/ñ��");
			}
			if (gui.Option("����/���/�Ƽ���ħ", NULL))
			{
				STATS::STAT_SET_INT(-889497715, 33002, true);
				STATS::STAT_SET_INT(-1162924007, 33012, true);
				STATS::STAT_SET_INT(1096886904, 32922, true);
				STATS::STAT_SET_INT(-359187968, 32927, true);
				STATS::STAT_SET_INT(190205845, 32942, true);
				STATS::STAT_SET_INT(-171130807, 32950, true);
				STATS::STAT_SET_INT(1424509866, 32954, true);
				STATS::STAT_SET_INT(-1677619307, 32957, true);
				STATS::STAT_SET_INT(-1285035231, 32958, true);
				STATS::STAT_SET_INT(-1792568167, 32983, true);
				script_global({ 262145 + 32929 }, 1);
				MenuFunctions::Notify("�ѽ�������/���/�Ƽ���ħ");
			}
			if (gui.Option("Ь��(����)/�ϻ�", NULL))
			{
				STATS::STAT_SET_INT(467678514, 32984, true);
				STATS::STAT_SET_INT(169972145, 32987, true);
				STATS::STAT_SET_INT(245491514, 33014, true);
				STATS::STAT_SET_INT(-141827484, 33037, true);
				MenuFunctions::Notify("�ѽ���Ь��(����)/�ϻ�");
			}
		}
		break;
		case tc_dlc:
		{
			gui.Title("The Contract DLC");
			if (gui.Option("�����������", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_FIXER_LOGIN_AWARD_FISHMASK_1"), 31859, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_FIXER_LOGIN_AWARD_FISHMASK_4"), 31870, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_FIXER_LOGIN_AWARD_FISHMASK_1"), 31859, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_FIXER_LOGIN_AWARD_FISHMASK_4"), 31870, true);
				MenuFunctions::Notify("�ѽ����������");
			}
			if (gui.Option("����DJ Pooth T��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_FIXER_LOGIN_DJ_POOH_ORANGE"), 31871, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_FIXER_LOGIN_DJ_POOH_BLUE"), 31873, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_FIXER_LOGIN_DJ_POOH_ORANGE"), 31871, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_FIXER_LOGIN_DJ_POOH_BLUE"), 31873, true);
				MenuFunctions::Notify("�ѽ���DJ Pooth T��");
			}
		}
		break;
		case cyh_dlc:
		{
			gui.Title("���ѻ�DLC");
			if (gui.Option("��������", NULL))
			{
				UNL::Unlock_the_awards();
				MenuFunctions::Notify("�ѽ������ѻ�DLC���н���");
			}
		}
		break;
		case xt_dlc:
		{
			gui.Title("2020������DLC");
			if (gui.Option("2020���ļ�����", NULL))
			{
				UNL::Summer_2020_awards();
				MenuFunctions::Notify("�ѽ���2020���ļ�����");
			}
			if (gui.Option("������װ", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ENABLE_LOGIN_BCTR_AGED_TEE"), 29685, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ENABLE_LOGIN_LEMON_SPORTS_TRACK_TOP"), 29720, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_ENABLE_LOGIN_BCTR_AGED_TEE"), 29685, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_ENABLE_LOGIN_LEMON_SPORTS_TRACK_TOP"), 29720, true);
				MenuFunctions::Notify("�ѽ�����װ");
			}
		}
		break;
		case jjc_dlc:
		{
			gui.Title("������DLC");
			if (gui.Option("�������о�����ս����������", NULL))
			{
				UNL::Unlock_all_arena_war_awards_and_toys();
				MenuFunctions::Notify("�ѽ������о�����ս����������");
			}
			if (gui.Option("������װ", NULL))
			{
				STATS::STAT_SET_INT(-1782918513, 25842, true);
				STATS::STAT_SET_INT(-1597048932, 25909, true);
				MenuFunctions::Notify("�ѽ�����װ");
			}
		}
		break;
		case CEO:
		{
			gui.Title("�칫��ѡ��");
			if (gui.Option("�칫������Ǯ", "ʹ�ú����ս����һ������������"))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_LIFETIME_CONTRA_EARNINGS"), 20000000, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_LIFETIME_CONTRA_EARNINGS"), 20000000, true);
			}
			if (gui.Option("�����칫��С����", "ʹ�ú����ս����һ������������"))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_LIFETIME_CONTRA_EARNINGS"), 1000, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_LIFETIME_BUY_COMPLETE"), 1000, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_LIFETIME_SELL_UNDERTAKEN"), 1000, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_LIFETIME_SELL_COMPLETE"), 1000, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_LIFETIME_CONTRA_EARNINGS"), 1000, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_LIFETIME_BUY_COMPLETE"), 1000, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_LIFETIME_SELL_UNDERTAKEN"), 1000, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_LIFETIME_SELL_COMPLETE"), 1000, true);
			}
		}
		break;
		case dibao:
		{
			gui.Title("�ر�ѡ��");
			if (gui.Option("�������еر��о�", NULL))
			{
				script_global({ 262145 + 21857 }, 1);
			}
			if (gui.Option("�ر�����", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_PAYRESUPPLYTIMER5"), 1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_PAYRESUPPLYTIMER5"), 1, true);
				MenuFunctions::notify((char*)"��ɣ������ս�֣�");
			}
			if (gui.Option("���õر���Ӫ��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_LIFETIME_BKR_SELL_EARNINGS5"), 0, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_LIFETIME_BKR_SELL_EARNINGS5"), 0, true);
				MenuFunctions::notify((char*)"��ɣ������ս�֣�");
			}
		}
		break;
		case RP:
		{
			gui.Title("�ȼ�ѡ��");
			if (gui.Option("���ý�ɫ�ȼ�", "ֱ������ȼ����س�����"))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					if (int rp = MenuFunctions::NumberKeyboard())
					{
						if (rp > 0 && rp <= 8000)
						{
							STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_CHAR_SET_RP_GIFT_ADMIN"), Levels[rp - 1], true);
							STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_CHAR_SET_RP_GIFT_ADMIN"), Levels[rp - 1], true);
							MenuFunctions::notify((char*)"���óɹ�������ս����Ч��");

						}
						else {
							MenuFunctions::Notify((char*)"���õȼ�ʧ�ܣ�����������\n~b~�ȼ�(1-8000)");
						}

					}
					else {
						MenuFunctions::Notify((char*)"���õȼ�ʧ�ܣ�����������");
					}
					fhtime = GetTickCount64();
				}


			}
			if (gui.Option("�ȼ�����Ϊ1��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CHAR_SET_RP_GIFT_ADMIN"), 0, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CHAR_SET_RP_GIFT_ADMIN"), 0, true);
				MenuFunctions::notify("���!�����ս�֣��ɷ������·�����!");
			}
			if (gui.Option("�ȼ�����Ϊ30��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CHAR_SET_RP_GIFT_ADMIN"), 177100, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CHAR_SET_RP_GIFT_ADMIN"), 177100, true);
				MenuFunctions::notify("���!�����ս�֣��ɷ������·�����!");
			}
			if (gui.Option("�ȼ�����Ϊ90��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CHAR_SET_RP_GIFT_ADMIN"), 1308100, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CHAR_SET_RP_GIFT_ADMIN"), 1308100, true);
				MenuFunctions::notify("���!�����ս�֣��ɷ������·�����!");
			}
			if (gui.Option("�ȼ�����Ϊ120��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CHAR_SET_RP_GIFT_ADMIN"), 2165850, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CHAR_SET_RP_GIFT_ADMIN"), 2165850, true);
				MenuFunctions::notify("���!�����ս�֣��ɷ������·�����!");
			}
			if (gui.Option("�ȼ�����Ϊ200��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CHAR_SET_RP_GIFT_ADMIN"), 4691850, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CHAR_SET_RP_GIFT_ADMIN"), 4691850, true);
				MenuFunctions::notify("���!�����ս�֣��ɷ������·�����!");
			}
			if (gui.Option("�ȼ�����Ϊ300��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CHAR_SET_RP_GIFT_ADMIN"), 8299350, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CHAR_SET_RP_GIFT_ADMIN"), 8299350, true);
				MenuFunctions::notify("���!�����ս�֣��ɷ������·�����!");
			}
			if (gui.Option("�ȼ�����Ϊ500��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CHAR_SET_RP_GIFT_ADMIN"), 17014350, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CHAR_SET_RP_GIFT_ADMIN"), 17014350, true);
				MenuFunctions::notify("���!�����ս�֣��ɷ������·�����!");
			}
			if (gui.Option("�ȼ�����Ϊ1000��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CHAR_SET_RP_GIFT_ADMIN"), 47551850, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CHAR_SET_RP_GIFT_ADMIN"), 47551850, true);
				MenuFunctions::notify("���!�����ս�֣��ɷ������·�����!");
			}
			if (gui.Option("�ȼ�����Ϊ2000��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CHAR_SET_RP_GIFT_ADMIN"), 146126850, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CHAR_SET_RP_GIFT_ADMIN"), 146126850, true);
				MenuFunctions::notify("���!�����ս�֣��ɷ������·�����!");
			}
			if (gui.Option("�ȼ�����Ϊ8000��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_CHAR_SET_RP_GIFT_ADMIN"), 1787576850, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_CHAR_SET_RP_GIFT_ADMIN"), 1787576850, true);
				MenuFunctions::notify("���!�����ս�֣��ɷ������·�����!");
			}
		}
		break;
		case arenaWareditor:
		{
			gui.Title("����������");
			if (gui.Option("����25�����⳵", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ARENAWARS_AP_TIER"), 24, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ARENAWARS_AP"), 280, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_ARENAWARS_AP_TIER"), 24, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_ARENAWARS_AP"), 280, true);
			}
			if (gui.Option("����50��������", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ARENAWARS_AP_TIER"), 49, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ARENAWARS_AP"), 530, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_ARENAWARS_AP_TIER"), 49, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_ARENAWARS_AP"), 530, true);
			}
			if (gui.Option("����75��С�󻨳�", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ARENAWARS_AP_TIER"), 74, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ARENAWARS_AP"), 780, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_ARENAWARS_AP_TIER"), 74, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_ARENAWARS_AP"), 780, true);
			}
			if (gui.Option("����100����������", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ARENAWARS_AP_TIER"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ARENAWARS_AP"), 1030, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_ARENAWARS_AP_TIER"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_ARENAWARS_AP"), 1030, true);
			}
			if (gui.Option("����200���ذ����ϳ�", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ARENAWARS_AP_TIER"), 199, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ARENAWARS_AP"), 2030, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_ARENAWARS_AP_TIER"), 199, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_ARENAWARS_AP"), 2030, true);
			}
			if (gui.Option("����300�����������賵", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ARENAWARS_AP_TIER"), 299, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ARENAWARS_AP"), 3030, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_ARENAWARS_AP_TIER"), 299, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_ARENAWARS_AP"), 3030, true);
			}
			if (gui.Option("����500���Ǽ���ͷ", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ARENAWARS_AP_TIER"), 499, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ARENAWARS_AP"), 5030, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_ARENAWARS_AP_TIER"), 499, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_ARENAWARS_AP"), 5030, true);
			}
			if (gui.Option("����1000����ʽ��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ARENAWARS_AP_TIER"), 999, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ARENAWARS_AP"), 10030, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_ARENAWARS_AP_TIER"), 999, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_ARENAWARS_AP"), 10030, true);
			}
			if (gui.Option("�����������мҹ���Ȩ��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ARENAWARS_SKILL_LEVEL"), 19, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ARENAWARS_SP"), 209, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_ARENAWARS_SKILL_LEVEL"), 19, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_ARENAWARS_SP"), 209, true);
			}
		}
		break;
		case assetmanager:
		{
			gui.Title("�Զ����ʲ�");
			if (gui.Option("α������", "ʹ�ú����ս��"))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_PAYRESUPPLYTIMER2"), 1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_PAYRESUPPLYTIMER2"), 1, true);
			}
			if (gui.Option("��֤����", "ʹ�ú����ս��"))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_PAYRESUPPLYTIMER0"), 1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_PAYRESUPPLYTIMER0"), 1, true);
			}
			if (gui.Option("��������", "ʹ�ú����ս��"))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_PAYRESUPPLYTIMER3"), 1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_PAYRESUPPLYTIMER3"), 1, true);
			}
			if (gui.Option("���鲹��", "ʹ�ú����ս��"))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_PAYRESUPPLYTIMER1"), 1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_PAYRESUPPLYTIMER1"), 1, true);
			}
			if (gui.Option("�ɿ��򲹻�", "ʹ�ú����ս��"))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_PAYRESUPPLYTIMER4"), 1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_PAYRESUPPLYTIMER4"), 1, true);
			}
			if (gui.Option("ҹ�ܻᲹ������", "ʹ�ú����ս��"))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_CLUB_POPULARITY"), 1000, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_CLUB_POPULARITY"), 1000, true);
			}
		}
		break;
		case jinqian:
		{
			gui.Title("ˢ����");
			//gui.Bool("������˿�", "������ʹ����ʩ�ڵ�����ڼ����Զ��˿�", g_Recovery.tianjipaotuikuan);
			gui.Bool("50Wѭ��ˢ", NULL, g_Recovery.xunhuanshua);
			gui.Bool("75Wѭ��ˢ", NULL, g_Recovery.qiwuxunhuanshua);
			if (gui.Option("1500W����Ǯ", "ÿ��Сʱ��ʹ��һ��"))
			{
				//ˢǮ��ʼ
				globalHandle(4536533).At(1).As<int>() = 2147483646;
				globalHandle(4536533).At(2).As<int>() = 15000000;
				globalHandle(4536533).At(3).As<int>() = 2708796979;
				globalHandle(4536533).At(6).As<int>() = 0;
				globalHandle(4536533).At(7).As<int>() = 2147483647;
				globalHandle(4536533).At(4).As<int>() = NETWORK::GET_NETWORK_TIME();
				globalHandle(4536533).As<int>() = 1;
				WAIT(500);
				//ˢǮ����
				globalHandle(4536533).As<int>() = 0;
				globalHandle(4536533).At(1).As<int>() = 2147483647;
				globalHandle(4536533).At(2).As<int>() = 0;
				globalHandle(4536533).At(3).As<int>() = 0;
				globalHandle(4536533).At(4).As<int>() = 0;
				globalHandle(4536533).As<int>() = 0;
			}
			if (gui.Option("�ϻ���ͷ��", "��һ�μ��ɣ�̫����ͷ��250w"))
			{
				for (int i = 0; i < 3; i++)
				{
					for (int j = 0; j < 64; j++)
					{
						script_local::script_local(script_local::GetLocalScript("CASINO_SLOTS"), 1341 + 1 + 1 + (i - 1) * 65 + 1 + j - 1, 6);
					}
				}
			}
			if (gui.Option("���޹���ĳ�����", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MPPLY_CASINO_CHIPS_PUR_GD"), 0, true);
				MenuFunctions::Notify("ִ�гɹ��������ڿ������޹�����룡");
			}
			gui.Bool("����ϻ�������", NULL, g_Recovery.jiechulaohuji);
			if (gui.Option("����ĳ���������ȴ", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MPPLY_VEHICLE_SELL_TIME"), 0, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MPPLY_NUM_CARS_SOLD_TODAY"), 0, true);
				MenuFunctions::Notify("�������ˢǮ��ȴ�ɹ���");
			}
		}
		break;
		case attributes:
		{
			gui.Title("��ɫ����");
			if (gui.Option("����ȥ����", "�ɸ����Ա�"))
			{
				STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY((char*)"MP0_FM_CHANGECHAR_ASKED"), 0, 1);
				STATS::STAT_SET_BOOL(MISC::GET_HASH_KEY((char*)"MP1_FM_CHANGECHAR_ASKED"), 0, 1);
				MenuFunctions::Notify("M-���-������ò����");
			}
			if (gui.Option("����ȫ��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_SCRIPT_INCREASE_STAM"), 100, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_SCRIPT_INCREASE_SHO"), 100, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_SCRIPT_INCREASE_STRN"), 100, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_SCRIPT_INCREASE_STL"), 100, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_SCRIPT_INCREASE_FLY"), 100, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_SCRIPT_INCREASE_DRIV"), 100, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_SCRIPT_INCREASE_LUNG"), 100, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_SCRIPT_INCREASE_STAM"), 100, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_SCRIPT_INCREASE_SHO"), 100, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_SCRIPT_INCREASE_STRN"), 100, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_SCRIPT_INCREASE_STL"), 100, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_SCRIPT_INCREASE_FLY"), 100, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_SCRIPT_INCREASE_DRIV"), 100, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_SCRIPT_INCREASE_LUNG"), 100, true);
			}
			if (gui.Option("������������", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_CHAR_ABILITY_1_UNLCK"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_CHAR_ABILITY_2_UNLCK"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_CHAR_ABILITY_3_UNLCK"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_CHAR_FM_ABILITY_1_UNLCK"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_CHAR_FM_ABILITY_2_UNLCK"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_CHAR_FM_ABILITY_3_UNLCK"), -1, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_CHAR_ABILITY_1_UNLCK"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_CHAR_ABILITY_2_UNLCK"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_CHAR_ABILITY_3_UNLCK"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_CHAR_FM_ABILITY_1_UNLCK"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_CHAR_FM_ABILITY_2_UNLCK"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_CHAR_FM_ABILITY_3_UNLCK"), -1, true);
			}
			if (gui.Option("��������", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_MP_CHAR_ARMOUR_1_COUNT"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_MP_CHAR_ARMOUR_1_COUNT"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_MP_CHAR_ARMOUR_2_COUNT"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_MP_CHAR_ARMOUR_2_COUNT"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_MP_CHAR_ARMOUR_3_COUNT"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_MP_CHAR_ARMOUR_3_COUNT"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_MP_CHAR_ARMOUR_4_COUNT"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_MP_CHAR_ARMOUR_4_COUNT"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_MP_CHAR_ARMOUR_5_COUNT"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_MP_CHAR_ARMOUR_5_COUNT"), 99, true);
			}
			if (gui.Option("������ʳ", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_NO_BOUGHT_YUM_SNACKS"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_NO_BOUGHT_HEALTH_SNACKS"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_NO_BOUGHT_EPIC_SNACKS"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_NUMBER_OF_ORANGE_BOUGHT"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_NUMBER_OF_BOURGE_BOUGHT"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_CIGARETTES_BOUGHT"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_NUMBER_OF_CHAMP_BOUGHT"), 99, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_NO_BOUGHT_YUM_SNACKS"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_NO_BOUGHT_HEALTH_SNACKS"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_NO_BOUGHT_EPIC_SNACKS"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_NUMBER_OF_ORANGE_BOUGHT"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_NUMBER_OF_BOURGE_BOUGHT"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_CIGARETTES_BOUGHT"), 99, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_NUMBER_OF_CHAMP_BOUGHT"), 99, true);
			}
		}
		break;
		case task:
		{
			gui.Title("������");
			gui.SubMenu("�ĳ�����", NULL, Casino_front);
			gui.SubMenu("����Ƶ�", NULL, Perico_Island_Front);
			gui.SubMenu("ĩ�պ���", NULL, The_prefix_of_the_apocalyptic_catastrophe);
			gui.SubMenu("��Ԣ����", NULL, Apartment_front);
			gui.SubMenu("�ĳ��̺�Լ", NULL, gaichepu);
			gui.SubMenu("��������ͬ", NULL, shiwusuo);
			gui.SubMenu("ULP����", NULL, ulprenwu);
			//gui.SubMenu("�����������", NULL, jukurenwu);
		}
		break;
		case jukurenwu:
		{
			gui.Title("�����������");
			if (gui.Option("����͵ȡ������ȴ", NULL))
			{
				script_local::script_local(script_local::GetLocalScript("gb_smuggler"), 1928 + 769, 0);
			}
			if (gui.Option("������ɹ������", NULL))
			{
				script_local::script_local(script_local::GetLocalScript("gb_smuggler"), 1928 + 1035, 1);
				script_local::script_local(script_local::GetLocalScript("gb_smuggler"), 1928 + 770, 15);
				script_local::script_local(script_local::GetLocalScript("gb_smuggler"), 1928 + 6 + 63 + 2, 175352);
			}
			if (gui.Option("������ɹ����������", NULL))
			{
				script_local::script_local(script_local::GetLocalScript("gb_smuggler"), 598 + 1, 111);
				script_local::script_local(script_local::GetLocalScript("gb_smuggler"), 598 + 192, 6);
				script_local::script_local(script_local::GetLocalScript("gb_smuggler"), 598 + 193, 4);
			}
			if (gui.Option("������ɳ��ۻ���", NULL))
			{
				script_local::script_local(script_local::GetLocalScript("gb_smuggler"), 928 + 6 + 63 + 2, 175352);
			}
		}
		break;
		case ulprenwu:
		{
			gui.Title("ULP����");
			if (gui.Option("�����鱨", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"ULP_MISSION_CURRENT"), 0, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"ULP_MISSION_PROGRESS"), 127, true);
			}
			if (gui.Option("���淴�鱨", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"ULP_MISSION_CURRENT"), 1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"ULP_MISSION_PROGRESS"), 127, true);
			}
			if (gui.Option("���泷��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"ULP_MISSION_CURRENT"), 2, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"ULP_MISSION_PROGRESS"), 127, true);
			}
			if (gui.Option("�����ʲ���Ѻ", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"ULP_MISSION_CURRENT"), 3, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"ULP_MISSION_PROGRESS"), 127, true);
			}
			if (gui.Option("�����ټ��ж�", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"ULP_MISSION_CURRENT"), 4, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"ULP_MISSION_PROGRESS"), 127, true);
			}
			if (gui.Option("�����峡", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"ULP_MISSION_CURRENT"), 5, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"ULP_MISSION_PROGRESS"), 127, true);
			}
			if (gui.Option("���͵�ULP����ʼ��", NULL))
			{
				Vector3 Coords;
				Coords.x = 101.59523010254; Coords.y = -662.92388916016; Coords.z = 45.09302520752;
				MenuFunctions::ChangeCoords(Coords);
			}
		}
		break;
		case shiwusuo:
		{
			gui.Title("��������ͬ");
			gui.SubMenu("ҹ����й©", NULL, yeshenghuo);
			gui.SubMenu("�������", NULL, shangliushehui);
			gui.SubMenu("����������", NULL, dailigongzuoshi);
			if (gui.Option("�������񣺱��ǵ���", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_GENERAL_BS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_COMPLETED_BS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_STORY_BS"), 4092, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_STORY_COOLDOWN"), -1, true);
			}
			gui.Bool("�������ձ���200��", NULL, g_Task.swsshouru);
			gui.Bool("�Ƴ���Լ&��ɱ����ȴ", NULL, g_Task.swscisha);
			gui.Bool("�Ƴ������������ȴ", NULL, g_Task.swsanbao);

			if (gui.Option("���ø������ֵ绰��ȴΪ0", NULL))
			{
				script_global({ 262145 + 31345 }, 0);
				script_global({ 262145 + 31345 }, 0);
				script_global({ 2720311 }, 0);
				MenuFunctions::notify((char*)"�ɹ�����������ֵ绰��ȴ��");
			}
		}
		break;
		case dailigongzuoshi:
		{
			gui.Title("�������");
			if (gui.Option("������ά˹��׼����", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_GENERAL_BS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_COMPLETED_BS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_STORY_BS"), 252, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_STORY_COOLDOWN"), -1, true);
			}
			if (gui.Option("��������˹��׼����", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_GENERAL_BS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_COMPLETED_BS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_STORY_BS"), 580, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_STORY_COOLDOWN"), -1, true);
			}
			if (gui.Option("�������������ң�����", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_GENERAL_BS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_COMPLETED_BS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_STORY_BS"), 2044, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_STORY_COOLDOWN"), -1, true);
			}
		}
		break;
		case shangliushehui:
		{
			gui.Title("�������");
			if (gui.Option("����ҹ�����ֲ���׼����", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_GENERAL_BS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_COMPLETED_BS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_STORY_BS"), 28, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_STORY_COOLDOWN"), -1, true);
			}
			if (gui.Option("��������������׼����", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_GENERAL_BS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_COMPLETED_BS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_STORY_BS"), 60, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_STORY_COOLDOWN"), -1, true);
			}
			if (gui.Option("����������ᣨ����", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_GENERAL_BS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_COMPLETED_BS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_STORY_BS"), 124, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_STORY_COOLDOWN"), -1, true);
			}
		}
		break;
		case yeshenghuo:
		{
			gui.Title("ҹ����й©");
			if (gui.Option("����ҹ�ܻᣨ׼����", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_GENERAL_BS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_COMPLETED_BS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_STORY_BS"), 3, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_STORY_COOLDOWN"), -1, true);
			}
			if (gui.Option("����ҹ��ͷ��׼����", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_GENERAL_BS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_COMPLETED_BS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_STORY_BS"), 4, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_STORY_COOLDOWN"), -1, true);
			}
			if (gui.Option("����ҹ����й©������", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_GENERAL_BS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_COMPLETED_BS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_STORY_BS"), 12, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"FIXER_STORY_COOLDOWN"), -1, true);
			}
		}
		break;
		case gaichepu:
		{
			gui.Title("�ĳ��̺�Լ");
			gui.stringvector("ѡ��ǰ������", NULL, gaichepuqianzhi, gaichepuqianzhi1);
			if (gui.Option("����ǰ��", "�������˳��ĳ����ؽ�"))
			{
				if (gaichepuqianzhi1 == 0)
				{
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_GEN_BS"), 12543, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_CURRENT"), 0, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_GEN_BS"), -1, true);

					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_GEN_BS"), 12543, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_CURRENT"), 0, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_GEN_BS"), -1, true);
					MenuFunctions::Notify((char*)"�������ϴ���ǰ�óɹ������˳��ĳ������½��룡");
				}
				if (gaichepuqianzhi1 == 1)
				{
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_GEN_BS"), 4351, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_CURRENT"), 1, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_GEN_BS"), -1, true);

					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_GEN_BS"), 4351, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_CURRENT"), 1, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_GEN_BS"), -1, true);
					MenuFunctions::Notify((char*)"�����󳮽���ǰ�óɹ������˳��ĳ������½��룡");
				}
				if (gaichepuqianzhi1 == 2)
				{
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_GEN_BS"), 12543, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_CURRENT"), 2, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_GEN_BS"), -1, true);

					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_GEN_BS"), 12543, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_CURRENT"), 2, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_GEN_BS"), -1, true);
					MenuFunctions::Notify((char*)"�������к�Լǰ�óɹ������˳��ĳ������½��룡");
				}
				if (gaichepuqianzhi1 == 3)
				{
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_GEN_BS"), 12543, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_CURRENT"), 3, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_GEN_BS"), -1, true);

					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_GEN_BS"), 12543, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_CURRENT"), 3, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_GEN_BS"), -1, true);
					MenuFunctions::Notify((char*)"������ص�Ԫǰ�óɹ������˳��ĳ������½��룡");
				}
				if (gaichepuqianzhi1 == 4)
				{
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_GEN_BS"), 12543, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_CURRENT"), 4, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_GEN_BS"), -1, true);

					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_GEN_BS"), 12543, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_CURRENT"), 4, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_GEN_BS"), -1, true);
					MenuFunctions::Notify((char*)"����������Լǰ�óɹ������˳��ĳ������½��룡");
				}
				if (gaichepuqianzhi1 == 5)
				{
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_GEN_BS"), 12543, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_CURRENT"), 5, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_GEN_BS"), -1, true);

					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_GEN_BS"), 12543, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_CURRENT"), 5, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_GEN_BS"), -1, true);
					MenuFunctions::Notify((char*)"����IAA����ǰ�óɹ������˳��ĳ������½��룡");
				}
				if (gaichepuqianzhi1 == 6)
				{
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_GEN_BS"), 12543, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_CURRENT"), 7, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_GEN_BS"), -1, true);

					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_GEN_BS"), 12543, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_CURRENT"), 7, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_GEN_BS"), -1, true);
					MenuFunctions::Notify((char*)"�������ݺ�Լǰ�óɹ������˳��ĳ������½��룡");
				}
				if (gaichepuqianzhi1 == 7)
				{
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_GEN_BS"), 12543, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_CURRENT"), 6, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TUNER_GEN_BS"), -1, true);

					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_GEN_BS"), 12543, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_CURRENT"), 6, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TUNER_GEN_BS"), -1, true);
					MenuFunctions::Notify((char*)"����Ħ�аｻ��ǰ�óɹ������˳��ĳ������½��룡");
				}
			}
			gui.Bool("���øĳ�����������100w", "������ǰ��", g_Task.gaichepushouru);
			if (gui.Option(StringToChar((std::string)"�Զ����" + gaichepuqianzhi[gaichepuqianzhi1]), NULL))
			{
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller_2020"), 46829, 383);
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller_2020"), 54115, 99999);
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller_2020"), 46829, 383);
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller_2020"), 45450, 9);
			}
		}
		break;
		case Apartment_front:
		{
			gui.Title("��Ԣ����");
			//gui.SubMenu("ȫ����������", NULL, quanfu);
			//gui.SubMenu("̫ƽ���׼����", NULL, taipingyang);
			if (gui.Option("����ǰ��", "���ڹ���������ʹ��"))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_HEIST_PLANNING_STAGE"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_HEIST_PLANNING_STAGE"), -1, true);
			}
			if (gui.Option("ȫԱ100�ֺ�", NULL))
			{
				script_global({ 1938365 + 3008 + 1 }, 100);
				script_global({ 1938365 + 3008 + 2 }, 100);
				script_global({ 1938365 + 3008 + 3 }, 100);
				script_global({ 1938365 + 3008 + 4 }, 100);
			}
			if (gui.Option("�Զ���ɹ�Ԣ����", NULL))
			{
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 31656, 99999);
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 28332, 99999);
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 31656, 99999);
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 19710, 12);
			}
			//gui.Bool("�ƹ��ֺ�ٷֱ�����", "ʹ���ķֺ������Ϊ0��100", g_Task.fenhongbaifenbi);
			gui.SubMenu("������ҷֺ�", NULL, gongyufenhong);
			if (gui.Option("ȡ����Ԣ��������", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_CAS_HEIST_NOTS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_CAS_HEIST_FLOW"), -1, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_CAS_HEIST_NOTS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_CAS_HEIST_FLOW"), -1, true);
			}
			//if (gui.Option("�����ȫ����·����", NULL))
			//{
			//	script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 11755, 7);
			//}
			//if (gui.Option("�����̫ƽ���ƽ�", NULL))
			//{
			//	script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 146, 7);
			//}
		}
		break;
		case gongyufenhong:
		{
			gui.Title("������ҷֺ�");
			if (gui.Option("����������ҷֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					int fh = MenuFunctions::NumberKeyboard();
					script_global({ 1938365 + 3008 + 1 }, fh);
					script_global({ 1938365 + 3008 + 2 }, fh);
					script_global({ 1938365 + 3008 + 3 }, fh);
					script_global({ 1938365 + 3008 + 4 }, fh);
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("�������1�ֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					script_global({ 1938365 + 3008 + 1 }, MenuFunctions::NumberKeyboard());
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("�������2�ֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					script_global({ 1938365 + 3008 + 2 }, MenuFunctions::NumberKeyboard());
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("�������3�ֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					script_global({ 1938365 + 3008 + 3 }, MenuFunctions::NumberKeyboard());
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("�������4�ֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					script_global({ 1938365 + 3008 + 4 }, MenuFunctions::NumberKeyboard());
					fhtime = GetTickCount64();
				}
			}

		}
		break;
		case taipingyang:
		{
			gui.Title("̫ƽ���׼����");
			gui.Bool("�������½��ֽ�Ϊ185��", "�����������½�����Ϊ185��", g_Task.tpyshouru);
			gui.Bool("����ָ����", NULL, g_Task.tpyzhiwensuo);
		}
		break;
		case quanfu:
		{
			gui.Title("ȫ����������");
			gui.Bool("������ķֺ�Ϊ1500��", "�ù��ܽ�������Ч�ұ���Ϊ����", g_Task.quanfushouru);
			gui.Bool("����ָ����", NULL, g_Task.quanfuzhiwensuo);
			gui.Bool("�������", NULL, g_Task.quanfuzuankong);
		}
		break;
		case The_prefix_of_the_apocalyptic_catastrophe:
		{
			gui.Title("ĩ�պ���");
			gui.SubMenu("������������", NULL, morishoudong);
			gui.SubMenu("�����ȴ", NULL, qingchulengque);
			gui.SubMenu("������ҷֺ�", NULL, morifenhong);
		}
		break;
		case morifenhong:
		{
			gui.Title("������ҷֺ�");
			if (gui.Option("����������ҷֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					int fh = MenuFunctions::NumberKeyboard();
					script_global({ 1967630 + 812 + 50 + 1 }, fh);
					script_global({ 1967630 + 812 + 50 + 2 }, fh);
					script_global({ 1967630 + 812 + 50 + 3 }, fh);
					script_global({ 1967630 + 812 + 50 + 4 }, fh);
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("�������1�ֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					script_global({ 1967630 + 812 + 50 + 1 }, MenuFunctions::NumberKeyboard());
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("�������2�ֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					script_global({ 1967630 + 812 + 50 + 2 }, MenuFunctions::NumberKeyboard());
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("�������3�ֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					script_global({ 1967630 + 812 + 50 + 3 }, MenuFunctions::NumberKeyboard());
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("�������4�ֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					script_global({ 1967630 + 812 + 50 + 4 }, MenuFunctions::NumberKeyboard());
					fhtime = GetTickCount64();
				}
			}
		}
		break;
		case qingchulengque:
		{
			gui.Title("�����ȴ");
			if (gui.Option("��������й¶��ȴʱ��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_HEISTCOOLDOWNTIMER0"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_HEISTCOOLDOWNTIMER0"), -1, true);
			}
			if (gui.Option("���ò���Σ����ȴʱ��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_HEISTCOOLDOWNTIMER1"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_HEISTCOOLDOWNTIMER1"), -1, true);
			}
			if (gui.Option("���ò�ĩ�ս�����ȴʱ��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_HEISTCOOLDOWNTIMER2"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_HEISTCOOLDOWNTIMER2"), -1, true);
			}
		}
		break;
		case morishoudong:
		{
			gui.Title("������������");
			if (gui.Option("��������й¶����", "ʹ�ú����¿����߻�����"))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_GANGOPS_FLOW_MISSION_PROG"), 503, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_GANGOPS_HEIST_STATUS"), 229383, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_GANGOPS_FLOW_NOTIFICATIONS"), 1557, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_GANGOPS_FLOW_MISSION_PROG"), 503, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_GANGOPS_HEIST_STATUS"), 229383, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_GANGOPS_FLOW_NOTIFICATIONS"), 1557, true);
				MenuFunctions::Notify((char*)"��������й¶ǰ����ɣ����¿����߻���������Ч��");
			}
			if (gui.Option("��������Σ������", "ʹ�ú����¿����߻�����"))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_GANGOPS_FLOW_MISSION_PROG"), 204, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_GANGOPS_HEIST_STATUS"), 229378, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_GANGOPS_FLOW_NOTIFICATIONS"), 1557, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_GANGOPS_FLOW_MISSION_PROG"), 204, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_GANGOPS_HEIST_STATUS"), 229378, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_GANGOPS_FLOW_NOTIFICATIONS"), 1557, true);
				MenuFunctions::Notify((char*)"��������Σ��ǰ����ɣ����¿����߻���������Ч��");
			}
			if (gui.Option("����ĩ�ս�������", "ʹ�ú����¿����߻�����"))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_GANGOPS_FLOW_MISSION_PROG"), 16368, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_GANGOPS_HEIST_STATUS"), 229380, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_GANGOPS_FLOW_NOTIFICATIONS"), 1557, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_GANGOPS_FLOW_MISSION_PROG"), 16368, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_GANGOPS_HEIST_STATUS"), 229380, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_GANGOPS_FLOW_NOTIFICATIONS"), 1557, true);
				MenuFunctions::Notify((char*)"����ĩ�ս���ǰ����ɣ����¿����߻���������Ч��");
			}
			if (gui.Option("����/����ȫ��ĩ�պ���", "ʹ�ú�ս��,��绰����˹��ȡ��ĩ������3�Σ�"))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_GANGOPS_HEIST_STATUS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_GANGOPS_FLOW_NOTIFICATIONS"), -1, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_GANGOPS_HEIST_STATUS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_GANGOPS_FLOW_NOTIFICATIONS"), -1, true);
				MenuFunctions::Notify((char*)"��ս��,��绰����˹��ȡ��ĩ������3�Σ�");
			}
		}
		break;
		case morizidong:
		{
			gui.SubMenu("ĩ�պ���1", NULL, mori1);
			gui.SubMenu("ĩ�պ���2", NULL, mori2);
			gui.SubMenu("ĩ�պ���3", NULL, mori3);
		}
		break;
		case mori1:
		{
			gui.Title("ĩ�պ���1");
			if (gui.Option("��������й¶����", "ʹ�ú����¿����߻�����"))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_GANGOPS_FLOW_MISSION_PROG"), 503, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_GANGOPS_HEIST_STATUS"), 229383, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_GANGOPS_FLOW_NOTIFICATIONS"), 1557, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_GANGOPS_FLOW_MISSION_PROG"), 503, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_GANGOPS_HEIST_STATUS"), 229383, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_GANGOPS_FLOW_NOTIFICATIONS"), 1557, true);
				MenuFunctions::Notify((char*)"��������й¶ǰ����ɣ����¿����߻���������Ч��");
			}
			if (gui.Option("ȫԱ196�ֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					script_global({ 1967630 + 812 + 50 + 1 }, 196);
					script_global({ 1967630 + 812 + 50 + 2 }, 196);
					script_global({ 1967630 + 812 + 50 + 3 }, 196);
					script_global({ 1967630 + 812 + 50 + 4 }, 196);
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("�Զ��������й¶", NULL))
			{
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 31656, 99999);
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 28332, 99999);
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 31656, 99999);
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 19710, 12);
			}
			if (gui.Option("��������й¶��ȴʱ��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_HEISTCOOLDOWNTIMER0"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_HEISTCOOLDOWNTIMER0"), -1, true);
			}
		}
		break;
		case mori2:
		{
			gui.Title("ĩ�պ���2");
			if (gui.Option("��������Σ������", "ʹ�ú����¿����߻�����"))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_GANGOPS_FLOW_MISSION_PROG"), 204, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_GANGOPS_HEIST_STATUS"), 229378, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_GANGOPS_FLOW_NOTIFICATIONS"), 1557, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_GANGOPS_FLOW_MISSION_PROG"), 204, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_GANGOPS_HEIST_STATUS"), 229378, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_GANGOPS_FLOW_NOTIFICATIONS"), 1557, true);
				MenuFunctions::Notify((char*)"��������Σ��ǰ����ɣ����¿����߻���������Ч��");
			}
			if (gui.Option("ȫԱ134�ֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					script_global({ 1967630 + 812 + 50 + 1 }, 134);
					script_global({ 1967630 + 812 + 50 + 2 }, 134);
					script_global({ 1967630 + 812 + 50 + 3 }, 134);
					script_global({ 1967630 + 812 + 50 + 4 }, 134);
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("�Զ���ɲ���Σ��", NULL))
			{
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 31656, 99999);
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 28332, 99999);
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 31656, 99999);
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 19710, 12);
			}

			if (gui.Option("���ò���Σ����ȴʱ��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_HEISTCOOLDOWNTIMER1"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_HEISTCOOLDOWNTIMER1"), -1, true);
			}
		}
		break;
		case mori3:
		{
			gui.Title("ĩ�պ���3");
			if (gui.Option("����ĩ�ս�������", "ʹ�ú����¿����߻�����"))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_GANGOPS_FLOW_MISSION_PROG"), 16368, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_GANGOPS_HEIST_STATUS"), 229380, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_GANGOPS_FLOW_NOTIFICATIONS"), 1557, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_GANGOPS_FLOW_MISSION_PROG"), 16368, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_GANGOPS_HEIST_STATUS"), 229380, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_GANGOPS_FLOW_NOTIFICATIONS"), 1557, true);
				MenuFunctions::Notify((char*)"����ĩ�ս���ǰ����ɣ����¿����߻���������Ч��");
			}
			if (gui.Option("ȫԱ106�ֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					script_global({ 1967630 + 812 + 50 + 1 }, 106);
					script_global({ 1967630 + 812 + 50 + 2 }, 106);
					script_global({ 1967630 + 812 + 50 + 3 }, 106);
					script_global({ 1967630 + 812 + 50 + 4 }, 106);
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("�Զ����ĩ�ս���", NULL))
			{
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 31656, 99999);
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 28332, 99999);
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 31656, 99999);
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 19710, 12);
			}
			if (gui.Option("���ò�ĩ�ս�����ȴʱ��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_HEISTCOOLDOWNTIMER2"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_HEISTCOOLDOWNTIMER2"), -1, true);
			}
		}
		break;
		case Perico_Island_Front:
		{
			gui.Title("����Ƶ�");
			gui.SubMenu("��������", NULL, daoyuzhineng);
			gui.SubMenu("�ֶ��߻�����", NULL, daoyushoudong);
			gui.SubMenu("������ҷֺ�", NULL, daoyufenhong);
			if (gui.Option("һ�����͵��������", NULL))
			{
				Vector3 Coords;
				Coords.x = 1561.2369; Coords.y = 385.8771; Coords.z = -49.689915;
				MenuFunctions::ChangeCoords(Coords);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("H4_PROGRESS"), 131055, true);
			}
			if (gui.Option("���ñ�������", "����99999������"))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					script_global({ 262145 + 29939 }, MenuFunctions::NumberKeyboard());
					MenuFunctions::Notify((char*)"���ñ���������ɣ�");
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("������ҪĿ��۸�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					int a = MenuFunctions::NumberKeyboard();
					script_global({ 262145 + 30189 }, a);
					script_global({ 262145 + 30190 }, a);
					script_global({ 262145 + 30191 }, a);
					script_global({ 262145 + 30192 }, a);
					script_global({ 262145 + 30193 }, a);
					script_global({ 262145 + 30194 }, a);
					fhtime = GetTickCount64();
				}
			}
			//if (gui.Option("ɾ���������ú���ά���ֺ�", NULL))
			//{
			//	script_global({ 262145 + 29991 }, 0);
			//	script_global({ 262145 + 29992 }, 0);
			//}
		}
		break;
		case daoyufenhong:
		{
			gui.Title("������ҷֺ�");
			if (gui.Option("���������ֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					int fh = MenuFunctions::NumberKeyboard();
					script_global({ 1978495 + 825 + 56 + 1 }, fh);
					script_global({ 1978495 + 825 + 56 + 2 }, fh);
					script_global({ 1978495 + 825 + 56 + 3 }, fh);
					script_global({ 1978495 + 825 + 56 + 4 }, fh);
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("����������ҷֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					int fh = MenuFunctions::NumberKeyboard();
					script_global({ 1978495 + 825 + 56 + 1 }, fh);
					script_global({ 1978495 + 825 + 56 + 2 }, fh);
					script_global({ 1978495 + 825 + 56 + 3 }, fh);
					script_global({ 1978495 + 825 + 56 + 4 }, fh);
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("�������1�ֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					int fh = MenuFunctions::NumberKeyboard();
					script_global({ 1978495 + 825 + 56 + 1 }, fh);
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("�������2�ֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					int fh = MenuFunctions::NumberKeyboard();
					script_global({ 1978495 + 825 + 56 + 2 }, fh);
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("�������3�ֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					int fh = MenuFunctions::NumberKeyboard();
					script_global({ 1978495 + 825 + 56 + 3 }, fh);
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("�������4�ֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					int fh = MenuFunctions::NumberKeyboard();
					script_global({ 1978495 + 825 + 56 + 4 }, fh);
					fhtime = GetTickCount64();
				}
			}
		}
		break;
		case daoyushoudong:
		{
			gui.Title("�ֶ��߻�����");
			if (gui.Option("�������е�λ", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4CNF_APPROACH"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4CNF_APPROACH"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4CNF_BS_ENTR"), 63, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4CNF_BS_ENTR"), 63, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4CNF_BS_GEN"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4CNF_BS_GEN"), -1, true);
				MenuFunctions::Notify((char*)"�ѽ�������Ƶ����е�λ");
			}
			if (gui.Option("�����Ŷ�֧��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4CNF_BS_ABIL"), 63, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4CNF_BS_ABIL"), 63, true);
				MenuFunctions::Notify((char*)"�ѽ�������Ƶ������Ŷ�֧��");
			}
			if (gui.stringvector("ѡ����ҪĿ��", NULL, zhuyaomubiao, zhuyaomubiao1))
			{
				if (GetAsyncKeyState(gui.selectKey))
				{
					if (zhuyaomubiao1 == 0)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4CNF_TARGET"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4CNF_TARGET"), 0, true);
						MenuFunctions::Notify("��������ҪĿ��Ϊ��~b~��������������");
					}
					if (zhuyaomubiao1 == 1)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4CNF_TARGET"), 1, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4CNF_TARGET"), 1, true);
						MenuFunctions::Notify("��������ҪĿ��Ϊ��~b~��ʯ����");
					}
					if (zhuyaomubiao1 == 2)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4CNF_TARGET"), 2, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4CNF_TARGET"), 2, true);
						MenuFunctions::Notify("��������ҪĿ��Ϊ��~b~��֪����ծȯ");
					}
					if (zhuyaomubiao1 == 3)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4CNF_TARGET"), 3, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4CNF_TARGET"), 3, true);
						MenuFunctions::Notify("��������ҪĿ��Ϊ��~b~����");
					}
					if (zhuyaomubiao1 == 4)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4CNF_TARGET"), 4, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4CNF_TARGET"), 4, true);
						MenuFunctions::Notify("��������ҪĿ��Ϊ��~b~��������ļ�");
					}
					if (zhuyaomubiao1 == 5)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4CNF_TARGET"), 5, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4CNF_TARGET"), 5, true);
						MenuFunctions::Notify("��������ҪĿ��Ϊ��~b~�Ա�����");
					}
				}
			}
			gui.SubMenu("ѡ���ҪĿ��", NULL, ciyaomubiao);
			if (gui.stringvector("ѡ����������", NULL, ruqinwuqi, ruqinwuqi1))
			{
				if (GetAsyncKeyState(gui.selectKey))
				{
					if (ruqinwuqi1 == 0)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4CNF_WEAPONS"), 1, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4CNF_WEAPONS"), 1, true);
						MenuFunctions::Notify("����������Ϊ��~b~��������ǹ+������ǹ+����+����");
					}
					if (ruqinwuqi1 == 1)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4CNF_WEAPONS"), 2, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4CNF_WEAPONS"), 2, true);
						MenuFunctions::Notify("����������Ϊ��~b~���ò�ǹ+������ǹ+ճ��+ָ��");
					}
					if (ruqinwuqi1 == 2)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4CNF_WEAPONS"), 3, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4CNF_WEAPONS"), 3, true);
						MenuFunctions::Notify("����������Ϊ��~b~���;ѻ���ǹ+������ǹ+ȼ��ƿ+С��");
					}
					if (ruqinwuqi1 == 3)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4CNF_WEAPONS"), 4, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4CNF_WEAPONS"), 4, true);
						MenuFunctions::Notify("����������Ϊ��~b~MK2���ǹ+������ǹ+����ը��+С��");
					}
					if (ruqinwuqi1 == 4)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4CNF_WEAPONS"), 5, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4CNF_WEAPONS"), 5, true);
						MenuFunctions::Notify("����������Ϊ��~b~MK2ͻ����ǹ+������ǹ+����ը��+����");
					}
				}
			}
			if (gui.stringvector("ѡ���˻�����λ��", NULL, yunhuokache, yunhuokache1))
			{
				if (GetAsyncKeyState(gui.selectKey))
				{
					if (yunhuokache1 == 0)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4CNF_TROJAN"), 1, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4CNF_TROJAN"), 1, true);
						MenuFunctions::Notify("�������˻�����λ��Ϊ��~b~����");
					}
					if (yunhuokache1 == 1)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4CNF_TROJAN"), 2, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4CNF_TROJAN"), 2, true);
						MenuFunctions::Notify("�������˻�����λ��Ϊ��~b~������");
					}
					if (yunhuokache1 == 2)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4CNF_TROJAN"), 3, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4CNF_TROJAN"), 3, true);
						MenuFunctions::Notify("�������˻�����λ��Ϊ��~b~����ͷ");
					}
					if (yunhuokache1 == 3)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4CNF_TROJAN"), 4, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4CNF_TROJAN"), 4, true);
						MenuFunctions::Notify("�������˻�����λ��Ϊ��~b~����ͷ");
					}
				}
			}
			if (gui.Option("��������", NULL))
			{
				if (g_Task.daoyuxianjin)
				{
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_CASH_I_SCOPED"), -1, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_CASH_C_SCOPED"), -1, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_CASH_V_SCOPED"), -1, true);

					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_CASH_I_SCOPED"), -1, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_CASH_C_SCOPED"), -1, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_CASH_V_SCOPED"), -1, true);
					g_Task.daoyuxianjin = false;
				}
				if (g_Task.daoyudama)
				{
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_WEED_I_SCOPED"), -1, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_WEED_C_SCOPED"), -1, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_WEED_V_SCOPED"), -1, true);

					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_WEED_I_SCOPED"), -1, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_WEED_C_SCOPED"), -1, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_WEED_V_SCOPED"), -1, true);
					g_Task.daoyudama = false;
				}
				if (g_Task.daoyuhuangjin)
				{
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_GOLD_I_SCOPED"), -1, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_GOLD_C_SCOPED"), -1, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_GOLD_V_SCOPED"), -1, true);

					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_GOLD_I_SCOPED"), -1, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_GOLD_C_SCOPED"), -1, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_GOLD_V_SCOPED"), -1, true);
					g_Task.daoyuhuangjin = false;
				}
				if (g_Task.daoyukekaying)
				{
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_COKE_I_SCOPED"), -1, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_COKE_C_SCOPED"), -1, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_COKE_V_SCOPED"), -1, true);

					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_COKE_I_SCOPED"), -1, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_COKE_C_SCOPED"), -1, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_COKE_V_SCOPED"), -1, true);
					g_Task.daoyukekaying = false;
				}
				if (g_Task.daoyuhuazuo)
				{
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_PAINT_SCOPED"), -1, true);
					STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_PAINT_SCOPED"), -1, true);
					g_Task.daoyuhuazuo = false;
				}
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4_MISSIONS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4_MISSIONS"), -1, true);
				MenuFunctions::Notify((char*)"������ɣ���ˢ�»��������˳������ٽ��룡");
			}
			if (gui.Option("���û������", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4_MISSIONS"), 0, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4_PROGRESS"), 0, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4_PLAYTHROUGH_STATUS"), 0, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4_H4CNF_APPROACH"), 0, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4CNF_BS_ENTR"), 0, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4CNF_BS_GEN"), 0, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4_MISSIONS"), 0, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4_PROGRESS"), 0, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4_PLAYTHROUGH_STATUS"), 0, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4_H4CNF_APPROACH"), 0, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4CNF_BS_ENTR"), 0, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4CNF_BS_GEN"), 0, true);
				MenuFunctions::Notify("�ѽ�����������ã�~b~�����½��뻢����ˢ�»������");
			}
		}
		break;
				case ciyaomubiao:
				{
					gui.Title("ѡ���ҪĿ��");
					gui.Bool("�ֽ�", NULL, g_Task.daoyuxianjin);
					gui.Bool("�ƽ�", NULL, g_Task.daoyuhuangjin);
					gui.Bool("����", NULL, g_Task.daoyudama);
					gui.Bool("�ɿ���", NULL, g_Task.daoyukekaying);
					gui.Bool("����", NULL, g_Task.daoyuhuazuo);
					if (gui.Option("��մ�ҪĿ��", NULL))
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_CASH_I"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_CASH_C"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_CASH_I_SCOPED"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_CASH_C_SCOPED"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_CASH_V"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_WEED_I"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_WEED_C"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_WEED_I_SCOPED"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_WEED_C_SCOPED"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_WEED_V"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_COKE_I"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_COKE_C"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_COKE_I_SCOPED"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_COKE_C_SCOPED"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_COKE_V"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_GOLD_I"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_GOLD_C"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_GOLD_I_SCOPED"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_GOLD_C_SCOPED"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_GOLD_V"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_PAINT"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_PAINT_SCOPED"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H4LOOT_PAINT_V"), 0, true);

						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_CASH_I"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_CASH_C"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_CASH_I_SCOPED"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_CASH_C_SCOPED"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_CASH_V"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_WEED_I"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_WEED_C"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_WEED_I_SCOPED"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_WEED_C_SCOPED"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_WEED_V"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_COKE_I"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_COKE_C"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_COKE_I_SCOPED"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_COKE_C_SCOPED"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_COKE_V"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_GOLD_I"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_GOLD_C"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_GOLD_I_SCOPED"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_GOLD_C_SCOPED"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_GOLD_V"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_PAINT"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_PAINT_SCOPED"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H4LOOT_PAINT_V"), 0, true);
						MenuFunctions::Notify((char*)"�ɹ�������д�ҪĿ�꣡");
					}
				}
				break;
		case daoyuzhineng:
		{
			gui.Title("��������");
			if (gui.Option("�����г�����", "��ȷ�����Ѿ��и��ʲ����ܺ���"))
			{
				script_global({ 2794162 + 960 }, 1);
			}
			if (gui.Option("һ������ǰ��", "һ������ǰ�ã�������ȫ����������"))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4CNF_APPROACH"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4CNF_APPROACH"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4CNF_BS_ENTR"), 63, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4CNF_BS_ENTR"), 63, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4CNF_BS_GEN"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4CNF_BS_GEN"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4CNF_BS_ABIL"), 63, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4CNF_BS_ABIL"), 63, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4CNF_WEP_DISRP"), 3, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4CNF_WEP_DISRP"), 3, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4CNF_ARM_DISRP"), 3, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4CNF_ARM_DISRP"), 3, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4CNF_HEL_DISRP"), 3, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4CNF_HEL_DISRP"), 3, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_CASH_I_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_CASH_C_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_CASH_V_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_CASH_I_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_CASH_C_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_CASH_V_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_GOLD_I_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_GOLD_C_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_GOLD_V_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_GOLD_I_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_GOLD_C_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_GOLD_V_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_WEED_I_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_WEED_C_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_WEED_V_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_WEED_I_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_WEED_C_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_WEED_V_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_COKE_I_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_COKE_C_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_COKE_V_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_COKE_I_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_COKE_C_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_COKE_V_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4LOOT_PAINT_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4LOOT_PAINT_SCOPED"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4CNF_TARGET"), 5, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP_H4CNF_TARGET"), 5, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4CNF_WEAPONS"), 1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4CNF_WEAPONS"), 1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4CNF_WEAPONS"), 2, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4CNF_WEAPONS"), 2, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4CNF_WEAPONS"), 3, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4CNF_WEAPONS"), 3, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4CNF_WEAPONS"), 4, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4CNF_WEAPONS"), 4, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4CNF_WEAPONS"), 5, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4CNF_WEAPONS"), 5, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4CNF_GRAPPEL"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4CNF_GRAPPEL"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4CNF_UNIFORM"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4CNF_UNIFORM"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4CNF_BOLTCUT"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4CNF_BOLTCUT"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP0_H4_MISSIONS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("MP1_H4_MISSIONS"), -1, true);
				MenuFunctions::Notify((char*)"����ǰ����ɣ���ˢ�»�����������");
			}
			if (gui.Option("һ��ȫԱ135�ֺ�", NULL))
			{
				script_global({ 1978495 + 825 + 56 + 1 }, 135);
				script_global({ 1978495 + 825 + 56 + 2 }, 135);
				script_global({ 1978495 + 825 + 56 + 3 }, 135);
				script_global({ 1978495 + 825 + 56 + 4 }, 135);
			}
			if (gui.Option("ɱ������", NULL))
			{
				MenuFunctions::explodepeds();
			}
			if (gui.Option("���͵���ڣ�����", NULL))
			{
				MenuFunctions::teleportToObjective();
			}
			if (gui.Option("���͵���ҪĿ��", NULL))
			{
				Vector3 Coords;
				Coords.x = 5006.744f; Coords.y = -5756.1079f; Coords.z = 15.48f;
				MenuFunctions::ChangeCoords(Coords);
			}
			if (gui.Option("���͵����ų���", NULL))
			{
				Vector3 Coords;
				Coords.x = 4991.881f; Coords.y = -5718.831f; Coords.z = 19.8802f;
				MenuFunctions::ChangeCoords(Coords);
			}
			if (gui.Option("���͵�����", NULL))
			{
				Vector3 Coords;
				Coords.x = 4430.3916f; Coords.y = -6138.72f; Coords.z = -0.307f;
				MenuFunctions::ChangeCoords(Coords);
			}
		}
		break;
		case daoyuquanzidong:
		{
			gui.Title("�ֶ��߻�����");
			if (gui.stringvector("���ٷ�ʽ", NULL, qiangjiefangshi, qiangjiefangshi1))
			{
				if (GetAsyncKeyState(gui.selectKey))
				{
					if (qiangjiefangshi1 == 0)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_APPROACH"), 1, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_APPROACH"), 1, true);
						MenuFunctions::Notify((char*)"���������ٷ�ʽ��~b~����Ǳ��");
					}
					if (qiangjiefangshi1 == 1)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_APPROACH"), 2, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_APPROACH"), 2, true);
						MenuFunctions::Notify((char*)"���������ٷ�ʽ��~b~������թ");
					}
					if (qiangjiefangshi1 == 2)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_APPROACH"), 3, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_APPROACH"), 3, true);
						MenuFunctions::Notify((char*)"���������ٷ�ʽ��~b~��������");
					}
				}
			}
			if (gui.stringvector("����Ŀ��", NULL, qiangjiemubiao, qiangjiemubiao1))
			{
				if (GetAsyncKeyState(gui.selectKey))
				{
					if (qiangjiemubiao1 == 0)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_TARGET"), 0, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_TARGET"), 0, true);
						MenuFunctions::Notify((char*)"����������Ŀ�꣺~b~�ֽ�");
					}
					if (qiangjiemubiao1 == 1)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_TARGET"), 1, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_TARGET"), 1, true);
						MenuFunctions::Notify((char*)"����������Ŀ�꣺~b~�ƽ�");
					}
					if (qiangjiemubiao1 == 2)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_TARGET"), 2, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_TARGET"), 2, true);
						MenuFunctions::Notify((char*)"����������Ŀ�꣺~b~����");
					}
					if (qiangjiemubiao1 == 3)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_TARGET"), 3, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_TARGET"), 3, true);
						MenuFunctions::Notify((char*)"����������Ŀ�꣺~b~��ʯ");
					}
				}
			}
			if (gui.Option("����������Ȥ��", "��һ�����ĳ����ֶ����")) {
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_POI"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_POI"), -1, true);
				MenuFunctions::Notify((char*)"����������Ȥ�����");
			}
			if (gui.Option("������������", "��һ�����ĳ����ֶ����")) {
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_ACCESSPOINTS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_ACCESSPOINTS"), -1, true);
				MenuFunctions::Notify((char*)"��������������ɣ�");
			}
			if (gui.Option("��ɵ�һ��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_BITSET1"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_BITSET1"), -1, true);
				MenuFunctions::Notify("�ѳɹ��ύ��һ��");
			}
			if (gui.Option("���õ�һ��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_BITSET1"), 0, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_BITSET1"), 0, true);
				MenuFunctions::Notify("�ѳɹ����õ�һ��");
			}
			if (gui.stringvector("ѡ��ǹ�ֵȼ�", NULL, qiangshoudengji, qiangshoudengji1))
			{
				if (GetAsyncKeyState(gui.selectKey))
				{
					if (qiangshoudengji1 == 0)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_CREWWEAP"), 1, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_CREWWEAP"), 1, true);
						MenuFunctions::Notify("��ǰǹ�ֵȼ���~b~�");
					}
					if (qiangshoudengji1 == 1)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_CREWWEAP"), 3, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_CREWWEAP"), 3, true);
						MenuFunctions::Notify("��ǰǹ�ֵȼ���~b~����");
					}
					if (qiangshoudengji1 == 2)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_CREWWEAP"), 4, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_CREWWEAP"), 4, true);
						MenuFunctions::Notify("��ǰǹ�ֵȼ���~b~����");
					}
				}
			}
			if (gui.stringvector("ѡ���ֵȼ�", NULL, cheshoudengji, cheshoudengji1))
			{
				if (GetAsyncKeyState(gui.selectKey))
				{
					if (cheshoudengji1 == 0)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_CREWDRIVER"), 1, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_CREWDRIVER"), 1, true);
						MenuFunctions::Notify("��ǰ���ֵȼ���~b~�");
					}
					if (cheshoudengji1 == 1)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_CREWDRIVER"), 3, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_CREWDRIVER"), 3, true);
						MenuFunctions::Notify("��ǰ���ֵȼ���~b~����");
					}
					if (cheshoudengji1 == 2)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_CREWDRIVER"), 5, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_CREWDRIVER"), 5, true);
						MenuFunctions::Notify("��ǰ���ֵȼ���~b~����");
					}
				}
			}
			if (gui.stringvector("ѡ��ڿ͵ȼ�", NULL, heikedengji, heikedengji1))
			{
				if (GetAsyncKeyState(gui.selectKey))
				{
					if (heikedengji1 == 0)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_CREWHACKER"), 1, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_CREWHACKER"), 1, true);
						MenuFunctions::Notify("��ǰ�ڿ͵ȼ���~b~�");
					}
					if (heikedengji1 == 1)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_CREWHACKER"), 3, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_CREWHACKER"), 3, true);
						MenuFunctions::Notify("��ǰ�ڿ͵ȼ���~b~����");
					}
					if (heikedengji1 == 2)
					{
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_CREWHACKER"), 4, true);
						STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_CREWHACKER"), 4, true);
						MenuFunctions::Notify("��ǰ�ڿ͵ȼ���~b~����");
					}
				}
			}
			if (gui.Option("��ɶŸ�����", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_DISRUPTSHIP"), 3, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_DISRUPTSHIP"), 3, true);
				MenuFunctions::Notify("�ѳɹ���ɶŸ���������");
			}
			if (gui.Option("��ȡ�����Ž�", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_KEYLEVELS"), 2, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_KEYLEVELS"), 2, true);
				MenuFunctions::Notify("��ǰԿ�׿���~b~����");
			}
			if (gui.Option("��ɵڶ���", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_BITSET0"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_BITSET0"), -1, true);
				MenuFunctions::Notify("�ѳɹ��ύ�ڶ���");
			}
			if (gui.Option("���õڶ���", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_BITSET0"), 0, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_BITSET0"), 0, true);
				MenuFunctions::Notify("�ѳɹ����õڶ���");
			}
		}
		break;
		case Casino_front:
		{
			gui.Title("�ĳ�����");
			gui.SubMenu("�ֶ��߻�����", NULL, duchangshoudong);
			gui.SubMenu("������ҷֺ�", NULL, duchangfenhong);
			if (gui.Option("ɾ��NPC�ֺ�", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_CREWWEAP"), 6, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_CREWWEAP"), 6, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_CREWDRIVER"), 6, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_CREWDRIVER"), 6, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_CREWHACKER"), 6, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_CREWHACKER"), 6, true);
				MenuFunctions::Notify("�ѳɹ�ɾ��NPC�ֺ�");
			}
			if (gui.Option("ˢ��������ȴʱ��", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3_COMPLETEDPOSIX"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3_COMPLETEDPOSIX"), -1, true);
				MenuFunctions::Notify("��ˢ���������ȴʱ�䣬����Ч���˳�CEO/Ħ�а�뿪��Ϸ���ٴε��");
			}
			if (gui.Option("�޸���ʼ���񿨲߻��忨����", NULL))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_ACCESSPOINTS"), 0, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_ACCESSPOINTS"), 0, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_POI"), 0, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_POI"), 0, true);
				MenuFunctions::Notify("�����¿�ʼ���ĳ������~");
			}
		}
		break;
		case duchangfenhong:
		{
			gui.Title("������ҷֺ�");
			if (gui.Option("����������ҷֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					int fh = MenuFunctions::NumberKeyboard();
					script_global({ 1971696 + 1497 + 736 + 92 + 1 }, fh);
					script_global({ 1971696 + 1497 + 736 + 92 + 2 }, fh);
					script_global({ 1971696 + 1497 + 736 + 92 + 3 }, fh);
					script_global({ 1971696 + 1497 + 736 + 92 + 4 }, fh);
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("�������1�ֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					int fh = MenuFunctions::NumberKeyboard();
					script_global({ 1971696 + 1497 + 736 + 92 + 1 }, fh);
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("�������2�ֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					int fh = MenuFunctions::NumberKeyboard();
					script_global({ 1971696 + 1497 + 736 + 92 + 2 }, fh);
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("�������3�ֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					int fh = MenuFunctions::NumberKeyboard();
					script_global({ 1971696 + 1497 + 736 + 92 + 3 }, fh);
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("�������4�ֺ�", NULL))
			{
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					int fh = MenuFunctions::NumberKeyboard();
					script_global({ 1971696 + 1497 + 736 + 92 + 4 }, fh);
					fhtime = GetTickCount64();
				}
			}
		}
		break;
		case duchangzidong:
		{
			gui.SubMenu("��������", NULL, qishixiongxiong);
		}
		break;
		case qishixiongxiong:
		{
			gui.Title("��������");
			if (gui.Option("һ��������������ǰ������", "һ��Ԥ�裬�������ڣ���ʯ������"))
			{
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_POI"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_POI"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_ACCESSPOINTS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_ACCESSPOINTS"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_APPROACH"), 3, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_APPROACH"), 3, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_TARGET"), 3, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_TARGET"), 3, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_BITSET1"), -1, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_BITSET1"), -1, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_CREWWEAP"), 4, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_CREWWEAP"), 4, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_CREWDRIVER"), 5, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_CREWDRIVER"), 5, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_CREWHACKER"), 4, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_CREWHACKER"), 4, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_DISRUPTSHIP"), 3, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_DISRUPTSHIP"), 3, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_KEYLEVELS"), 2, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_KEYLEVELS"), 2, true);
			}
			if (gui.Option("ɾ��NPC�ֺ�", NULL)) {
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_CREWWEAP"), 6, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_CREWDRIVER"), 6, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_H3OPT_CREWHACKER"), 6, true);

				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_CREWWEAP"), 6, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_CREWDRIVER"), 6, true);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_H3OPT_CREWHACKER"), 6, true);
				MenuFunctions::Notify("��ɾ������NPC�ֺ�");
			}
			if (gui.Option("ȫԱ85�ֺ�", NULL)) {
				if (GetTickCount64() - fhtime < 300)
				{
				}
				else
				{
					script_global({ 1971696 + 1497 + 736 + 92 + 1 }, 85);
					script_global({ 1971696 + 1497 + 736 + 92 + 2 }, 85);
					script_global({ 1971696 + 1497 + 736 + 92 + 3 }, 85);
					script_global({ 1971696 + 1497 + 736 + 92 + 4 }, 85);
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("�Զ������������", NULL))
			{
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 31656, 99999);
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 28332, 99999);
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 31656, 99999);
				script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 19710, 12);
			}
		}
		break;
		case teleport:
		{
			gui.Title("����ѡ��");
			gui.SubMenu("IPL", NULL, ipl);
			gui.SubMenu("���͵����õص�", NULL, commonteleport);
			gui.SubMenu("���͵����ڵص�", NULL, Internaltp);
			gui.Bool("�Զ����͵���ǵ�", NULL, g_Teleport.autoteleport);
			if (gui.Option("���͵���ǵ�", NULL))
			{
				if (GetTickCount64() - fhtime < 500)
				{
				}
				else
				{
					MenuFunctions::TpWaypoint();
					fhtime = GetTickCount64();
				}
			}
			if (gui.Option("���͵������", NULL))
			{
				MenuFunctions::teleport_to_objective();
			}
			if (gui.Option("��ǰ����", NULL))
			{
				Vector3 Coords = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(PLAYER::PLAYER_PED_ID(), 0.0, 3.0, 0.0);
				int player = PLAYER::PLAYER_PED_ID();
				if (PED::IS_PED_IN_ANY_VEHICLE(player, 0))
					player = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(player, Coords.x, Coords.y, Coords.z, 0, 0, 1);
			}
			if (gui.Option("���ϴ���", NULL))
			{
				Vector3 Coords = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(PLAYER::PLAYER_PED_ID(), 0.0, 0.0, 3.0);
				int player = PLAYER::PLAYER_PED_ID();
				if (PED::IS_PED_IN_ANY_VEHICLE(player, 0))
					player = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(player, Coords.x, Coords.y, Coords.z, 0, 0, 1);
			}
			if (gui.Option("�����", NULL))
			{
				Vector3 Coords = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(PLAYER::PLAYER_PED_ID(), 0.0, -3.0, 0.0);
				int player = PLAYER::PLAYER_PED_ID();
				if (PED::IS_PED_IN_ANY_VEHICLE(player, 0))
					player = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(player, Coords.x, Coords.y, Coords.z, 0, 0, 1);
			}
			if (gui.Option("���´���", NULL))
			{
				Vector3 Coords = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(PLAYER::PLAYER_PED_ID(), 0.0, 0.0, -3.0);
				int player = PLAYER::PLAYER_PED_ID();
				if (PED::IS_PED_IN_ANY_VEHICLE(player, 0))
					player = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(player, Coords.x, Coords.y, Coords.z, 0, 0, 1);
			}
		}
		break;
		case Internaltp:
		{
			Vector3 pos;
			gui.Title("���ڵص�");
			if (gui.Option("FIB��¥¥��", NULL))
			{
				pos.x = 136.0f; pos.y = -750.f; pos.z = 262.f;
				MenuFunctions::ChangeCoords(pos);
			}
			if (gui.Option("��װ��", NULL))
			{
				pos.x = 712.716f; pos.y = -962.906f; pos.z = 30.6f;
				MenuFunctions::ChangeCoords(pos);
			}
			if (gui.Option("�������ּ�", NULL))
			{
				pos.x = 7.119f; pos.y = 536.615f; pos.z = 176.2f;
				MenuFunctions::ChangeCoords(pos);
			}
			if (gui.Option("��˼�", NULL))
			{
				pos.x = -813.603f; pos.y = 179.474f; pos.z = 72.5f;
				MenuFunctions::ChangeCoords(pos);
			}
			if (gui.Option("�޷��", NULL))
			{
				pos.x = 1972.610f; pos.y = 3817.040f; pos.z = 33.65f;
				MenuFunctions::ChangeCoords(pos);
			}
			if (gui.Option("����˹���̼�", NULL))
			{
				pos.x = -14.380f; pos.y = -1438.510f; pos.z = 31.3f;
				MenuFunctions::ChangeCoords(pos);
			}
			if (gui.Option("�������¼�", NULL))
			{
				pos.x = -1151.770f; pos.y = -1518.138f; pos.z = 10.85f;
				MenuFunctions::ChangeCoords(pos);
			}
			if (gui.Option("��˹�ؼ�", NULL))
			{
				pos.x = 1273.898f; pos.y = -1719.304f; pos.z = 54.8f;
				MenuFunctions::ChangeCoords(pos);
			}
			if (gui.Option("��������ֲ�", NULL))
			{
				pos.x = 97.271f; pos.y = -1290.994f; pos.z = 29.45f;
				MenuFunctions::ChangeCoords(pos);
			}
			if (gui.Option("���н�⣨̫ƽ���׼��", NULL))
			{
				pos.x = 255.85f; pos.y = 217.f; pos.z = 101.9f;
				MenuFunctions::ChangeCoords(pos);
			}
			if (gui.Option("ϲ����ֲ�", NULL))
			{
				pos.x = 378.100f; pos.y = -999.964f; pos.z = -98.6f;
				MenuFunctions::ChangeCoords(pos);
			}
			if (gui.Option("�˵�ʵ����", NULL))
			{
				pos.x = 3614.394f; pos.y = 3744.803f; pos.z = 28.9f;
				MenuFunctions::ChangeCoords(pos);
			}
			if (gui.Option("�˵�ʵ���ҵص�", NULL))
			{
				pos.x = 3525.201f; pos.y = 3709.625f; pos.z = 21.2f;
				MenuFunctions::ChangeCoords(pos);
			}
			if (gui.Option("IAA�칫��", NULL))
			{
				pos.x = 113.568f; pos.y = -619.001f; pos.z = 206.25f;
				MenuFunctions::ChangeCoords(pos);
			}
			if (gui.Option("��Ѷ��", NULL))
			{
				pos.x = 142.746f; pos.y = -2201.189f; pos.z = 4.9f;
				MenuFunctions::ChangeCoords(pos);
			}
			if (gui.Option("���»��ظ���", NULL))
			{
				pos.x = -2358.132f; pos.y = 3249.754f; pos.z = 101.65f;
				MenuFunctions::ChangeCoords(pos);
			}
			if (gui.Option("��", NULL))
			{
				pos.x = -595.342f; pos.y = 2086.008f; pos.z = 131.6f;
				MenuFunctions::ChangeCoords(pos);
			}
		}
		break;
		case commonteleport:
		{
			gui.Title("���õص�");
			if (gui.Option("ǧ��ɽ", NULL))
			{
				Vector3 Coords;
				Coords.x = 489.979f; Coords.y = 5587.527f; Coords.z = 794.3f;
				MenuFunctions::ChangeCoords(Coords);
			}
			if (gui.Option("��԰����", NULL))
			{
				Vector3 Coords;
				Coords.x = -74.94243f; Coords.y = -818.63446f; Coords.z = 326.174347f;
				MenuFunctions::ChangeCoords(Coords);
			}
			if (gui.Option("��ߵ�", NULL))
			{
				Vector3 Coords;
				Coords.x = -1338.16; Coords.y = -1278.11; Coords.z = 4.87;
				MenuFunctions::ChangeCoords(Coords);
			}
			if (gui.Option("�߼���װ��", NULL))
			{
				Vector3 Coords;
				Coords.x = -718.91; Coords.y = -158.16; Coords.z = 37.00;
				MenuFunctions::ChangeCoords(Coords);
			}
			if (gui.Option("��ʥ���ĳ���", NULL))
			{
				Vector3 Coords;
				Coords.x = -365.425f; Coords.y = -131.809f; Coords.z = -225.f;
				MenuFunctions::ChangeCoords(Coords);
			}
			if (gui.Option("������", NULL))
			{
				Vector3 Coords;
				Coords.x = 247.3652; Coords.y = -45.8777; Coords.z = 69.9411;
				MenuFunctions::ChangeCoords(Coords);
			}
			if (gui.Option("��ʥ�����ʻ���", NULL))
			{
				Vector3 Coords;
				Coords.x = -1102.2910f; Coords.y = -2894.5160f; Coords.z = 13.9467f;
				MenuFunctions::ChangeCoords(Coords);
			}
			if (gui.Option("ɣ�Ϻ�������", NULL))
			{
				Vector3 Coords;
				Coords.x = 1747.f; Coords.y = 3273.f; Coords.z = -225.f;
				MenuFunctions::ChangeCoords(Coords);
			}
			if (gui.Option("��ͨϿ���ٲ�", NULL))
			{
				Vector3 Coords;
				Coords.x = -597.9525f; Coords.y = 4475.2910f; Coords.z = 25.6890f;
				MenuFunctions::ChangeCoords(Coords);

			}
			if (gui.Option("FIB��¥�ڲ�", NULL))
			{
				Vector3 Coords;
				Coords.x = 135.5220f; Coords.y = -749.0003f; Coords.z = 260.0000f;
				MenuFunctions::ChangeCoords(Coords);
			}
			if (gui.Option("�˵�ʵ����", NULL))
			{
				Vector3 Coords;
				Coords.x = 3617.231f; Coords.y = 3739.871f; Coords.z = 28.6901f;
				MenuFunctions::ChangeCoords(Coords);
			}
			if (gui.Option("ɣ��౤��", NULL))
			{
				Vector3 Coords;
				Coords.x = -2356.0940; Coords.y = 3248.645; Coords.z = 101.4505;
				MenuFunctions::ChangeCoords(Coords);
			}
			if (gui.Option("��β¥����", NULL))
			{
				Vector3 Coords;
				Coords.x = -222.1977; Coords.y = -1185.8500; Coords.z = 23.0294;
				MenuFunctions::ChangeCoords(Coords);
			}
			if (gui.Option("ɳĮ����", NULL))
			{
				Vector3 Coords;
				Coords.x = 1741.4960f; Coords.y = 3269.2570f; Coords.z = 41.6014f;
				MenuFunctions::ChangeCoords(Coords);
			}
			if (gui.Option("IAA�칫��", NULL))
			{
				Vector3 Coords;
				Coords.x = 113.568f; Coords.y = -619.001f; Coords.z = 206.25f;
				MenuFunctions::ChangeCoords(Coords);
			}
			if (gui.Option("��������ֲ�", NULL))
			{
				Vector3 Coords;
				Coords.x = 97.271f; Coords.y = -1290.994f; Coords.z = 29.45f;
				MenuFunctions::ChangeCoords(Coords);
			}
		}
		break;
		case ipl:
		{
			gui.Title("IPL");
			if (gui.Option("����˶�", NULL))
			{
				STREAMING::REQUEST_IPL("prologue01");
				STREAMING::REQUEST_IPL("Prologue01c");
				STREAMING::REQUEST_IPL("Prologue01d");
				STREAMING::REQUEST_IPL("Prologue01e");
				STREAMING::REQUEST_IPL("Prologue01f");
				STREAMING::REQUEST_IPL("Prologue01g");
				STREAMING::REQUEST_IPL("prologue01h");
				STREAMING::REQUEST_IPL("prologue01i");
				STREAMING::REQUEST_IPL("prologue01j");
				STREAMING::REQUEST_IPL("prologue01k");
				STREAMING::REQUEST_IPL("prologue01z");
				STREAMING::REQUEST_IPL("prologue02");
				STREAMING::REQUEST_IPL("prologue03");
				STREAMING::REQUEST_IPL("prologue03b");
				STREAMING::REQUEST_IPL("prologue03_grv_cov");
				STREAMING::REQUEST_IPL("prologue03_grv_dug");
				STREAMING::REQUEST_IPL("prologue03_grv_fun");
				STREAMING::REQUEST_IPL("prologue04");
				STREAMING::REQUEST_IPL("prologue04b");
				STREAMING::REQUEST_IPL("prologue04_cover");
				STREAMING::REQUEST_IPL("prologue05");
				STREAMING::REQUEST_IPL("prologue05b");
				STREAMING::REQUEST_IPL("prologue06");
				STREAMING::REQUEST_IPL("prologue06b");
				STREAMING::REQUEST_IPL("prologue06_int");
				STREAMING::REQUEST_IPL("prologuerd");
				STREAMING::REQUEST_IPL("prologuerdb");
				STREAMING::REQUEST_IPL("prologue_DistantLights");
				STREAMING::REQUEST_IPL("prologue_grv_torch");
				STREAMING::REQUEST_IPL("prologue_m2_door");
				STREAMING::REQUEST_IPL("prologue_LODLights");
				STREAMING::REQUEST_IPL("DES_ProTree_start");
				PED::SET_PED_COORDS_KEEP_VEHICLE(PLAYER::PLAYER_PED_ID(), 3595.39673f, -4893.727f, 115.838394f);
			}
			if (gui.Option("����Ƶ�", NULL))
			{
				STREAMING::REQUEST_IPL("h4_islandx_terrain_01_lod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_01_slod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_02");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_02_lod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_02_slod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_03");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_03_lod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_04");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_04_lod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_04_slod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_05");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_05_lod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_05_slod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_06");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_01_grass_0");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_01_grass_1");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_02_grass_0");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_02_grass_1");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_02_grass_2");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_02_grass_3");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_04_grass_0");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_04_grass_1");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_05_grass_0");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_06_grass_0");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_06_lod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_06_slod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_05_a");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_05_a_lod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_05_b");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_05_b_lod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_05_c");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_05_c_lod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_05_d");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_05_d_lod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_05_d_slod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_05_e");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_05_e_lod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_05_e_slod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_05_f");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_05_f_lod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_05_f_slod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_06_a");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_06_a_lod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_06_a_slod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_06_b");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_06_b_lod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_06_b_slod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_06_c");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_06_c_lod");
				STREAMING::REQUEST_IPL("h4_islandx_terrain_props_06_c_slod");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_01");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_01_long_0");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_02");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_03");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_04");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_05");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_06");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_06_strm_0");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_lod");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_occ_00");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_occ_01");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_occ_02");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_occ_03");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_occ_04");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_occ_05");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_occ_06");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_occ_07");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_occ_08");
				STREAMING::REQUEST_IPL("h4_mph4_terrain_occ_09");
				STREAMING::REQUEST_IPL("h4_boatblockers");
				STREAMING::REQUEST_IPL("h4_islandx");
				STREAMING::REQUEST_IPL("h4_islandx_disc_strandedshark");
				STREAMING::REQUEST_IPL("h4_islandx_disc_strandedshark_lod");
				STREAMING::REQUEST_IPL("h4_islandx_disc_strandedwhale");
				STREAMING::REQUEST_IPL("h4_islandx_disc_strandedwhale_lod");
				STREAMING::REQUEST_IPL("h4_islandx_props");
				STREAMING::REQUEST_IPL("h4_islandx_props_lod");
				STREAMING::REQUEST_IPL("h4_islandx_sea_mines");
				STREAMING::REQUEST_IPL("h4_mph4_island");
				STREAMING::REQUEST_IPL("h4_mph4_island_long_0");
				STREAMING::REQUEST_IPL("h4_mph4_island_strm_0");
				STREAMING::REQUEST_IPL("h4_aa_guns");
				STREAMING::REQUEST_IPL("h4_aa_guns_lod");
				STREAMING::REQUEST_IPL("h4_beach");
				STREAMING::REQUEST_IPL("h4_beach_bar_props");
				STREAMING::REQUEST_IPL("h4_beach_lod");
				STREAMING::REQUEST_IPL("h4_beach_party");
				STREAMING::REQUEST_IPL("h4_beach_party_lod");
				STREAMING::REQUEST_IPL("h4_beach_props");
				STREAMING::REQUEST_IPL("h4_beach_props_lod");
				STREAMING::REQUEST_IPL("h4_beach_props_party");
				STREAMING::REQUEST_IPL("h4_beach_props_slod");
				STREAMING::REQUEST_IPL("h4_beach_slod");
				STREAMING::REQUEST_IPL("h4_islandairstrip");
				STREAMING::REQUEST_IPL("h4_islandairstrip_doorsclosed");
				STREAMING::REQUEST_IPL("h4_islandairstrip_doorsclosed_lod");
				STREAMING::REQUEST_IPL("h4_islandairstrip_doorsopen");
				STREAMING::REQUEST_IPL("h4_islandairstrip_doorsopen_lod");
				STREAMING::REQUEST_IPL("h4_islandairstrip_hangar_props");
				STREAMING::REQUEST_IPL("h4_islandairstrip_hangar_props_lod");
				STREAMING::REQUEST_IPL("h4_islandairstrip_hangar_props_slod");
				STREAMING::REQUEST_IPL("h4_islandairstrip_lod");
				STREAMING::REQUEST_IPL("h4_islandairstrip_props");
				STREAMING::REQUEST_IPL("h4_islandairstrip_propsb");
				STREAMING::REQUEST_IPL("h4_islandairstrip_propsb_lod");
				STREAMING::REQUEST_IPL("h4_islandairstrip_propsb_slod");
				STREAMING::REQUEST_IPL("h4_islandairstrip_props_lod");
				STREAMING::REQUEST_IPL("h4_islandairstrip_props_slod");
				STREAMING::REQUEST_IPL("h4_islandairstrip_slod");
				STREAMING::REQUEST_IPL("h4_islandxcanal_props");
				STREAMING::REQUEST_IPL("h4_islandxcanal_props_lod");
				STREAMING::REQUEST_IPL("h4_islandxcanal_props_slod");
				STREAMING::REQUEST_IPL("h4_islandxdock");
				STREAMING::REQUEST_IPL("h4_islandxdock_lod");
				STREAMING::REQUEST_IPL("h4_islandxdock_props");
				STREAMING::REQUEST_IPL("h4_islandxdock_props_2");
				STREAMING::REQUEST_IPL("h4_islandxdock_props_2_lod");
				STREAMING::REQUEST_IPL("h4_islandxdock_props_2_slod");
				STREAMING::REQUEST_IPL("h4_islandxdock_props_lod");
				STREAMING::REQUEST_IPL("h4_islandxdock_props_slod");
				STREAMING::REQUEST_IPL("h4_islandxdock_slod");
				STREAMING::REQUEST_IPL("h4_islandxdock_water_hatch");
				STREAMING::REQUEST_IPL("h4_islandxtower");
				STREAMING::REQUEST_IPL("h4_islandxtower_lod");
				STREAMING::REQUEST_IPL("h4_islandxtower_slod");
				STREAMING::REQUEST_IPL("h4_islandxtower_veg");
				STREAMING::REQUEST_IPL("h4_islandxtower_veg_lod");
				STREAMING::REQUEST_IPL("h4_islandxtower_veg_slod");
				STREAMING::REQUEST_IPL("h4_islandx_barrack_hatch");
				STREAMING::REQUEST_IPL("h4_islandx_barrack_props");
				STREAMING::REQUEST_IPL("h4_islandx_barrack_props_lod");
				STREAMING::REQUEST_IPL("h4_islandx_barrack_props_slod");
				STREAMING::REQUEST_IPL("h4_islandx_checkpoint");
				STREAMING::REQUEST_IPL("h4_islandx_checkpoint_lod");
				STREAMING::REQUEST_IPL("h4_islandx_checkpoint_props");
				STREAMING::REQUEST_IPL("h4_islandx_checkpoint_props_lod");
				STREAMING::REQUEST_IPL("h4_islandx_checkpoint_props_slod");
				STREAMING::REQUEST_IPL("h4_islandx_maindock");
				STREAMING::REQUEST_IPL("h4_islandx_maindock_lod");
				STREAMING::REQUEST_IPL("h4_islandx_maindock_props");
				STREAMING::REQUEST_IPL("h4_islandx_maindock_props_2");
				STREAMING::REQUEST_IPL("h4_islandx_maindock_props_2_lod");
				STREAMING::REQUEST_IPL("h4_islandx_maindock_props_2_slod");
				STREAMING::REQUEST_IPL("h4_islandx_maindock_props_lod");
				STREAMING::REQUEST_IPL("h4_islandx_maindock_props_slod");
				STREAMING::REQUEST_IPL("h4_islandx_maindock_slod");
				STREAMING::REQUEST_IPL("h4_islandx_mansion");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_b");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_b_lod");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_b_side_fence");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_b_slod");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_entrance_fence");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_guardfence");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_lights");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_lockup_01");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_lockup_01_lod");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_lockup_02");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_lockup_02_lod");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_lockup_03");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_lockup_03_lod");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_lod");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_office");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_office_lod");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_props");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_props_lod");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_props_slod");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_slod");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_vault");
				STREAMING::REQUEST_IPL("h4_islandx_mansion_vault_lod");
				STREAMING::REQUEST_IPL("h4_island_padlock_props");
				STREAMING::REQUEST_IPL("h4_mansion_gate_broken");
				STREAMING::REQUEST_IPL("h4_mansion_gate_closed");
				STREAMING::REQUEST_IPL("h4_mansion_remains_cage");
				STREAMING::REQUEST_IPL("h4_mph4_airstrip");
				STREAMING::REQUEST_IPL("h4_mph4_airstrip_interior_0_airstrip_hanger");
				STREAMING::REQUEST_IPL("h4_mph4_beach");
				STREAMING::REQUEST_IPL("h4_mph4_dock");
				STREAMING::REQUEST_IPL("h4_mph4_island_lod");
				STREAMING::REQUEST_IPL("h4_mph4_island_ne_placement");
				STREAMING::REQUEST_IPL("h4_mph4_island_nw_placement");
				STREAMING::REQUEST_IPL("h4_mph4_island_se_placement");
				STREAMING::REQUEST_IPL("h4_mph4_island_sw_placement");
				STREAMING::REQUEST_IPL("h4_mph4_mansion");
				STREAMING::REQUEST_IPL("h4_mph4_mansion_b");
				STREAMING::REQUEST_IPL("h4_mph4_mansion_b_strm_0");
				STREAMING::REQUEST_IPL("h4_mph4_mansion_strm_0");
				STREAMING::REQUEST_IPL("h4_mph4_wtowers");
				STREAMING::REQUEST_IPL("h4_ne_ipl_00");
				STREAMING::REQUEST_IPL("h4_ne_ipl_00_lod");
				STREAMING::REQUEST_IPL("h4_ne_ipl_00_slod");
				STREAMING::REQUEST_IPL("h4_ne_ipl_01");
				STREAMING::REQUEST_IPL("h4_ne_ipl_01_lod");
				STREAMING::REQUEST_IPL("h4_ne_ipl_01_slod");
				STREAMING::REQUEST_IPL("h4_ne_ipl_02");
				STREAMING::REQUEST_IPL("h4_ne_ipl_02_lod");
				STREAMING::REQUEST_IPL("h4_ne_ipl_02_slod");
				STREAMING::REQUEST_IPL("h4_ne_ipl_03");
				STREAMING::REQUEST_IPL("h4_ne_ipl_03_lod");
				STREAMING::REQUEST_IPL("h4_ne_ipl_03_slod");
				STREAMING::REQUEST_IPL("h4_ne_ipl_04");
				STREAMING::REQUEST_IPL("h4_ne_ipl_04_lod");
				STREAMING::REQUEST_IPL("h4_ne_ipl_04_slod");
				STREAMING::REQUEST_IPL("h4_ne_ipl_05");
				STREAMING::REQUEST_IPL("h4_ne_ipl_05_lod");
				STREAMING::REQUEST_IPL("h4_ne_ipl_05_slod");
				STREAMING::REQUEST_IPL("h4_ne_ipl_06");
				STREAMING::REQUEST_IPL("h4_ne_ipl_06_lod");
				STREAMING::REQUEST_IPL("h4_ne_ipl_06_slod");
				STREAMING::REQUEST_IPL("h4_ne_ipl_07");
				STREAMING::REQUEST_IPL("h4_ne_ipl_07_lod");
				STREAMING::REQUEST_IPL("h4_ne_ipl_07_slod");
				STREAMING::REQUEST_IPL("h4_ne_ipl_08");
				STREAMING::REQUEST_IPL("h4_ne_ipl_08_lod");
				STREAMING::REQUEST_IPL("h4_ne_ipl_08_slod");
				STREAMING::REQUEST_IPL("h4_ne_ipl_09");
				STREAMING::REQUEST_IPL("h4_ne_ipl_09_lod");
				STREAMING::REQUEST_IPL("h4_ne_ipl_09_slod");
				STREAMING::REQUEST_IPL("h4_nw_ipl_00");
				STREAMING::REQUEST_IPL("h4_nw_ipl_00_lod");
				STREAMING::REQUEST_IPL("h4_nw_ipl_00_slod");
				STREAMING::REQUEST_IPL("h4_nw_ipl_01");
				STREAMING::REQUEST_IPL("h4_nw_ipl_01_lod");
				STREAMING::REQUEST_IPL("h4_nw_ipl_01_slod");
				STREAMING::REQUEST_IPL("h4_nw_ipl_02");
				STREAMING::REQUEST_IPL("h4_nw_ipl_02_lod");
				STREAMING::REQUEST_IPL("h4_nw_ipl_02_slod");
				STREAMING::REQUEST_IPL("h4_nw_ipl_03");
				STREAMING::REQUEST_IPL("h4_nw_ipl_03_lod");
				STREAMING::REQUEST_IPL("h4_nw_ipl_03_slod");
				STREAMING::REQUEST_IPL("h4_nw_ipl_04");
				STREAMING::REQUEST_IPL("h4_nw_ipl_04_lod");
				STREAMING::REQUEST_IPL("h4_nw_ipl_04_slod");
				STREAMING::REQUEST_IPL("h4_nw_ipl_05");
				STREAMING::REQUEST_IPL("h4_nw_ipl_05_lod");
				STREAMING::REQUEST_IPL("h4_nw_ipl_05_slod");
				STREAMING::REQUEST_IPL("h4_nw_ipl_06");
				STREAMING::REQUEST_IPL("h4_nw_ipl_06_lod");
				STREAMING::REQUEST_IPL("h4_nw_ipl_06_slod");
				STREAMING::REQUEST_IPL("h4_nw_ipl_07");
				STREAMING::REQUEST_IPL("h4_nw_ipl_07_lod");
				STREAMING::REQUEST_IPL("h4_nw_ipl_07_slod");
				STREAMING::REQUEST_IPL("h4_nw_ipl_08");
				STREAMING::REQUEST_IPL("h4_nw_ipl_08_lod");
				STREAMING::REQUEST_IPL("h4_nw_ipl_08_slod");
				STREAMING::REQUEST_IPL("h4_nw_ipl_09");
				STREAMING::REQUEST_IPL("h4_nw_ipl_09_lod");
				STREAMING::REQUEST_IPL("h4_nw_ipl_09_slod");
				STREAMING::REQUEST_IPL("h4_se_ipl_00");
				STREAMING::REQUEST_IPL("h4_se_ipl_00_lod");
				STREAMING::REQUEST_IPL("h4_se_ipl_00_slod");
				STREAMING::REQUEST_IPL("h4_se_ipl_01");
				STREAMING::REQUEST_IPL("h4_se_ipl_01_lod");
				STREAMING::REQUEST_IPL("h4_se_ipl_01_slod");
				STREAMING::REQUEST_IPL("h4_se_ipl_02");
				STREAMING::REQUEST_IPL("h4_se_ipl_02_lod");
				STREAMING::REQUEST_IPL("h4_se_ipl_02_slod");
				STREAMING::REQUEST_IPL("h4_se_ipl_03");
				STREAMING::REQUEST_IPL("h4_se_ipl_03_lod");
				STREAMING::REQUEST_IPL("h4_se_ipl_03_slod");
				STREAMING::REQUEST_IPL("h4_se_ipl_04");
				STREAMING::REQUEST_IPL("h4_se_ipl_04_lod");
				STREAMING::REQUEST_IPL("h4_se_ipl_04_slod");
				STREAMING::REQUEST_IPL("h4_se_ipl_05");
				STREAMING::REQUEST_IPL("h4_se_ipl_05_lod");
				STREAMING::REQUEST_IPL("h4_se_ipl_05_slod");
				STREAMING::REQUEST_IPL("h4_se_ipl_06");
				STREAMING::REQUEST_IPL("h4_se_ipl_06_lod");
				STREAMING::REQUEST_IPL("h4_se_ipl_06_slod");
				STREAMING::REQUEST_IPL("h4_se_ipl_07");
				STREAMING::REQUEST_IPL("h4_se_ipl_07_lod");
				STREAMING::REQUEST_IPL("h4_se_ipl_07_slod");
				STREAMING::REQUEST_IPL("h4_se_ipl_08");
				STREAMING::REQUEST_IPL("h4_se_ipl_08_lod");
				STREAMING::REQUEST_IPL("h4_se_ipl_08_slod");
				STREAMING::REQUEST_IPL("h4_se_ipl_09");
				STREAMING::REQUEST_IPL("h4_se_ipl_09_lod");
				STREAMING::REQUEST_IPL("h4_se_ipl_09_slod");
				STREAMING::REQUEST_IPL("h4_sw_ipl_00");
				STREAMING::REQUEST_IPL("h4_sw_ipl_00_lod");
				STREAMING::REQUEST_IPL("h4_sw_ipl_00_slod");
				STREAMING::REQUEST_IPL("h4_sw_ipl_01");
				STREAMING::REQUEST_IPL("h4_sw_ipl_01_lod");
				STREAMING::REQUEST_IPL("h4_sw_ipl_01_slod");
				STREAMING::REQUEST_IPL("h4_sw_ipl_02");
				STREAMING::REQUEST_IPL("h4_sw_ipl_02_lod");
				STREAMING::REQUEST_IPL("h4_sw_ipl_02_slod");
				STREAMING::REQUEST_IPL("h4_sw_ipl_03");
				STREAMING::REQUEST_IPL("h4_sw_ipl_03_lod");
				STREAMING::REQUEST_IPL("h4_sw_ipl_03_slod");
				STREAMING::REQUEST_IPL("h4_sw_ipl_04");
				STREAMING::REQUEST_IPL("h4_sw_ipl_04_lod");
				STREAMING::REQUEST_IPL("h4_sw_ipl_04_slod");
				STREAMING::REQUEST_IPL("h4_sw_ipl_05");
				STREAMING::REQUEST_IPL("h4_sw_ipl_05_lod");
				STREAMING::REQUEST_IPL("h4_sw_ipl_05_slod");
				STREAMING::REQUEST_IPL("h4_sw_ipl_06");
				STREAMING::REQUEST_IPL("h4_sw_ipl_06_lod");
				STREAMING::REQUEST_IPL("h4_sw_ipl_06_slod");
				STREAMING::REQUEST_IPL("h4_sw_ipl_07");
				STREAMING::REQUEST_IPL("h4_sw_ipl_07_lod");
				STREAMING::REQUEST_IPL("h4_sw_ipl_07_slod");
				STREAMING::REQUEST_IPL("h4_sw_ipl_08");
				STREAMING::REQUEST_IPL("h4_sw_ipl_08_lod");
				STREAMING::REQUEST_IPL("h4_sw_ipl_08_slod");
				STREAMING::REQUEST_IPL("h4_sw_ipl_09");
				STREAMING::REQUEST_IPL("h4_sw_ipl_09_lod");
				STREAMING::REQUEST_IPL("h4_sw_ipl_09_slod");
				STREAMING::REQUEST_IPL("h4_underwater_gate_closed");
				STREAMING::REQUEST_IPL("h4_islandx_placement_01");
				STREAMING::REQUEST_IPL("h4_islandx_placement_02");
				STREAMING::REQUEST_IPL("h4_islandx_placement_03");
				STREAMING::REQUEST_IPL("h4_islandx_placement_04");
				STREAMING::REQUEST_IPL("h4_islandx_placement_05");
				STREAMING::REQUEST_IPL("h4_islandx_placement_06");
				STREAMING::REQUEST_IPL("h4_islandx_placement_07");
				STREAMING::REQUEST_IPL("h4_islandx_placement_08");
				STREAMING::REQUEST_IPL("h4_islandx_placement_09");
				STREAMING::REQUEST_IPL("h4_islandx_placement_10");
				STREAMING::REQUEST_IPL("h4_mph4_island_placement");
				Vector3 Coords;
				Coords.x = 4892.064f; Coords.y = -4923.567; Coords.z = 3.500f;
				MenuFunctions::ChangeCoords(Coords);
			}
			if (gui.Option("��������", NULL))
			{
				STREAMING::REQUEST_IPL("smboat");
				Vector3 Coords;
				Coords.x = -2045.8f; Coords.y = -1031.2f; Coords.z = 11.9f;
				PED::SET_PED_COORDS_KEEP_VEHICLE(PLAYER::PLAYER_PED_ID(), Coords.x, Coords.y, Coords.z);
			}
			if (gui.Option("�����߰칫��", NULL))
			{
				STREAMING::REQUEST_IPL("facelobby");
				STREAMING::REQUEST_IPL("facelobbyfake");
				Vector3 Coords;
				Coords.x = -1047.9f; Coords.y = -233.0f; Coords.z = 39.0f;
				PED::SET_PED_COORDS_KEEP_VEHICLE(PLAYER::PLAYER_PED_ID(), Coords.x, Coords.y, Coords.z);
			}
			if (gui.Option("��������", NULL))
			{
				STREAMING::REQUEST_IPL("cargoship");
				Vector3 Coords;
				Coords.x = -162.8918f; Coords.y = -2365.769f; Coords.z = 9.3192f;
				PED::SET_PED_COORDS_KEEP_VEHICLE(PLAYER::PLAYER_PED_ID(), Coords.x, Coords.y, Coords.z);
			}
			if (gui.Option("��������", NULL))
			{
				STREAMING::REMOVE_IPL("farm_burnt");
				STREAMING::REMOVE_IPL("farm_burnt_props");
				STREAMING::REQUEST_IPL("farm");
				STREAMING::REQUEST_IPL("farm_props");
				STREAMING::REQUEST_IPL("farmint");
				STREAMING::REQUEST_IPL("farmint_cap");
				Vector3 Coords;
				Coords.x = 2441.2f; Coords.y = 4968.5f; Coords.z = 51.7f;
				PED::SET_PED_COORDS_KEEP_VEHICLE(PLAYER::PLAYER_PED_ID(), Coords.x, Coords.y, Coords.z);
			}
			if (gui.Option("����ҽԺ", NULL))
			{
				STREAMING::REQUEST_IPL("RC12B_HospitalInterior");
				STREAMING::REQUEST_IPL("RC12B_Destroyed");
				Vector3 Coords;
				Coords.x = 356.8f; Coords.y = -590.1f; Coords.z = 43.3f;
				PED::SET_PED_COORDS_KEEP_VEHICLE(PLAYER::PLAYER_PED_ID(), Coords.x, Coords.y, Coords.z);
			}
			if (gui.Option("�鱦��", NULL))
			{
				STREAMING::REQUEST_IPL("jewel2fake");
				STREAMING::REQUEST_IPL("post_hiest_unload");
				STREAMING::REQUEST_IPL("bh1_16_refurb");
				Vector3 Coords;
				Coords.x = -630.4f; Coords.y = -236.7f; Coords.z = 40.0f;
				PED::SET_PED_COORDS_KEEP_VEHICLE(PLAYER::PLAYER_PED_ID(), Coords.x, Coords.y, Coords.z);
			}
			if (gui.Option("ͣʬ��", NULL))
			{
				STREAMING::REQUEST_IPL("Coroner_Int_on");
				Vector3 Coords;
				Coords.x = 244.9f; Coords.y = -1374.7f; Coords.z = 39.5f;
				PED::SET_PED_COORDS_KEEP_VEHICLE(PLAYER::PLAYER_PED_ID(), Coords.x, Coords.y, Coords.z);
			}
		}
		break;
		case vehicle:
		{
			gui.Title("�ؾ�ѡ��");
			gui.SubMenu("�����ؾ�", NULL, spawn);
			gui.SubMenu("ģ���ؾ�", NULL, modveh);
			gui.SubMenu("�ĳ���", NULL, GAICHEWANG_);
			gui.SubMenu("�ؾ߼���", NULL, flip);
			gui.SubMenu("����״̬", NULL, chemen);
			gui.SubMenu("�Զ���ʻ", NULL, zidongjiashi);
			if (gui.Option("������ǰ�ؾ�", NULL))
			{
				Ped playerPed = PLAYER::PLAYER_PED_ID();
				Vehicle vehicle = PED::GET_VEHICLE_PED_IS_IN(playerPed, FALSE);
				VEHICLE::SET_VEHICLE_MOD_KIT(vehicle, 0);
				for (int i = 0; i < 50; i++)
				{
					VEHICLE::SET_VEHICLE_MOD(vehicle, i, VEHICLE::GET_NUM_VEHICLE_MODS(vehicle, i) - 1, false);
				}
			}
			if (gui.Option("ɾ����ǰ�ؾ�", NULL))
			{
				Ped playerPed = PLAYER::PLAYER_PED_ID();
				Vehicle pedVeh = PED::GET_VEHICLE_PED_IS_IN(playerPed, FALSE);
				ENTITY::SET_ENTITY_AS_MISSION_ENTITY(pedVeh, true, true);
				VEHICLE::DELETE_VEHICLE(&pedVeh);
			}
			if (gui.Option("�����ؾ�", "����������ǰ�������ؾ�"))
			{
				Vehicle veh = PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID()));
				//�޸�
				VEHICLE::SET_VEHICLE_FIXED(veh);
				VEHICLE::SET_VEHICLE_DEFORMATION_FIXED(veh);
				//���
				VEHICLE::SET_VEHICLE_DIRT_LEVEL(veh, 0);
			}
			if (gui.Option("Ū���ؾ�", NULL))
			{
				Vehicle veh = PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID()));
				VEHICLE::SET_VEHICLE_DIRT_LEVEL(veh, 15.0f);
			}
			gui.Bool("�޵��ؾ�", NULL, g_Vehicle.vehiclegodmode);
			gui.Bool("ˮ�ϼ�ʻ", NULL, g_Vehicle.driveonwater);
			if (gui.Bool("������̥", NULL, g_Vehicle.bulletProofTyres))
			{
				VEHICLE::SET_VEHICLE_WHEELS_CAN_BREAK(PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID()), false), 1);
			}
			gui.Bool("���ȼ���", NULL, g_Vehicle.vehicleboost);
			gui.Bool("��ȫ��", NULL, g_Vehicle.anquandai);
			gui.Bool("�����ؾ�", NULL, g_Vehicle.invisiblecar);
			gui.Bool("�����ؾ�", NULL, g_Vehicle.flycar);
			gui.Bool("�����ؾ�v2", NULL, g_Vehicle.flycarv2);
			gui.Bool("�ʺ糵��", NULL, g_Vehicle.rainbowcar);
			gui.Bool("�ʺ��޺��", NULL, g_Vehicle.rainbowneno);
			gui.Bool("�ʺ���̥��", NULL, g_Vehicle.rainbowsmoke);
			gui.Bool("����һֱ����", NULL, g_Vehicle.enginealwayson);
			gui.Bool("ѭ���޳�", NULL, g_Vehicle.fixcarloop);
		}
		break;
		case spawn:
		{
			gui.Title("�����ؾ�");
			gui.SubMenu("��������", NULL, spanwsetting);
			gui.SubMenu("�����ܳ�", NULL, super);
			gui.SubMenu("�ܳ�", NULL, Sports);
			gui.SubMenu("�����ܳ�", NULL, SportsClassics);
			gui.SubMenu("�γ�", NULL, Sedans);
			gui.SubMenu("SUV", NULL, suvs);
			gui.SubMenu("ԽҰ��", NULL, offroad);
			gui.SubMenu("���⳵", NULL, Muscle);
			gui.SubMenu("�����ó�", NULL, Military);
			gui.SubMenu("���г�", NULL, bike);
			gui.SubMenu("�ɻ�", NULL, plane);
			gui.SubMenu("ֱ����", NULL, helicopter);
			gui.SubMenu("Ħ�г�", NULL, motorbike);
			gui.SubMenu("��ֻ", NULL, boat);
			gui.SubMenu("������", NULL, service);
			gui.SubMenu("�ϳ�", NULL, Trailer);
			gui.SubMenu("��", NULL, Trains);
			gui.SubMenu("����", NULL, Vans);
			gui.SubMenu("������ҵ", NULL, Utility);
			gui.SubMenu("��ҵ����", NULL, Commercial);
			gui.SubMenu("С�ͳ���", NULL, Compacts);
			gui.SubMenu("���ܳ�", NULL, Coupes);
			gui.SubMenu("���ó���", NULL, Emergency);
			gui.SubMenu("��ҵ�ó�", NULL, Industrial);
			gui.SubMenu("���ѻ�DLC", NULL, Tuner);
			gui.SubMenu("����ĳ�DLC", NULL, CasinoHeistDLC);
			gui.SubMenu("ĩ�պ���DLC", NULL, DoomsdayDLC);
			gui.SubMenu("������֮սDLC", NULL, ArenaWarDLC);
			gui.SubMenu("��˽����DLC", NULL, SmugglersDLC);
			gui.SubMenu("�����ҵDLC", NULL, GunrunningDLC);
			gui.SubMenu("��ʥ������˹����ϵ����DLC", NULL, SportSeries);
		}
		break;
		case spanwsetting:
		{
			gui.Title("��������");
			gui.Bool("���������ؾ�", NULL, g_Vehicle.setcarmax);
			gui.Bool("�����޵��ؾ�", NULL, g_Vehicle.setvehgodmode);
			gui.Bool("ɾ����һ���ؾ�", NULL, g_Vehicle.deletelastcar);
			gui.Bool("��������ؾ���", NULL, g_Vehicle.setpedintocar);
		}
		break;
		case Tuner:
		{
			gui.Title("���ѻ�");
			for (auto car : tunersDLC)
			{
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case Sports:
		{
			gui.Title("�ܳ�");
			for (auto car : sports) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case SportsClassics:
		{
			gui.Title("�����ܳ�");
			for (auto car : sportsClassics) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case Trailer:
		{
			gui.Title("�ϳ�");
			for (auto car : trailer) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case Trains:
		{
			gui.Title("��");
			for (auto car : trains) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case Vans:
		{
			gui.Title("����");
			for (auto car : vans) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case Utility:
		{
			gui.Title("������ҵ");
			for (auto car : utility) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case Coupes:
		{
			gui.Title("���ܳ�");
			for (auto car : coupes) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case Emergency:
		{
			gui.Title("���ó���");
			for (auto car : emergency) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case Industrial:
		{
			gui.Title("��ҵ�ó�");
			for (auto car : industrial) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case CasinoHeistDLC:
		{
			gui.Title("����ĳ�");
			for (auto car : casinoHeistDLC) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
			for (auto car1 : diamondDLC) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car1), NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car1));
			}
		}
		break;
		case DoomsdayDLC:
		{
			gui.Title("ĩ�պ���");
			for (auto car : doomsdayDLC) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case ArenaWarDLC:
		{
			gui.Title("������֮ս");
			for (auto car : arenaWarDLC) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL))MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case SmugglersDLC:
		{
			gui.Title("��˽����");
			for (auto car : smugglersDLC) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL))MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case GunrunningDLC:
		{
			gui.Title("�����ҵ");
			for (auto car : gunrunningDLC) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case SportSeries:
		{
			gui.Title("��ʥ������˹����ϵ����");
			for (auto car : sportSeries) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case Muscle:
		{
			gui.Title("���⳵");
			for (auto car : muscle) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case Military:
		{
			gui.Title("�����ó�");
			for (auto car : military) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case super:
		{
			gui.Title("�����ܳ�");
			for (auto car : Super) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case suvs:
		{
			gui.Title("SUV");
			for (auto car : sUVs) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case Sedans:
		{
			gui.Title("�γ�");
			for (auto car : sedans) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case offroad:
		{
			gui.Title("ԽҰ��");
			for (auto car : offRoad) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case bike:
		{
			gui.Title("���г�");
			for (auto car : cycles) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case helicopter:
		{
			gui.Title("ֱ����");
			for (auto car : helicopters) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL))MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case plane:
		{
			gui.Title("�ɻ�");
			for (auto car : planes) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case motorbike:
		{
			gui.Title("Ħ�г�");
			for (auto car : motorcycles) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case boat:
		{
			gui.Title("��");
			for (auto car : boats) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case service:
		{
			gui.Title("������");
			for (auto car : services) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
				;
			}
		}
		break;
		case Commercial:
		{
			gui.Title("��ҵ����");
			for (auto car : commercial) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case Compacts:
		{
			gui.Title("С�ͳ���");
			for (auto car : compacts) {
				if (gui.Option(HUD::_GET_LABEL_TEXT(car),NULL)) MenuFunctions::spawn_vehicle(MISC::GET_HASH_KEY(car));
			}
		}
		break;
		case flip:
		{
			gui.Title("�ؾ߼���");
			if (gui.Option("��ǰ����", NULL)) {
				MenuFunctions::requestControlOfEnt(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false));
				ENTITY::APPLY_FORCE_TO_ENTITY(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false), true, 0, 0, 6.0f, 0, -2.0f, 0, true, true, true, true, false, true);
			}
			if (gui.Option("˫����ǰ����", NULL)) {
				MenuFunctions::requestControlOfEnt(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false));
				ENTITY::APPLY_FORCE_TO_ENTITY(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false), true, 0, 0, 12.0f, 0, -4.0f, 0, true, true, true, true, false, true);
			}
			if (gui.Option("��߷���", NULL)) {
				MenuFunctions::requestControlOfEnt(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false));
				ENTITY::APPLY_FORCE_TO_ENTITY(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false), true, 0, 0, 6.0f, 5.0f, 2.0f, 0, true, true, true, true, false, true);
			}
			if (gui.Option("��󷭹�", NULL)) {
				MenuFunctions::requestControlOfEnt(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false));
				ENTITY::APPLY_FORCE_TO_ENTITY(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false), true, 0, 0, 6.0f, 0, 2.0f, 0, true, true, true, true, false, true);
			}
			if (gui.Option("˫����󷭹�", NULL)) {
				MenuFunctions::requestControlOfEnt(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false));
				ENTITY::APPLY_FORCE_TO_ENTITY(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false), true, 0, 0, 12.0f, 0, 4.0f, 0, true, true, true, true, false, true);
			}
			if (gui.Option("����1", NULL)) {
				MenuFunctions::requestControlOfEnt(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false));
				ENTITY::APPLY_FORCE_TO_ENTITY(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false), true, 0, 0, 5.0f, 2.0f, 0, 0, true, true, true, true, false, true);
			}
			if (gui.Option("����2", NULL)) {
				MenuFunctions::requestControlOfEnt(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false));
				ENTITY::APPLY_FORCE_TO_ENTITY(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false), true, 0, 0, 5.0f, -2.0f, 0, 0, true, true, true, true, false, true);
			}
			if (gui.Option("С����", NULL)) {
				MenuFunctions::requestControlOfEnt(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false));
				ENTITY::APPLY_FORCE_TO_ENTITY(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false), true, 0, 0, 7.0f, 0, 0, 0, true, true, true, true, false, true);
			}
			if (gui.Option("���", NULL)) {
				MenuFunctions::requestControlOfEnt(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false));
				ENTITY::APPLY_FORCE_TO_ENTITY(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false), true, 0, 0, 40.0f, 0, 0, 0, true, true, true, true, false, true);
			}
			if (gui.Option("����", NULL)) {
				MenuFunctions::requestControlOfEnt(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false));
				ENTITY::APPLY_FORCE_TO_ENTITY(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false), true, 0, 0, -40.0f, 0, 0, 0, true, true, true, true, false, true);
			}
		}
		break;
		case chemen:
		{
			gui.Title("����״̬");
			if (gui.Option("�����г���", NULL))
			{
				if (PED::IS_PED_IN_ANY_VEHICLE(PLAYER::PLAYER_PED_ID(), false))
				{
					VEHICLE::SET_VEHICLE_DOOR_OPEN(PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID()), 0, true, false);
					VEHICLE::SET_VEHICLE_DOOR_OPEN(PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID()), 1, true, false);
					VEHICLE::SET_VEHICLE_DOOR_OPEN(PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID()), 2, true, false);
					VEHICLE::SET_VEHICLE_DOOR_OPEN(PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID()), 3, true, false);
					VEHICLE::SET_VEHICLE_DOOR_OPEN(PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID()), 4, true, false);
					VEHICLE::SET_VEHICLE_DOOR_OPEN(PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID()), 5, true, false);
					VEHICLE::SET_VEHICLE_DOOR_OPEN(PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID()), 6, true, false);
					VEHICLE::SET_VEHICLE_DOOR_OPEN(PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID()), 7, true, false);
					MenuFunctions::Notify("�����г��ųɹ�");
				}
				else { MenuFunctions::Notify("�򿪳���ʧ�ܣ�����ǰ�����ؾ���"); }
			}
			if (gui.Option("�ر����г���", NULL))
			{
				if (PED::IS_PED_IN_ANY_VEHICLE(PLAYER::PLAYER_PED_ID(), false))
				{
					VEHICLE::SET_VEHICLE_DOORS_SHUT(PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID()), true);
					MenuFunctions::Notify("�ر����г��ųɹ�");
				}
				else { MenuFunctions::Notify("�رճ��ţ�����ǰ�����ؾ���"); }
			}
			if (gui.Option("���г�������", NULL))
			{
				if (PED::IS_PED_IN_ANY_VEHICLE(PLAYER::PLAYER_PED_ID(), false))
				{
					Vehicle veh = PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID());
					VEHICLE::SET_VEHICLE_DOORS_LOCKED(veh, 2);
					VEHICLE::SET_VEHICLE_DOORS_LOCKED(veh, 3);
					VEHICLE::SET_VEHICLE_DOORS_LOCKED(veh, 4);
					MenuFunctions::Notify("���������ɹ�");
				}
				else { MenuFunctions::Notify("��������ʧ�ܣ�����ǰ�����ؾ���"); }
			}
			if (gui.Option("���г��Ž���", NULL))
			{
				if (PED::IS_PED_IN_ANY_VEHICLE(PLAYER::PLAYER_PED_ID(), false))
				{
					VEHICLE::SET_VEHICLE_DOORS_LOCKED(PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID()), 1);
					MenuFunctions::Notify("���Ž����ɹ�");
				}
				else { MenuFunctions::Notify("���Ž���ʧ�ܣ�����ǰ�����ؾ���"); }
			}
		}
		break;
		case zidongjiashi:
		{
			gui.Title("�Զ���ʻ");
			gui.Float("��ʻ�ٶ�", NULL, g_Vehicle.aispeed, 10, 100, 10.0f);
			gui.stringvector("��ʻ���", NULL, u_drivetype, aispeed1);
			if (gui.Option("��ʼ�Զ���ʻ����ǵ�", "����ѡ���ʻ����ٿ����Զ���ʻ"))
			{

				Vector3 coords = HUD::GET_BLIP_COORDS(HUD::GET_FIRST_BLIP_INFO_ID(8));
				if (coords.x == 0 && coords.y == 0)
				{
					MenuFunctions::Notify((char*)"��û�б�ǵ����㣡");
					return;
				}
				if (!PED::IS_PED_IN_ANY_VEHICLE(PLAYER::PLAYER_PED_ID(), 0))
				{
					MenuFunctions::Notify((char*)"����Ҫһ���ؾߣ�");
					return;
				}
				Vehicle veh = PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID());
				int drivemode;
				if (aispeed1 == 0)
				{
					drivemode = 539647;
				}
				if (aispeed1 == 1)
				{
					drivemode = 525088;
				}
				if (aispeed1 == 2)
				{
					drivemode = 16777216;
				}
				if (aispeed1 == 3)
				{
					drivemode = 537657663;
				}
				BRAIN::TASK_VEHICLE_DRIVE_TO_COORD(PLAYER::PLAYER_PED_ID(), veh, coords.x, coords.y, NULL, g_Vehicle.aispeed, 1, ENTITY::GET_ENTITY_MODEL(veh), drivemode, 6, -1);
			}
			if (gui.Option("�ر��Զ���ʻ", NULL)) { BRAIN::CLEAR_PED_TASKS(PLAYER::PLAYER_PED_ID()); }
		}
		break;
		case Wheels:
		{
			gui.Title("����ѡ��");
			gui.SubMenu("Ƥ��", NULL, Pika); //done
			gui.SubMenu("SUV", NULL, WheelsSUV); //done
			gui.SubMenu("�����˶�", NULL, SportWheels); //done
			gui.SubMenu("ԽҰ��", NULL, OffroadWheels); //done
			gui.SubMenu("�ߵ���", NULL, HighEnd); //done
			gui.SubMenu("ſ��������", NULL, LowriderWheels); //done
			gui.SubMenu("����", NULL, MuscleWheels); //done
		}
		break;
		case WheelsSUV:
		{
			gui.Title("SUV");
			if (gui.Option("Benefactor", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 3);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 1, 0);
			}
			if (gui.Option("Cosmo", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 3);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 2, 0);
			}
			if (gui.Option("Royal Six", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 3);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 4, 0);
			}
			if (gui.Option("Fagorme", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 3);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 5, 0);
			}
			if (gui.Option("Deluxe", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 3);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 6, 0);
			}
			if (gui.Option("Iced Out", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 3);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 7, 0);
			}
			if (gui.Option("Cognoscenti", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 3);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 8, 0);
			}
			if (gui.Option("Supernova", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 3);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 10, 0);
			}
			if (gui.Option("Obey RS", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 3);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 11, 0);
			}
			if (gui.Option("LozSpeed Baller", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 3);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 12, 0);
			}
			if (gui.Option("Extravaganzo", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 3);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 13, 0);
			}
			if (gui.Option("Split Six", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 3);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 14, 0);
			}
			if (gui.Option("Empowered", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 3);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 15, 0);
			}
			if (gui.Option("Sunrise", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 3);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 16, 0);
			}
			if (gui.Option("Dash VIP", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 3);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 17, 0);
			}
		}
		break;
		case OffroadWheels:
		{
			gui.Title("ԽҰ��");
			if (gui.Option("Raider", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 4);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 0, 0);
			}
			if (gui.Option("Mudslinger", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 4);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 1, 0);
			}
			if (gui.Option("Nevis", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 4);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 2, 0);
			}
			if (gui.Option("Cairngorm", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 4);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 3, 0);
			}
			if (gui.Option("Amazon", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 4);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 4, 0);
			}
			if (gui.Option("Challenger", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 4);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 5, 0);
			}
			if (gui.Option("Dune Basher", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 4);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 6, 0);
			}
			if (gui.Option("Five Star", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 4);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 7, 0);
			}
			if (gui.Option("Rock Crawler", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 4);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 8, 0);
			}
			if (gui.Option("Mil Spec Steelie", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 4);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 9, 0);
			}
		}
		break;
		case SportWheels:
		{
			gui.Title("�����˶�");
			if (gui.Option("Inferno", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 0);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 0, 0);
			}
			if (gui.Option("Deep Five", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 0);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 1, 0);
			}
			if (gui.Option("LozSpeed Mk. V", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 0);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 2, 0);
			}
			if (gui.Option("Diamond Cut", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 0);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 3, 0);
			}
			if (gui.Option("Feroci RR", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 0);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 5, 0);
			}
			if (gui.Option("FiftyNine", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 0);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 6, 0);
			}
			if (gui.Option("Synthetic Z", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 0);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 8, 0);
			}
			if (gui.Option("Organic Type 0", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 0);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 9, 0);
			}
			if (gui.Option("GT One", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 0);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 11, 0);
			}
			if (gui.Option("S Racer", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 0);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 15, 0);
			}
			if (gui.Option("Venum", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 0);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 16, 0);
			}
			if (gui.Option("Cosmo", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 0);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 17, 0);
			}
			if (gui.Option("Dash VIP", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 0);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 18, 0);
			}
			if (gui.Option("Ice Kid", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 0);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 19, 0);
			}
			if (gui.Option("Split Six", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 0);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 24, 0);
			}
		}
		break;
		case MuscleWheels:
		{
			gui.Title("����");
			if (gui.Option("Classic Five", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 1);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 0, 0);
			}
			if (gui.Option("Dukes", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 1);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 1, 0);
			}
			if (gui.Option("Muscle Freak", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 1);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 2, 0);
			}
			if (gui.Option("Kracka", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 1);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 3, 0);
			}
			if (gui.Option("Azreal", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 1);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 4, 0);
			}
			if (gui.Option("Mecha", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 1);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 5, 0);
			}
			if (gui.Option("Black Top", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 1);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 6, 0);
			}
			if (gui.Option("Drag SPL", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 1);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 7, 0);
			}
			if (gui.Option("Revolver", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 1);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 8, 0);
			}
			if (gui.Option("Classic Rod", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 1);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 9, 0);
			}
			if (gui.Option("Spooner", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 1);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 11, 0);
			}
			if (gui.Option("Five Star", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 1);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 12, 0);
			}
			if (gui.Option("Old School", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 1);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 13, 0);
			}
			if (gui.Option("El Jefe", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 1);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 14, 0);
			}
			if (gui.Option("Mercenary", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 1);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 17, 0);

			}
		}
		break;
		case LowriderWheels:
		{
			gui.Title("ſ��������");
			if (gui.Option("Flare", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 2);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 0, 0);
			}
			if (gui.Option("Wired", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 2);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 1, 0);
			}
			if (gui.Option("Triple Golds", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 2);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 2, 0);
			}
			if (gui.Option("Big Worm", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 2);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 3, 0);
			}
			if (gui.Option("Seven Fives", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 2);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 4, 0);
			}
			if (gui.Option("Split Six", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 2);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 5, 0);
			}
			if (gui.Option("Fresh Mesh", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 2);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 6, 0);
			}
			if (gui.Option("Lead Sled", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 2);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 7, 0);
			}
			if (gui.Option("Turbine", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 2);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 8, 0);
			}
			if (gui.Option("Super Fin", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 2);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 9, 0);
			}
			if (gui.Option("Classic Rod", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 2);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 10, 0);
			}
			if (gui.Option("Dollar", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 2);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 11, 0);
			}
			if (gui.Option("Dukes", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 2);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 12, 0);
			}
			if (gui.Option("Low Five", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 2);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 13, 0);
			}
			if (gui.Option("Gooch", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 2);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 14, 0);

			}
		}
		break;
		case HighEnd:
		{
			gui.Title("�ߵ���");
			if (gui.Option("Shadow", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 7);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 0, 0);
			}
			if (gui.Option("Hypher", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 7);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 1, 0);
			}
			if (gui.Option("Blade", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 7);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 2, 0);
			}
			if (gui.Option("Diamond", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 7);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 3, 0);
			}
			if (gui.Option("Supa Gee", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 7);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 4, 0);
			}
			if (gui.Option("Chromatic Z", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 7);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 5, 0);
			}
			if (gui.Option("Obey RS", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 7);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 7, 0);
			}
			if (gui.Option("GT Chrome", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 7);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 8, 0);
			}
			if (gui.Option("Cheetah RR", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 7);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 9, 0);
			}
			if (gui.Option("Solar", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 7);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 10, 0);
			}
			if (gui.Option("Split Ten", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 7);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 11, 0);
			}
			if (gui.Option("Dash VIP", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 7);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 12, 0);
			}
			if (gui.Option("LozSpeed Ten", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 7);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 13, 0);
			}
			if (gui.Option("Carbon Shadow", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 7);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 15, 0);
			}
			if (gui.Option("Carbon S Racer", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 7);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 19, 0);

			}
		}
		break;
		case Colours:
		{
			gui.Title("��ɫѡ��");
			gui.Int("��ɫ��", NULL, g_Vehicle.Prim_, 0, 150, 5); { int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
			VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
			VEHICLE::SET_VEHICLE_COLOURS(VehID, g_Vehicle.Prim_, g_Vehicle.Sec_);
			}
			gui.Int("��ɫ��", NULL, g_Vehicle.Sec_, 0, 150, 5); { int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
			VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
			VEHICLE::SET_VEHICLE_COLOURS(VehID, g_Vehicle.Prim_, g_Vehicle.Sec_);
			}
		}
		break;
		case Neons:
		{
			gui.Title("����ѡ��");
			if (gui.Option("���������", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				MenuFunctions::ToggleXenon(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0));
			}
			if (gui.Option("�������еĳ���", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::_IS_VEHICLE_NEON_LIGHT_ENABLED(VehID, 1);
				VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 0, 1);
				VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 1, 1);
				VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 2, 1);
				VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 3, 1);
				VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 4, 1);
				VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 5, 1);
				VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 6, 1);
				VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 7, 1);
			}
			if (gui.Option("��ɫ", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::_IS_VEHICLE_NEON_LIGHT_ENABLED(VehID, 1);
				VEHICLE::_SET_VEHICLE_NEON_LIGHTS_COLOUR(VehID, 255, 0, 0);
			}
			if (gui.Option("��ɫ", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::_IS_VEHICLE_NEON_LIGHT_ENABLED(VehID, 8);
				VEHICLE::_SET_VEHICLE_NEON_LIGHTS_COLOUR(VehID, 0, 255, 0);
			}
			if (gui.Option("��ɫ", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::_IS_VEHICLE_NEON_LIGHT_ENABLED(VehID, 8);
				VEHICLE::_SET_VEHICLE_NEON_LIGHTS_COLOUR(VehID, 0, 0, 255);
			}
			if (gui.Option("�ۺ�ɫ", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::_IS_VEHICLE_NEON_LIGHT_ENABLED(VehID, 8);
				VEHICLE::_SET_VEHICLE_NEON_LIGHTS_COLOUR(VehID, 226, 35, 157);
			}
			if (gui.Option("��ɫ", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::_IS_VEHICLE_NEON_LIGHT_ENABLED(VehID, 8);
				VEHICLE::_SET_VEHICLE_NEON_LIGHTS_COLOUR(VehID, 247, 244, 0);
			}
			if (gui.Option("��ɫ", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::_IS_VEHICLE_NEON_LIGHT_ENABLED(VehID, 8);
				VEHICLE::_SET_VEHICLE_NEON_LIGHTS_COLOUR(VehID, 247, 91, 0);
			}
			if (gui.Option("ǳ��ɫ", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::_IS_VEHICLE_NEON_LIGHT_ENABLED(VehID, 8);
				VEHICLE::_SET_VEHICLE_NEON_LIGHTS_COLOUR(VehID, 40, 255, 255);
			}
			if (gui.Option("��ɫ", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::_IS_VEHICLE_NEON_LIGHT_ENABLED(VehID, 8);
				VEHICLE::_SET_VEHICLE_NEON_LIGHTS_COLOUR(VehID, 255, 255, 255);
			}
			if (gui.Option("���ɫ", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::_IS_VEHICLE_NEON_LIGHT_ENABLED(VehID, 8);
				VEHICLE::_SET_VEHICLE_NEON_LIGHTS_COLOUR(VehID, 102, 0, 35);
			}
			if (gui.Option("��ɫ", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::_IS_VEHICLE_NEON_LIGHT_ENABLED(VehID, 8);
				VEHICLE::_SET_VEHICLE_NEON_LIGHTS_COLOUR(VehID, 53, 0, 83);
			}
			if (gui.Option("����ɫ", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::_IS_VEHICLE_NEON_LIGHT_ENABLED(VehID, 8);
				VEHICLE::_SET_VEHICLE_NEON_LIGHTS_COLOUR(VehID, 0, 118, 0);
			}
			if (gui.Option("���ɫ", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::_IS_VEHICLE_NEON_LIGHT_ENABLED(VehID, 8);
				VEHICLE::_SET_VEHICLE_NEON_LIGHTS_COLOUR(VehID, 161, 0, 0);
			}
		}
		break;
		case Pika:
		{
			gui.Title("Ƥ��");
			if (gui.Option("Cosmo", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 5);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 0, 0);
			}
			if (gui.Option("Super Mesh", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 5);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 1, 0);
			}
			if (gui.Option("Driftmeister", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 5);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 4, 0);
			}
			if (gui.Option("El Quatro", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 5);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 6, 0);
			}
			if (gui.Option("Dubbed", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 5);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 7, 0);
			}
			if (gui.Option("Slideways", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 5);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 9, 0);
			}
			if (gui.Option("Countersteer", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 5);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 12, 0);
			}
			if (gui.Option("Endo v.2 Dish", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 5);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 14, 0);
			}
			if (gui.Option("Choku-Dori", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 5);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 16, 0);
			}
			if (gui.Option("Chicane", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 5);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 17, 0);
			}
			if (gui.Option("Saisoku", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 5);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 18, 0);
			}
			if (gui.Option("Dished Eight", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 5);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 19, 0);
			}
			if (gui.Option("Battle VIII", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 5);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 22, 0);
			}
			if (gui.Option("Rally Master", NULL)) {
				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, 0);
				VEHICLE::SET_VEHICLE_WHEEL_TYPE(VehID, 5);
				VEHICLE::SET_VEHICLE_MOD(VehID, 23, 23, 0);
			}
		}
		break;
		case GAICHEWANG_:
		{
			gui.Title("��˹͡�ĳ���");
			gui.SubMenu("����ѡ��", NULL, Wheels);
			gui.SubMenu("����ѡ��", NULL, Neons);
			gui.SubMenu("��ɫѡ��", NULL, Colours);
			gui.Int("����", NULL, g_Vehicle.Armor_, 0, 6, 1);
			{

				int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);//this is for armor
				VEHICLE::SET_VEHICLE_MOD_KIT(VehID, g_Vehicle.Armor_);
				VEHICLE::SET_VEHICLE_MOD(VehID, 16, g_Vehicle.Armor_, 0);
			}
			gui.Int("ɲ��", NULL, g_Vehicle.Brakes_, 0, 4, 1); { int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
			VEHICLE::SET_VEHICLE_MOD_KIT(VehID, g_Vehicle.Brakes_);
			VEHICLE::SET_VEHICLE_MOD(VehID, 12, g_Vehicle.Brakes_, 0);
			}
			gui.Int("����", NULL, g_Vehicle.Transmission_, 0, 4, 1); { int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
			VEHICLE::SET_VEHICLE_MOD_KIT(VehID, g_Vehicle.Brakes_);
			VEHICLE::SET_VEHICLE_MOD(VehID, 12, g_Vehicle.Brakes_, 0);
			}
			if (gui.Option("������ѹ", NULL)) {
				VEHICLE::SET_VEHICLE_MOD_KIT(g_Vehicle.VehID, 0);
				VEHICLE::TOGGLE_VEHICLE_MOD(g_Vehicle.VehID, 18, 0);

			}
			gui.Int("���ո�", NULL, g_Vehicle.Bumpers_, 0, 3, 1); { int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
			VEHICLE::SET_VEHICLE_MOD_KIT(VehID, g_Vehicle.Bumpers_);
			VEHICLE::SET_VEHICLE_MOD(VehID, 2, g_Vehicle.Bumpers_, 0);
			}
			gui.Int("������", NULL, g_Vehicle.Hoods_, 0, 5, 1); { int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
			VEHICLE::SET_VEHICLE_MOD_KIT(VehID, g_Vehicle.Hoods_);
			VEHICLE::SET_VEHICLE_MOD(VehID, 7, g_Vehicle.Hoods_, 0);
			}
			gui.Int("����", NULL, g_Vehicle.Suspension_, 0, 5, 1); { int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
			VEHICLE::SET_VEHICLE_MOD_KIT(VehID, g_Vehicle.Suspension_);
			VEHICLE::SET_VEHICLE_MOD(VehID, 15, g_Vehicle.Suspension_, 0);
			}
			gui.Int("������", NULL, g_Vehicle.Spoilers_, 0, 5, 1); { int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
			VEHICLE::SET_VEHICLE_MOD_KIT(VehID, g_Vehicle.Spoilers_);
			VEHICLE::SET_VEHICLE_MOD(VehID, 0, g_Vehicle.Spoilers_, 0);
			}
			gui.Int("��ȹ", NULL, g_Vehicle.Skirts_, 0, 5, 1); { int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
			VEHICLE::SET_VEHICLE_MOD_KIT(VehID, g_Vehicle.Skirts_);
			VEHICLE::SET_VEHICLE_MOD(VehID, 3, g_Vehicle.Skirts_, 0);
			}
			gui.Int("������", NULL, g_Vehicle.Exhaust_, 0, 5, 1); { int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
			VEHICLE::SET_VEHICLE_MOD_KIT(VehID, g_Vehicle.Exhaust_);
			VEHICLE::SET_VEHICLE_MOD(VehID, 4, g_Vehicle.Exhaust_, 0);
			}
			gui.Int("������", NULL, g_Vehicle.Grill_, 0, 5, 1); { int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
			VEHICLE::SET_VEHICLE_MOD_KIT(VehID, g_Vehicle.Grill_);
			VEHICLE::SET_VEHICLE_MOD(VehID, 6, g_Vehicle.Grill_, 0);
			}
			gui.Int("β��", NULL, g_Vehicle.Interior_, 0, 5, 1); { int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
			VEHICLE::SET_VEHICLE_MOD_KIT(VehID, g_Vehicle.Interior_);
			VEHICLE::REMOVE_VEHICLE_MOD(VehID, g_Vehicle.Interior_);
			}
			gui.Int("����", NULL, g_Vehicle.Tint_, 0, 5, 1); { int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
			VEHICLE::SET_VEHICLE_MOD_KIT(VehID, g_Vehicle.Tint_);
			VEHICLE::SET_VEHICLE_WINDOW_TINT(VehID, g_Vehicle.Tint_);
			}
			gui.Int("����", NULL, g_Vehicle.horns, 0, 5, 1); { int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
			VEHICLE::SET_VEHICLE_MOD_KIT(VehID, g_Vehicle.horns);
			VEHICLE::SET_VEHICLE_MOD(VehID, 14, g_Vehicle.horns, 0);
			}
		}
		break;
		case weapon:
		{
			gui.Title("����ѡ��");
			gui.SubMenu("��Чǹ", NULL, trollgun);
			gui.SubMenu("ʵ��ǹ", NULL, objgun);
			gui.SubMenu("�ӵ��༭", NULL, zidanbianji);
			gui.SubMenu("�����̵�", NULL, wuqishangdian);
			gui.Bool("��ը�ӵ�", NULL, g_Weapon.explosiveammo);
			gui.Bool("�������", NULL, g_Weapon.rapidfire);
			gui.Bool("���޵�ҩ", NULL, g_Weapon.unlimitedammo);
			gui.Bool("һ����ɱ", NULL, g_Weapon.oneshoot);
			gui.Bool("����֮��", NULL, g_Weapon.deatheye);
		}
		break;
		case wuqishangdian:
		{
			gui.Title("�����̵�");
			if (gui.Option("������������", NULL))
			{
				for (auto hash : AllWeaponList) {
					WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), hash, 9999, 0);
				}
			}
			if (gui.Option("��������MK2����", NULL))
			{
				std::vector<Hash> pistolMk2{
					1329061674, 2396306288, 1140676955, 1709866683, 568543123, 2467084625
				};
				std::vector<Hash> smgMk2{
					190476639, 2076495324, 2681951826, 3842157419, 1038927834, 1303784126, 2774849419, 966612367
				};
				std::vector<Hash> assltRifleMk2{
					1675665560, 2640679034, 2076495324, 1108334355, 77277509, 3328927042, 2805810788, 1303784126, 1447477866, 3115408816
				};
				std::vector<Hash> carbineRifleMk2{
					1141059345, 2640679034, 2076495324, 1108334355, 77277509, 3328927042, 2205435306, 1303784126, 2335983627, 3663056191
				};
				std::vector<Hash> combatMgMk2{
					1475288264, 2640679034, 1108334355, 1060929921, 3328927042, 1303784126, 3051509595, 3607349581
				};
				std::vector<Hash> heavySniperMk2{
					2313935527, 2193687427, 3159677559, 3061846192, 776198721, 2890063729, 1764221345, 277524638, 1815270123
				};
				std::vector<Hash> WeaponHash{
					0xBFE256D4, 0x78A97CD0, 0xDBBD7280, 0x394F415C, 0xFAD1F1C9, 0xA914799
				};
				for (Hash hash : pistolMk2)
					WEAPON::GIVE_WEAPON_COMPONENT_TO_PED(PLAYER::PLAYER_PED_ID(), MISC::GET_HASH_KEY("WEAPON_PISTOL_MK2"), hash);

				for (Hash hash : smgMk2)
					WEAPON::GIVE_WEAPON_COMPONENT_TO_PED(PLAYER::PLAYER_PED_ID(), MISC::GET_HASH_KEY("WEAPON_SMG_MK2"), hash);

				for (Hash hash : assltRifleMk2)
					WEAPON::GIVE_WEAPON_COMPONENT_TO_PED(PLAYER::PLAYER_PED_ID(), MISC::GET_HASH_KEY("WEAPON_ASSAULTRIFLE_MK2"), hash);

				for (Hash hash : carbineRifleMk2)
					WEAPON::GIVE_WEAPON_COMPONENT_TO_PED(PLAYER::PLAYER_PED_ID(), MISC::GET_HASH_KEY("WEAPON_CARBINERIFLE_MK2"), hash);

				for (Hash hash : combatMgMk2)
					WEAPON::GIVE_WEAPON_COMPONENT_TO_PED(PLAYER::PLAYER_PED_ID(), MISC::GET_HASH_KEY("WEAPON_COMBATMG_MK2"), hash);

				for (Hash hash : heavySniperMk2)
					WEAPON::GIVE_WEAPON_COMPONENT_TO_PED(PLAYER::PLAYER_PED_ID(), MISC::GET_HASH_KEY("WEAPON_HEAVYSNIPER_MK2"), hash);

				for (Hash hash : WeaponHash)
					WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), hash, 9999, 0);
			}
			if (gui.Option("�Ƴ���������", NULL))
			{
				WEAPON::REMOVE_ALL_PED_WEAPONS(PLAYER::PLAYER_PED_ID(), true);
			}
			if (gui.Option("�Ƴ������������", NULL))
			{
				for (Hash w : AllWeaponList) {
					for (Hash hash : Weaponcomponents) {
						WEAPON::REMOVE_WEAPON_COMPONENT_FROM_PED(PLAYER::PLAYER_PED_ID(), w, hash);
					}
				}
			}
			if (gui.Option("���������������", NULL))
			{
				for (Hash w : AllWeaponList) {
					for (Hash hash : Weaponcomponents) {
						WEAPON::GIVE_WEAPON_COMPONENT_TO_PED(PLAYER::PLAYER_PED_ID(), w, hash);
					}
				}
			}
			if (gui.Option("�������������ӵ�", NULL))
			{
				for (Hash hash : AllWeaponList)
					WEAPON::SET_PED_AMMO(PLAYER::PLAYER_PED_ID(), hash, 9999, 0);
			}
		}
		break;
		case zidanbianji:
		{
			gui.Title("�ӵ��༭");
			gui.Bool("�ؾ�ǹ", "����ʹ�ù��࣬�������", g_Weapon.zaijuqiang);
			gui.Bool("̹��ǹ", NULL, g_Weapon.tankeqiang);
			gui.Bool("����ǹ", NULL, g_Weapon.teleportgun);
			gui.Bool("ɾ��ǹ", NULL, g_Weapon.deletegun);
			gui.Bool("��Ϯǹ", NULL, g_Weapon.airstrikegun);
			gui.Bool("���ǹ", NULL, g_Weapon.fireshoot);
			gui.Bool("��ˮǹ", NULL, g_Weapon.watershoot);
			gui.Bool("�̻�ǹ", NULL, g_Weapon.fireworkammo);
			gui.Bool("�ʺ�ǹ", NULL, g_Weapon.rainbowgun);
			gui.Bool("ȼ��ƿǹ", NULL, g_Weapon.firegun);
			gui.Bool("����ǹ", NULL, g_Weapon.smokegun);
			gui.Bool("����ǹ", NULL, g_Weapon.grvgun);
			gui.Bool("��ǹ", NULL, g_Weapon.rocketgun);
			gui.Bool("RPGǹ", NULL, g_Weapon.RPGgun);
			gui.Bool("͵��ǹ", NULL, g_Weapon.toucheqiang);
			gui.Bool("��Ǯ��ǹ", NULL, g_Weapon.jiaqiandaiqiang);
		}
		break;
		case objgun:
		{
			gui.Title("ʵ��ǹ");
			gui.Bool("����ǹ", NULL, g_Weapon.boxgun);
			gui.Bool("·��ǹ[��]", NULL, g_Weapon.Forstingun);
			gui.Bool("·��ǹ[��]", NULL, g_Weapon.Forstin2gun);
			gui.Bool("��װ��ǹ[��]", NULL, g_Weapon.containergun);
			gui.Bool("��װ��ǹ[��]", NULL, g_Weapon.containergun2);
			gui.Bool("��װ��ǹ[��]", NULL, g_Weapon.containergun3);
			gui.Bool("·��ǹ", NULL, g_Weapon.lampgun);
		}
		break;
		case trollgun:
		{
			gui.Title("��Чǹ");
			gui.Bool("С������", NULL, g_Weapon.kickgun);
			//gui.Bool("С�����", NULL, g_Weapon.xiaochouchuxian);
			gui.Bool("��Ʊ", NULL, g_Weapon.chaopiao);
			gui.Bool("����", NULL, g_Weapon.xingxing);
			gui.Bool("�̻�", NULL, g_Weapon.yanhua);
			gui.Bool("�������߽�", NULL, g_Weapon.waixingrenwajie);
			gui.Bool("�����˴���", NULL, g_Weapon.waixingrenchuansong);
			gui.Bool("������ײ", NULL, g_Weapon.kachechongzhuang);
			gui.Bool("�ѻ�Ӱ��", NULL, g_Weapon.jujiyingxiang);
			gui.Bool("ˮ���ɽ�", NULL, g_Weapon.shuihuafeijian);

		}
		break;
		case self:
		{
			gui.Title("����ѡ��");
			gui.SubMenu("��װѡ��", NULL, OutfitCreator);
			gui.SubMenu("����ѡ��", NULL, TEXIAO_);
			gui.SubMenu("����ѡ��", NULL, animation);
			gui.SubMenu("ͨ��ѡ��", NULL, tongjixuanx);
			gui.Bool("�޵�ģʽ", NULL, g_Local.GodMode);
			gui.Bool("��ɫ��ǽ", NULL, g_Local.freecambool);
			gui.Bool("����ˤ��", NULL, g_Local.noragdoll);
			gui.Bool("����ģʽ", NULL, g_Local.pengci);
			gui.Bool("������Ծ", NULL, g_Local.superjump);
			if (gui.Bool("���ٱ���", NULL, g_Local.superrun))
			{
				if (g_Local.superrun)
					PLAYER::SET_RUN_SPRINT_MULTIPLIER_FOR_PLAYER(PLAYER::PLAYER_ID(), 1.49);
				else
					PLAYER::SET_RUN_SPRINT_MULTIPLIER_FOR_PLAYER(PLAYER::PLAYER_ID(), 1);
			}
			if (gui.Bool("������Ӿ", NULL, g_Local.superswim))
			{
				if (g_Local.superswim)
				{
					PLAYER::SET_SWIM_MULTIPLIER_FOR_PLAYER(PLAYER::PLAYER_PED_ID(), 3.49);
					PLAYER::SET_SWIM_MULTIPLIER_FOR_PLAYER(PLAYER::PLAYER_ID(), 3.49);
				}
				else
				{
					PLAYER::SET_SWIM_MULTIPLIER_FOR_PLAYER(PLAYER::PLAYER_PED_ID(), 1);
					PLAYER::SET_SWIM_MULTIPLIER_FOR_PLAYER(PLAYER::PLAYER_ID(), 1);
				}
			}
			gui.Bool("ˮ������", NULL, g_Local.walkonwater);
			gui.Bool("���", NULL, g_Local.firebreath);
			gui.Bool("����ģʽ", NULL, g_Local.superman);
			if (gui.Bool("��Сģ��", NULL, g_Local.tinyplayer))
			{
				PED::SET_PED_CONFIG_FLAG(PLAYER::PLAYER_PED_ID(), 223, g_Local.tinyplayer);
			}
			if (gui.Bool("����", NULL, g_Local.invisible))
			{
				if (g_Local.invisible)
					ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(), false, false);
				else ENTITY::SET_ENTITY_VISIBLE(PLAYER::PLAYER_PED_ID(), true, true);
			}
			if (gui.Option("�������Ѫ��", NULL))
			{
				ENTITY::SET_ENTITY_HEALTH(PLAYER::PLAYER_PED_ID(), 400);
			}
			if (gui.Option("������󻤼�", NULL))
			{
				PED::ADD_ARMOUR_TO_PED(PLAYER::PLAYER_PED_ID(), 200);
			}
			if (gui.Option("�������", NULL))
			{
				PED::CLEAR_ALL_PED_PROPS(PLAYER::PLAYER_PED_ID());
				PED::CLEAR_PED_BLOOD_DAMAGE(PLAYER::PLAYER_PED_ID());
				PED::CLEAR_PED_WETNESS(PLAYER::PLAYER_PED_ID());
				PED::CLEAR_PED_DECORATIONS(PLAYER::PLAYER_PED_ID());
				PED::_CLEAR_PED_FACIAL_DECORATIONS(PLAYER::PLAYER_PED_ID());
			}
			if (gui.Option("��ɱ", NULL))
			{
				ENTITY::SET_ENTITY_HEALTH(PLAYER::PLAYER_PED_ID(), 0);
			}
			if (gui.Option("���װ��", NULL))
			{
				PED::SET_PED_RANDOM_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), true);
			}
			if (gui.Option("��¡�Լ�", NULL))
			{
				PED::CLONE_PED(PLAYER::PLAYER_PED_ID(), ENTITY::GET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID()), false, true);
			}
		}
		break;
		case tongjixuanx:
		{
			gui.Title("ͨ��ѡ��");

			gui.Bool("����ͨ��", NULL, g_Local.neverwanted);
			if (gui.Option("���ͨ��", NULL))
			{
				PLAYER::CLEAR_PLAYER_WANTED_LEVEL(PLAYER::PLAYER_ID());
			}
			if (gui.Option("��������5��ͨ��", NULL))
			{
				PLAYER::SET_PLAYER_WANTED_LEVEL(PLAYER::PLAYER_ID(), 5, false);
				PLAYER::SET_PLAYER_WANTED_LEVEL_NOW(PLAYER::PLAYER_ID(), false);
			}
			if (gui.Option("��������6�����ͨ��", NULL))
			{
				MISC::SET_FAKE_WANTED_LEVEL(6);
			}
			if (gui.Option("ȡ��6�����ͨ��", NULL))
			{
				MISC::SET_FAKE_WANTED_LEVEL(0);
			}
			int level;
			if (gui.Int("ͨ���ȼ�", NULL, level, 0, 5, 1))
			{
				PLAYER::SET_PLAYER_WANTED_LEVEL(PLAYER::PLAYER_ID(), level, false);
				PLAYER::SET_PLAYER_WANTED_LEVEL_NOW(PLAYER::PLAYER_ID(), false);
			}
		}
		break;
		case animation:
		{
			gui.Title("����ѡ��");
			gui.SubMenu("��������", NULL, senas);
			if (gui.Option("ֹͣ����", NULL)) {
				Ped playerPed = PLAYER::PLAYER_PED_ID();
				ENTITY::DETACH_ENTITY(playerPed, 1, 1);
				BRAIN::CLEAR_PED_TASKS_IMMEDIATELY(playerPed);
			}
			if (gui.Option("����Ϊ������", NULL)) { MenuFunctions::doAnimation("rcmpaparazzo_2", "shag_loop_poppy"); }
			if (gui.Option("��������Ϊ", NULL)) { MenuFunctions::doAnimation("rcmpaparazzo_2", "shag_loop_a"); }
			if (gui.Option("���������", NULL)) { MenuFunctions::doAnimation("mini@strip_club@private_dance@part1", "priv_dance_p1"); }
			if (gui.Option("�ֹ������", NULL)) { MenuFunctions::doAnimation("mini@strip_club@pole_dance@pole_dance1", "pd_dance_01"); }
			if (gui.Option("���Գ�", NULL)) { MenuFunctions::doAnimation("amb@world_human_push_ups@male@base", "base"); }
			if (gui.Option("��������", NULL)) { MenuFunctions::doAnimation("amb@world_human_sit_ups@male@base", "base"); }
			if (gui.Option("��ף���", NULL)) { MenuFunctions::doAnimation("rcmfanatic1celebrate", "celebrate"); }
			if (gui.Option("��������", NULL)) { MenuFunctions::doAnimation("ragdoll@human", "electrocute"); }
			if (gui.Option("��ȡ����", NULL)) { MenuFunctions::doAnimation("mp_suicide", "pistol"); }
			if (gui.Option("����ϴ��", NULL)) { MenuFunctions::doAnimation("mp_safehouseshower@male@", "male_shower_idle_b"); }
		}
		break;
		case senas:
		{
			gui.Title("��������");
			if (gui.Option("ֹͣ����", NULL)) {
				Ped playerPed = PLAYER::PLAYER_PED_ID();
				ENTITY::DETACH_ENTITY(playerPed, 1, 1);
				BRAIN::CLEAR_PED_TASKS_IMMEDIATELY(playerPed);
			}

			if (gui.Option("���ж�", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "WORLD_HUMAN_PAPARAZZI", 0, true);
			if (gui.Option("����", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "WORLD_HUMAN_DRUG_DEALER_HARD", 0, true);
			if (gui.Option("�ȿ���", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "WORLD_HUMAN_AA_COFFEE", 0, true);
			if (gui.Option("��������", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "WORLD_HUMAN_MUSICIAN", 0, true);
			if (gui.Option("�����ڶ�", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "WORLD_HUMAN_MUSCLE_FLEX", 0, true);
			if (gui.Option("���ܶ���", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "WORLD_HUMAN_JOG_STANDING", 0, true);
			if (gui.Option("˫Ͳ��Զ��", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "WORLD_HUMAN_BINOCULARS", 0, true);
			if (gui.Option("����", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "WORLD_HUMAN_CLIPBOARD", 0, true);
			if (gui.Option("��������", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "PROP_HUMAN_SEAT_MUSCLE_BENCH_PRESS", 0, true);
			if (gui.Option("��������", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "PROP_HUMAN_MUSCLE_CHIN_UPS", 0, true);
			if (gui.Option("Ұ���տ�", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "PROP_HUMAN_BBQ", 0, true);
			if (gui.Option("���˹���", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "WORLD_HUMAN_SUPERHERO", 0, true);
			if (gui.Option("����", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "WORLD_HUMAN_STAND_FISHING", 0, true);
			if (gui.Option("����״̬", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "WORLD_HUMAN_SECURITY_SHINE_TORCH", 0, true);
			if (gui.Option("�����", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "WORLD_HUMAN_GARDENER_LEAF_BLOWER", 0, true);
			if (gui.Option("��Ӱ����", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "WORLD_HUMAN_MOBILE_FILM_SHOCKING", 0, true);
			if (gui.Option("�۲�", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "WORLD_HUMAN_COP_IDLES", 0, true);
			if (gui.Option("����", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "WORLD_HUMAN_DRINKING", 0, true);
			if (gui.Option("�߶������˶�Ա", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "WORLD_HUMAN_GOLF_PLAYER", 0, true);
			if (gui.Option("����", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "WORLD_HUMAN_WELDING", 0, true);
			if (gui.Option("���̺�", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "WORLD_HUMAN_SMOKING_POT", 0, true);
			if (gui.Option("����", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "WORLD_HUMAN_HAMMERING", 0, true);
			if (gui.Option("����", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "WORLD_HUMAN_TENNIS_PLAYER", 0, true);
			if (gui.Option("���", NULL)) BRAIN::TASK_START_SCENARIO_IN_PLACE(PLAYER::PLAYER_PED_ID(), "WORLD_HUMAN_CONST_DRILL", 0, true);
		}
		break;
		case TEXIAO_:
		{
			gui.Title("����ѡ��");
			if (gui.Option("ֹͣ����", NULL)) {
				Ped playerPed = PLAYER::PLAYER_PED_ID();
				ENTITY::DETACH_ENTITY(playerPed, 1, 1);
				BRAIN::CLEAR_PED_TASKS_IMMEDIATELY(playerPed);
			}
			if (gui.Option("��¹", NULL)) {
				Player player = PLAYER::PLAYER_ID();
				Ped playerPed = PLAYER::PLAYER_PED_ID();
				if (!ENTITY::DOES_ENTITY_EXIST(playerPed)) return;
				Vector3 pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), 1);
				Hash stripper = MISC::GET_HASH_KEY("a_c_deer");
				STREAMING::REQUEST_MODEL(stripper);
				while (!STREAMING::HAS_MODEL_LOADED(stripper))
					WAIT(0);

				int createdPED = PED::CREATE_PED(26, stripper, pos.x, pos.y, pos.z, 1, 1, 0);
				ENTITY::SET_ENTITY_INVINCIBLE(createdPED, false);
				PED::SET_PED_COMBAT_ABILITY(createdPED, 100);
				PED::SET_PED_CAN_SWITCH_WEAPON(createdPED, true);
				//				SET_ENTITY_HEADING(createdPED, 180.0f);

				ENTITY::ATTACH_ENTITY_TO_ENTITY(playerPed, createdPED, -1, 0.0f, 0.35f, 0.72f, 0.0f, 0.0f, 0.0f, 1, 0, 0, 2, 1, 1);

				//deer animation
				char* anim = "creatures@deer@move";
				char* animID = "trot";

				STREAMING::REQUEST_ANIM_DICT(anim);
				while (!STREAMING::HAS_ANIM_DICT_LOADED(anim))
					WAIT(0);

				BRAIN::TASK_PLAY_ANIM(createdPED, anim, animID, 8.0f, 0.0f, -1, 9, 0, 0, 0, 0);

				//charPose
				char* anim2 = "mp_safehouselost_table@";
				char* animID2 = "lost_table_negative_a";

				STREAMING::REQUEST_ANIM_DICT(anim2);
				while (!STREAMING::HAS_ANIM_DICT_LOADED(anim2))
					WAIT(0);

				BRAIN::TASK_PLAY_ANIM(playerPed, anim2, animID2, 8.0f, 0.0f, -1, 9, 0, 0, 0, 0);

			}
			if (gui.Option("����¹��", NULL)) {
				Player player = PLAYER::PLAYER_ID();
				Ped playerPed = PLAYER::PLAYER_PED_ID();
				if (!ENTITY::DOES_ENTITY_EXIST(playerPed)) return;
				Vector3 pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), 1);
				Hash stripper = MISC::GET_HASH_KEY("a_c_deer");
				STREAMING::REQUEST_MODEL(stripper);
				while (!STREAMING::HAS_MODEL_LOADED(stripper))
					WAIT(0);

				int createdPED = PED::CREATE_PED(26, stripper, pos.x, pos.y, pos.z, 1, 1, 0);
				ENTITY::SET_ENTITY_INVINCIBLE(createdPED, false);
				PED::SET_PED_COMBAT_ABILITY(createdPED, 100);
				PED::SET_PED_CAN_SWITCH_WEAPON(createdPED, true);
				//				SET_ENTITY_HEADING(createdPED, 180.0f);

				ENTITY::ATTACH_ENTITY_TO_ENTITY(playerPed, createdPED, -1, 0.0f, 0.35f, 0.72f, 0.0f, 0.0f, 0.0f, 1, 0, 0, 2, 1, 1);

				//charPose
				char* anim2 = "mp_safehouselost_table@";
				char* animID2 = "lost_table_negative_a";

				STREAMING::REQUEST_ANIM_DICT(anim2);
				while (!STREAMING::HAS_ANIM_DICT_LOADED(anim2))
					WAIT(0);

				BRAIN::TASK_PLAY_ANIM(playerPed, anim2, animID2, 8.0f, 0.0f, -1, 9, 0, 0, 0, 0);
			}
			if (gui.Option("����¹", NULL)) {
				Player player = PLAYER::PLAYER_ID();
				Ped playerPed = PLAYER::PLAYER_PED_ID();
				if (!ENTITY::DOES_ENTITY_EXIST(playerPed)) return;
				Vector3 pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), 1);
				Hash stripper = MISC::GET_HASH_KEY("a_c_deer");
				STREAMING::REQUEST_MODEL(stripper);
				while (!STREAMING::HAS_MODEL_LOADED(stripper))
					WAIT(0);

				int createdPED = PED::CREATE_PED(26, stripper, pos.x, pos.y, pos.z, 1, 1, 0);
				ENTITY::SET_ENTITY_INVINCIBLE(createdPED, false);
				PED::SET_PED_COMBAT_ABILITY(createdPED, 100);
				PED::SET_PED_CAN_SWITCH_WEAPON(createdPED, true);
				//				SET_ENTITY_HEADING(createdPED, 180.0f);

				ENTITY::ATTACH_ENTITY_TO_ENTITY(playerPed, createdPED, -1, 0.0f, 0.35f, 0.72f, 0.0f, 0.0f, 0.0f, 1, 0, 0, 2, 1, 1);

				//deer animation
				char* anim = "creatures@deer@move";
				char* animID = "walk";

				STREAMING::REQUEST_ANIM_DICT(anim);
				while (!STREAMING::HAS_ANIM_DICT_LOADED(anim))
					WAIT(0);

				BRAIN::TASK_PLAY_ANIM(createdPED, anim, animID, 8.0f, 0.0f, -1, 9, 0, 0, 0, 0);

				//charPose
				char* anim2 = "mp_safehouselost_table@";
				char* animID2 = "lost_table_negative_a";

				STREAMING::REQUEST_ANIM_DICT(anim2);
				while (!STREAMING::HAS_ANIM_DICT_LOADED(anim2))
					WAIT(0);

				BRAIN::TASK_PLAY_ANIM(playerPed, anim2, animID2, 8.0f, 0.0f, -1, 9, 0, 0, 0, 0);
			}
			if (gui.Option("��ţ", NULL)) {
				Player player = PLAYER::PLAYER_ID();
				Ped playerPed = PLAYER::PLAYER_PED_ID();
				if (!ENTITY::DOES_ENTITY_EXIST(playerPed)) return;
				Vector3 pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), 1);
				Hash stripper = MISC::GET_HASH_KEY("a_c_cow");
				STREAMING::REQUEST_MODEL(stripper);
				while (!STREAMING::HAS_MODEL_LOADED(stripper))
					WAIT(0);

				int createdPED = PED::CREATE_PED(26, stripper, pos.x, pos.y, pos.z, 1, 1, 0);
				ENTITY::SET_ENTITY_INVINCIBLE(createdPED, false);
				PED::SET_PED_COMBAT_ABILITY(createdPED, 100);
				PED::SET_PED_CAN_SWITCH_WEAPON(createdPED, true);
				//				SET_ENTITY_HEADING(createdPED, 180.0f);

				ENTITY::ATTACH_ENTITY_TO_ENTITY(playerPed, createdPED, -1, 0.0f, 0.35f, 0.72f, 0.0f, 0.0f, 0.0f, 1, 0, 0, 2, 1, 1);

				//charPose
				char* anim2 = "mp_safehouselost_table@";
				char* animID2 = "lost_table_negative_a";

				STREAMING::REQUEST_ANIM_DICT(anim2);
				while (!STREAMING::HAS_ANIM_DICT_LOADED(anim2))
					WAIT(0);

				BRAIN::TASK_PLAY_ANIM(playerPed, anim2, animID2, 8.0f, 0.0f, -1, 9, 0, 0, 0, 0);
			}
		}
		break;
		case OutfitCreator:
		{
			gui.Title("��װѡ��");
			gui.Int("ñ��", NULL, g_Local.Face_, 0, 55); { PED::SET_PED_PROP_INDEX(PLAYER::PLAYER_PED_ID(), 0, g_Local.Face_, 0, 1); }
			gui.Int("�۾�", NULL, g_Local.Glasses_, 0, 23); { PED::SET_PED_PROP_INDEX(PLAYER::PLAYER_PED_ID(), 1, g_Local.Glasses_, 0, 1); }
			gui.Int("����", NULL, g_Local.Ears_, 0, 3); { PED::SET_PED_PROP_INDEX(PLAYER::PLAYER_PED_ID(), 2, g_Local.Ears_, 0, 1); }
			gui.Int("�ϲ��װ", NULL, g_Local.Torso_, 0, 150); { PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 3, g_Local.Torso_, 0, 1); }
			gui.Int("�²��װ", NULL, g_Local.Torso2_, 0, 150); { PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 11, g_Local.Torso2_, 0, 1); }
			gui.Int("�Ȳ�", NULL, g_Local.Legs_, 0, 150); { PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 4, g_Local.Legs_, 0, 1); }
			gui.Int("��", NULL, g_Local.Hands_, 0, 150); { PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 5, g_Local.Hands_, 0, 1); }
			gui.Int("�ֱ�", NULL, g_Local.Watches_, 0, 150); { PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 6, g_Local.Watches_, 0, 1); }
			gui.Int("���� 1", NULL, g_Local.Special1_, 0, 150); { PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 7, g_Local.Special1_, 0, 1); }
			gui.Int("���� 2 ", NULL, g_Local.Special2_, 0, 150); { PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 8, g_Local.Special2_, 0, 1); }
			gui.Int("���� 3", NULL, g_Local.Special3_, 0, 150); { PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 9, g_Local.Special3_, 0, 1); }
			gui.Int("����", NULL, g_Local.Texture_, 0, 150); { PED::SET_PED_COMPONENT_VARIATION(PLAYER::PLAYER_PED_ID(), 10, g_Local.Texture_, 0, 1); }
		}
		break;
		case conversation:
		{
			gui.Title("ս�ֹ���");
			gui.SubMenu("����б�", NULL, playerlist);
			gui.SubMenu("����ѡ��", NULL, drop);
			gui.SubMenu("����ѡ��", NULL, help);
			gui.SubMenu("ս������", NULL, sessionstarter);
			gui.SubMenu("ȫ��͸��", NULL, quanjutoushi);
			gui.SubMenu("�����Ϣ", NULL, xujiaxinxi);
			gui.Bool("�˼�����", NULL, g_Session.zhengfa);
		}
		break;
		case xujiaxinxi:
		{
			gui.Title("�����Ϣ");
			if (gui.Option("������ͨ�������", NULL))
			{
				WAIT(0);
				char* name = MenuFunctions::getKEYBOARD("SPOOF_NAME");
				MenuFunctions::setSpoofName(name);
			}
			if (gui.Option("~r~��ɫ����", NULL)) { std::string nname = MenuFunctions::getKEYBOARD("SPOOF_NAME"); MenuFunctions::setSpoofName(StringToChar("~r~" + nname)); }
			if (gui.Option("~b~��ɫ����", NULL)) { std::string nname = MenuFunctions::getKEYBOARD("SPOOF_NAME"); MenuFunctions::setSpoofName(StringToChar("~b~" + nname)); }
			if (gui.Option("~g~��ɫ����", NULL)) { std::string nname = MenuFunctions::getKEYBOARD("SPOOF_NAME"); MenuFunctions::setSpoofName(StringToChar("~g~" + nname)); }
			if (gui.Option("~y~��ɫ����", NULL)) { std::string nname = MenuFunctions::getKEYBOARD("SPOOF_NAME"); MenuFunctions::setSpoofName(StringToChar("~y~" + nname)); }
			if (gui.Option("~p~��ɫ����", NULL)) { std::string nname = MenuFunctions::getKEYBOARD("SPOOF_NAME"); MenuFunctions::setSpoofName(StringToChar("~p~" + nname)); }
			if (gui.Option("~o~��ɫ����", NULL)) { std::string nname = MenuFunctions::getKEYBOARD("SPOOF_NAME"); MenuFunctions::setSpoofName(StringToChar("~o~" + nname)); }
			if (gui.Option("~c~��ɫ����", NULL)) { std::string nname = MenuFunctions::getKEYBOARD("SPOOF_NAME"); MenuFunctions::setSpoofName(StringToChar("~c~" + nname)); }
			if (gui.Option("~m~����ɫ����", NULL)) { std::string nname = MenuFunctions::getKEYBOARD("SPOOF_NAME"); MenuFunctions::setSpoofName(StringToChar("~m~" + nname)); }
			if (gui.Option("~u~��ɫ����", NULL)) { std::string nname = MenuFunctions::getKEYBOARD("SPOOF_NAME"); MenuFunctions::setSpoofName(StringToChar("~u~" + nname)); }
			if (gui.Option("~s~��ɫ����", NULL)) { std::string nname = MenuFunctions::getKEYBOARD("SPOOF_NAME"); MenuFunctions::setSpoofName(StringToChar("~s~" + nname)); }
			if (gui.Option("~d~����ɫ����", NULL)) { std::string nname = MenuFunctions::getKEYBOARD("SPOOF_NAME"); MenuFunctions::setSpoofName(StringToChar("~d~" + nname)); }
			if (gui.Option("~f~����ɫ����", NULL)) { std::string nname = MenuFunctions::getKEYBOARD("SPOOF_NAME"); MenuFunctions::setSpoofName(StringToChar("~f~" + nname)); }
			if (gui.Option("~bold~�Ӵֵ�����", NULL)) { std::string nname = MenuFunctions::getKEYBOARD("SPOOF_NAME"); MenuFunctions::setSpoofName(StringToChar("~bold~" + nname)); }
			if (gui.Option("~italic~б�������", NULL)) { std::string nname = MenuFunctions::getKEYBOARD("SPOOF_NAME"); MenuFunctions::setSpoofName(StringToChar("~italic~" + nname)); }
			if (gui.Option("~ws~�����ǵ�����", NULL)) { std::string nname = MenuFunctions::getKEYBOARD("SPOOF_NAME"); MenuFunctions::setSpoofName(StringToChar("~ws~" + nname)); }

		}
		break;
		case quanjutoushi:
		{
			gui.Title("ȫ��͸��");
			gui.Bool("ȫ������͸��", NULL, g_Session.ESPname);
			gui.Bool("ȫ�ַ���͸��", NULL, g_Session.espbox);
			gui.Bool("ȫ��ֱ��͸��" ,NULL, g_Session.espline);
		}
		break;
		case sessionstarter:
		{
			gui.Title("ս������");
			if (gui.Option("���빫��ս��", NULL))
			{
				MenuFunctions::JoinSession(0);
			}
			if (gui.Option("��������ս��", NULL))
			{
				MenuFunctions::JoinSession(1);
			}
			if (gui.Option("�������Ա", NULL))
			{
				MenuFunctions::JoinSession(12);
			}
			if (gui.Option("������ս��", NULL))
			{
				MenuFunctions::JoinSession(3);
			}
			if (gui.Option("����˽�˰��ս��", NULL))
			{
				MenuFunctions::JoinSession(2);
			}
			if (gui.Option("�������ս��", NULL))
			{
				MenuFunctions::JoinSession(9);
			}
			if (gui.Option("����˽�˺���ս��", NULL))
			{
				MenuFunctions::JoinSession(6);
			}
			if (gui.Option("�ǹ���˽��ս��", NULL))
			{
				MenuFunctions::JoinSession(10);
			}
			if (gui.Option("��������ս��", NULL))
			{
				MenuFunctions::JoinSession(11);
			}
		}
		break;
		case help:
		{
			gui.Title("����ѡ��");
			if (gui.Option("�����г�������ս����", "��ȷ�����Ѿ��и��ʲ����ܺ���"))
			{
				script_global({ 2793046 + 925 }, 1);
			}
			if (gui.Option("�����г�������", "��ȷ�����Ѿ��и��ʲ����ܺ���"))
			{
				script_global({ 2793046 + 933 }, 1);
			}
			if (gui.Option("�����г��ְ�", "��ȷ�����Ѿ��и��ʲ����ܺ���"))
			{
				script_global({ 2793046 + 937 }, 1);
			}
			if (gui.Option("�����г�����", "��ȷ�����Ѿ��и��ʲ����ܺ���"))
			{
				script_global({ 2793046 + 954 }, 1);
			}
			if (gui.Option("�����г��»ü�ʵ����", "��ȷ�����Ѿ��и��ʲ����ܺ���"))
			{
				script_global({ 2793046 + 938 }, 1);
			}
			if (gui.Option("�����г�Сͧ", "��ȷ�����Ѿ��и��ʲ����ܺ���"))
			{
				script_global({ 2793046 + 966 }, 1);
			}
			if (gui.Option("�����г����ͷ���װ��", NULL))
			{
				script_global({ 2793046 + 886 }, 1);
			}
		}
		break;
		case drop:
		{
			gui.Title("����ѡ��");
			if (gui.Option("���併��ɡ", NULL))
			{
				Vector3 vec = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), true);
				OBJECT::CREATE_AMBIENT_PICKUP(MISC::GET_HASH_KEY("PICKUP_PARACHUTE"), vec.x, vec.y, vec.z, 0, 2500, 1, 0, 1);
			}
			if (gui.Option("���������", NULL))
			{
				Vector3 vec = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), true);
				OBJECT::CREATE_AMBIENT_PICKUP(MISC::GET_HASH_KEY("PICKUP_ARMOUR_STANDARD"), vec.x, vec.y, vec.z, 0, 2500, 1, 0, 1);
			}
			if (gui.Option("����ҽ�ư�", NULL))
			{
				Vector3 vec = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), true);
				OBJECT::CREATE_AMBIENT_PICKUP(MISC::GET_HASH_KEY("PICKUP_HEALTH_STANDARD"), vec.x, vec.y, vec.z, 0, 2500, 1, 0, 1);
			}
		}
		break;
		case playerlist:
			gui.Title("����б�");
			for (int i = 0; i < 32; ++i) {
				if (ENTITY::DOES_ENTITY_EXIST(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i))) {
					gui.SubMenu(PLAYER::GET_PLAYER_NAME(i), NULL, playerfunction) ? Online::g_SelectedPlayer = i : NULL;
				}
			}
		break;
		case playerfunction:
			gui.Title(PLAYER::GET_PLAYER_NAME(Online::g_SelectedPlayer));
			gui.SubMenu("���ѡ��", NULL, troll);
			gui.SubMenu("�߳�ѡ��", NULL, kicks);
			gui.SubMenu("����ѡ��", NULL, spawner);
			gui.SubMenu("�ؾ�ѡ��", NULL, vehtroll);
			gui.SubMenu("�Ѻ�ѡ��", NULL, peaceful); 
			gui.Bool("�ۿ����", NULL, g_Plists.spectate);
		break;
		case kicks:
		{
			gui.Title("�߳�ѡ��");
			if (gui.Option("������", "�����������������߳����"))
			{
				NETWORK::NETWORK_SESSION_KICK_PLAYER(Online::g_SelectedPlayer);
			}
			if (gui.Option("�˼������", NULL))
			{
				if (PED::IS_PED_IN_ANY_VEHICLE(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), true))
				{
					int veh = PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
					MenuFunctions::requestControlOfEnt(veh);
					ENTITY::APPLY_FORCE_TO_ENTITY(veh, true, 0, 0, 6.0f, 0, -2.0f, 0, true, true, true, true, false, true);
					MenuFunctions::Notify("ִ�гɹ��������߳�");
				}
			}
		}
		break;
		case peaceful:
		{
			gui.Title("�Ѻ�ѡ��");
			if (gui.Option("������������", NULL))
			{
				for (Hash hash : AllWeaponList)
					WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), hash, 9999, 1);
			}
			if (gui.Option("�Ƴ���������", NULL))
			{
				WEAPON::REMOVE_ALL_PED_WEAPONS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), 1);
			}
			if (gui.Option("���併��ɡ", NULL))
			{
				Vector3 vec = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), true);
				OBJECT::CREATE_AMBIENT_PICKUP(MISC::GET_HASH_KEY("PICKUP_PARACHUTE"), vec.x, vec.y, vec.z, 0, 2500, 1, 0, 1);
			}
			if (gui.Option("���������", NULL))
			{
				Vector3 vec = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), true);
				OBJECT::CREATE_AMBIENT_PICKUP(MISC::GET_HASH_KEY("PICKUP_ARMOUR_STANDARD"), vec.x, vec.y, vec.z, 0, 2500, 1, 0, 1);
			}
			if (gui.Option("����ҽ�ư�", NULL))
			{
				Vector3 vec = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), true);
				OBJECT::CREATE_AMBIENT_PICKUP(MISC::GET_HASH_KEY("PICKUP_HEALTH_STANDARD"), vec.x, vec.y, vec.z, 0, 2500, 1, 0, 1);
			}
		}
		break;
		case vehtroll:
		{
			gui.Title("�ؾ�ѡ��");
			if (gui.Option("����120��", NULL))
			{
				Vehicle veh = PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
				MenuFunctions::requestControlOfEnt(veh);
				VEHICLE::SET_VEHICLE_FORWARD_SPEED(veh, 120.0f);
			}
			if (gui.Option("����", NULL))
			{
				Vehicle veh = PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
				MenuFunctions::requestControlOfEnt(veh);
				float a = 2, b = 3, c = 4;
				VEHICLE::SET_VEHICLE_DOORS_LOCKED(&veh, &a);
				VEHICLE::SET_VEHICLE_DOORS_LOCKED(&veh, &b);
				VEHICLE::SET_VEHICLE_DOORS_LOCKED(&veh, &c);
			}
			if (gui.Option("����", NULL))
			{
				Vehicle veh = PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
				MenuFunctions::requestControlOfEnt(veh);
				float a = 1;
				VEHICLE::SET_VEHICLE_DOORS_LOCKED(&veh, &a);
			}
			if (gui.Option("��ǰ����", NULL))
			{
				if (PED::IS_PED_IN_ANY_VEHICLE(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), true))
				{
					int veh = PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
					MenuFunctions::requestControlOfEnt(veh);
					ENTITY::APPLY_FORCE_TO_ENTITY(veh, true, 0, 0, 6.0f, 0, -2.0f, 0, true, true, true, true, false, true);
				}
			}
			if (gui.Option("˫����ǰ����", NULL))
			{
				if (PED::IS_PED_IN_ANY_VEHICLE(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), true))
				{
					int veh = PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
					MenuFunctions::requestControlOfEnt(veh);
					ENTITY::APPLY_FORCE_TO_ENTITY(veh, true, 0, 0, 12.0f, 0, -4.0f, 0, true, true, true, true, false, true);
				}
			}
			if (gui.Option("��󷭹�", NULL))
			{
				if (PED::IS_PED_IN_ANY_VEHICLE(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), true))
				{
					int veh = PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
					MenuFunctions::requestControlOfEnt(veh);
					ENTITY::APPLY_FORCE_TO_ENTITY(veh, true, 0, 0, 6.0f, 0, 2.0f, 0, true, true, true, true, false, true);
				}
			}
			if (gui.Option("˫����󷭹�", NULL))
			{
				if (PED::IS_PED_IN_ANY_VEHICLE(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), true))
				{
					int veh = PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
					MenuFunctions::requestControlOfEnt(veh);
					ENTITY::APPLY_FORCE_TO_ENTITY(veh, true, 0, 0, 12.0f, 0, 4.0f, 0, true, true, true, true, false, true);
				}
			}
			if (gui.Option("��߷���", NULL))
			{
				if (PED::IS_PED_IN_ANY_VEHICLE(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), true))
				{
					int veh = PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
					MenuFunctions::requestControlOfEnt(veh);
					ENTITY::APPLY_FORCE_TO_ENTITY(veh, true, 0, 0, 6.0f, 5.0f, 2.0f, 0, true, true, true, true, false, true);
				}
			}
			if (gui.Option("�ߵ�����", NULL))
			{
				if (PED::IS_PED_IN_ANY_VEHICLE(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), true))
				{
					int veh = PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
					MenuFunctions::requestControlOfEnt(veh);
					ENTITY::APPLY_FORCE_TO_ENTITY(veh, true, 0, 0, 5.0f, 2.0f, 0, 0, true, true, true, true, false, true);
				}
			}
			if (gui.Option("������", NULL))
			{
				if (PED::IS_PED_IN_ANY_VEHICLE(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), true))
				{
					int veh = PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
					MenuFunctions::requestControlOfEnt(veh);
					ENTITY::APPLY_FORCE_TO_ENTITY(veh, true, 0, 0, 5.0f, -2.0f, 0, 0, true, true, true, true, false, true);
				}
			}
			if (gui.Option("����Hop", NULL))
			{
				if (PED::IS_PED_IN_ANY_VEHICLE(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), true))
				{
					int veh = PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
					MenuFunctions::requestControlOfEnt(veh);
					ENTITY::APPLY_FORCE_TO_ENTITY(veh, true, 0, 0, 7.0f, 0, 0, 0, true, true, true, true, false, true);
				}
			}
			if (gui.Option("��ɣ�", NULL))
			{
				if (PED::IS_PED_IN_ANY_VEHICLE(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), true))
				{
					int veh = PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
					MenuFunctions::requestControlOfEnt(veh);
					ENTITY::APPLY_FORCE_TO_ENTITY(veh, true, 0, 0, 40.0f, 0, 0, 0, true, true, true, true, false, true);
				}
			}
			if (gui.Option("���䣡", NULL))
			{
				if (PED::IS_PED_IN_ANY_VEHICLE(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), true))
				{
					int veh = PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
					MenuFunctions::requestControlOfEnt(veh);
					ENTITY::APPLY_FORCE_TO_ENTITY(veh, true, 0, 0, -40.0f, 0, 0, 0, true, true, true, true, false, true);
				}
			}
		}
		break;
		case spawner:
		{
			gui.Title("����ѡ��");
			gui.SubMenu("����", NULL, spawnenemy);
			gui.SubMenu("�ؾ�", NULL, spawnveh);
		}
		break;
		case spawnenemy:
		{
			gui.Title("���ɵ���");
			if (gui.Option("���ɴ޷�", NULL))
			{
				Hash enemy = 0x9B810FA2;
				STREAMING::REQUEST_MODEL(enemy);
				Player get_player_ped = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer);
				Vector3 pos = ENTITY::GET_ENTITY_COORDS(get_player_ped, true);
				Ped ped = PED::CREATE_PED(2, enemy, pos.x, pos.y + 5.0f, pos.z + 1.0f, ENTITY::GET_ENTITY_HEADING(get_player_ped), true, true);
				if (ped)
				{
					WEAPON::GIVE_DELAYED_WEAPON_TO_PED(ped, -2084633992, 9999, true);
					PED::SET_PED_CAN_SWITCH_WEAPON(ped, true);
					PED::SET_PED_AS_ENEMY(ped, true);
				}
			}
			if (gui.Option("����ɽʨ", NULL))
			{
				Hash Lion = 307287994;
				STREAMING::REQUEST_MODEL(Lion);
				Player get_player_ped = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer);
				Vector3 pos = ENTITY::GET_ENTITY_COORDS(get_player_ped, true);
				Ped ped = PED::CREATE_PED(2, Lion, pos.x, pos.y + 5.0f, pos.z + 1.0f, ENTITY::GET_ENTITY_HEADING(get_player_ped), true, true);
				if (ped)
				{
					PED::SET_PED_AS_ENEMY(ped, true);
				}
			}
			if (gui.Option("������ƨƨ", NULL))
			{
				Hash pig = 0xB11BAB56;
				STREAMING::REQUEST_MODEL(pig);
				Player get_player_ped = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer);
				Vector3 pos = ENTITY::GET_ENTITY_COORDS(get_player_ped, true);
				Ped ped = PED::CREATE_PED(2, pig, pos.x, pos.y + 5.0f, pos.z + 1.0f, ENTITY::GET_ENTITY_HEADING(get_player_ped), true, true);
				if (ped)
				{
					PED::SET_PED_AS_ENEMY(ped, true);
				}
			}
		}
		break;
		case spawnveh:
		{
			gui.Title("�����ؾ�");
			if (gui.Option("����T20", NULL))
			{
				MenuFunctions::spawncartoplayer("T20");
			}
			if (gui.Option("����XA21", NULL))
			{
				MenuFunctions::spawncartoplayer("XA21");
			}
			if (gui.Option("������ɷ", NULL))
			{
				MenuFunctions::spawncartoplayer("Lazer");
			}
			if (gui.Option("���ɱ���", NULL))
			{
				MenuFunctions::spawncartoplayer("Oppressor");
			}
			if (gui.Option("����������", NULL))
			{
				MenuFunctions::spawncartoplayer("oppressor2");
			}
		}
		break;
		case troll:
		{

			gui.Title("���ѡ��");
			gui.SubMenu("��������", NULL, cages);
			gui.Bool("�������", NULL, g_Plists.freezeplayer);
			gui.Bool("��ѭ��", NULL, g_Plists.fireloop);
			gui.Bool("ˮѭ��", NULL, g_Plists.waterloop);
			gui.Bool("ѭ����ը", NULL, g_Plists.explosionloop);
			gui.Bool("������֡", NULL, g_Plists.FPSdrop);
			if (gui.Option("������", NULL ))
			{
				Vector3 destination = PED::GET_PED_BONE_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), SKEL_ROOT, 0.0f, 0.0f, 0.0f);
				Vector3 origin = PED::GET_PED_BONE_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), SKEL_R_Hand, 0.0f, 0.0f, 0.2f);
				Hash tazerHash = MISC::GET_HASH_KEY((char*)"WEAPON_STUNGUN");
				MISC::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(origin.x, origin.y, origin.z, destination.x, destination.y, destination.z, 1, 0, tazerHash, PLAYER::PLAYER_PED_ID(), false, false, 1);
			}
			if (gui.Option("ҡ�ξ�ͷ", NULL))
			{
				Vector3 Coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), true);
				Hash explosionFx;
				owned_explossion_bypass(true);
				FIRE::ADD_EXPLOSION(Coords.x, Coords.y, Coords.z, CameraShakeHand, 50.f, false, true, 50.f,false);
				owned_explossion_bypass(false);
			}
			if (gui.Option("��¡���ķ�װ", NULL))
			{
				Ped playerPed = PLAYER::PLAYER_PED_ID();
				Ped theirPed = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer);

				for (int i = 0; i < 12; i++)
				{
					PED::SET_PED_COMPONENT_VARIATION(playerPed, i, PED::GET_PED_DRAWABLE_VARIATION(theirPed, i),
						PED::GET_PED_TEXTURE_VARIATION(theirPed, i),
						PED::GET_PED_PALETTE_VARIATION(theirPed, i));
					for (int i = 0; i < 2; i++)
					{
						WAIT(0);
					}
				}
			}
			if (gui.Option("��¡���", NULL))
			{
				int clone = PED::CLONE_PED(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), 1, 1, 1);
				ENTITY::SET_ENTITY_AS_NO_LONGER_NEEDED(&clone);
			}
		}
		break;
		case cages:
		{
			gui.Title("����");
			if (gui.Option("�������", NULL))
			{
				Vector3 pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
				MISC::CLEAR_AREA(pos.x, pos.y, pos.z, 10.0f, true, false, false, false);
				MISC::_CLEAR_AREA_OF_EVERYTHING(pos.x, pos.y, pos.z, 10.0f, false, false, false, false);
				MISC::CLEAR_AREA_OF_OBJECTS(pos.x, pos.y, pos.z, 10.0f, 2);
				MenuFunctions::Notify("����������");
			}
			if (gui.Option("��դ��", NULL))
			{
				model_spawn_bypass(true);
				if (PED::IS_PED_IN_ANY_VEHICLE(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), 0));
				{
					BRAIN::CLEAR_PED_TASKS_IMMEDIATELY(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
					WAIT(10);
				}
				BRAIN::CLEAR_PED_TASKS_IMMEDIATELY(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
				Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), true);
				MenuFunctions::CREATE_OBJECT_WITH_ROTATION(206865238, coords.x - 1.39, coords.y - 1.87f, coords.z - 1.0f, 0.0f, 0.0f, -0.66576f, 0.746166f, false, true);
				MenuFunctions::CREATE_OBJECT_WITH_ROTATION(206865238, coords.x + 1.51f, coords.y + 1.94f, coords.z - 1.0f, 0.0f, 0.0f, 0.75172f, 0.659482f, false, true);
				model_spawn_bypass(false);
				MenuFunctions::Notify("ִ�гɹ�����ִ��������դ��");
			}
			if (gui.Option("��ƿ����", NULL))
			{
				model_spawn_bypass(true);
				if (PED::IS_PED_IN_ANY_VEHICLE(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), 0));
				{
					BRAIN::CLEAR_PED_TASKS_IMMEDIATELY(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
					WAIT(10);
				}
				BRAIN::CLEAR_PED_TASKS_IMMEDIATELY(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
				Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), true);
				Hash cage2 = MISC::GET_HASH_KEY("prop_gascage01");
				OBJECT::CREATE_OBJECT(cage2, coords.x, coords.y, coords.z, true, true, false);
				model_spawn_bypass(false);
				MenuFunctions::Notify("ִ�гɹ�����ִ��������ƿ����");
			}
			if (gui.Option("���������", NULL))
			{
				model_spawn_bypass(true);
				BRAIN::CLEAR_PED_TASKS_IMMEDIATELY(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
				Vector3 pos = ENTITY::GET_ENTITY_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), true);
				Object obj = OBJECT::CREATE_OBJECT(0x392d62aa, pos.x, pos.y, pos.z - 1.f, true, false, false);
				ENTITY::SET_ENTITY_AS_NO_LONGER_NEEDED(&obj);
				model_spawn_bypass(false);
				MenuFunctions::Notify("ִ�гɹ�����ִ�����Ӿ�������");
			}
		}
		break;
		}
		gui.End();
		WAIT(0);
	}
}