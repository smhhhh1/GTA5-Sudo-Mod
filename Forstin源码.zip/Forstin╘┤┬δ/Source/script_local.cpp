#include"script_local.h"

namespace script_local
{
	__int64 GetLocalScript(std::string n)
	{
		for (int i = 0; i < 53; i++)
		{
			__int64 Pointer = get_long(get_long(Hooking::LocalScript) + i * 8);
			int lc_pointer = get_int(Pointer + 0xB0);
			std::string lc_name = get_text(Pointer + 0xD4, 60);
			if (lc_name == "")
			{
				continue;
			}
			if (lc_name == n && lc_pointer != 0)
			{
				return Pointer + 0xB0;
			}
		}
		return 0;
	}
	__int64 get_long(__int64 addr) {
		if (addr == NULL) return NULL;
		if (IsBadReadPtr((PVOID)addr, sizeof(__int64))) return NULL;
		return *(__int64*)addr;
	}
	std::string get_text(__int64 addr, int size) {
		char* temp = new char[size];
		memset(temp, 0, size);
		std::string text = "";
		if (IsBadReadPtr((PVOID)addr, size)) return text;
		memcpy(temp, (PVOID)addr, size);
		text = temp;
		delete[]temp;
		return text;
	}
	void set_int(__int64 addr, int value) {
		if (addr == NULL) return;
		if (IsBadWritePtr((PVOID)addr, sizeof(int))) return;
		*(int*)addr = value;
	}
	int get_int(__int64 addr) {
		if (addr == NULL) return NULL;
		if (IsBadReadPtr((PVOID)addr, sizeof(int))) return NULL;
		return *(int*)addr;
	}
	__int64 LA(__int64 addr, int Index)
	{
		return get_long(addr) + Index * 8;
	}
	void script_local(__int64 addr, int Index, int Value)
	{
		set_int(LA(addr, Index), Value);
	}
}