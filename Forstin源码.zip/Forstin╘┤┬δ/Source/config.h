#pragma once
#include"stdafx.h"
#include"features.h"

namespace config
{
	int ReadConfig(std::wstring Section, std::wstring Item);
	void WriteConfig(std::wstring Section, std::wstring Item, std::wstring WriteData);
	void load_config();
	void save_config();
	void zidong_config(bool toggle);
}