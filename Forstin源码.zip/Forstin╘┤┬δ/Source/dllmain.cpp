// dllmain.cpp : Defines the entry point for the DLL application.
#include "stdafx.h"

std::atomic_bool g_running = true;

DWORD WINAPI ControlThread(LPVOID lpParam)
{
	if (AllocConsole()) {
		freopen_s(reinterpret_cast<FILE**>(stdout), "CONOUT$", "w", stdout);
		SetConsoleTitleW(L"Forstin");
		SetConsoleCP(CP_UTF8);
		SetConsoleOutputCP(CP_UTF8);
	}
	Log_Info(R"(

  ______                 _    _             __  __                     
 |  ____|               | |  (_)           |  \/  |                    
 | |__  ___   _ __  ___ | |_  _  _ __      | \  / |  ___  _ __   _   _ 
 |  __|/ _ \ | '__|/ __|| __|| || '_ \     | |\/| | / _ \| '_ \ | | | |
 | |  | (_) || |   \__ \| |_ | || | | |    | |  | ||  __/| | | || |_| |
 |_|   \___/ |_|   |___/ \__||_||_| |_|    |_|  |_| \___||_| |_| \____|
                                             
                                              )");
	Hooking::Start((HMODULE)lpParam);

	while (g_running)
	{
		std::this_thread::sleep_for(std::chrono::milliseconds(10));
		std::this_thread::yield();

		if (Menu::gui.textureID != 0 && !Menu::gui.reggedytd) // Cringe code, please no look
		{
			std::string ytd = std::string("The external YTD resource file has been loaded,-�ļ�ID: ") + std::to_string(Menu::gui.textureID).c_str();
			Log_Info(_strdup(ytd.c_str()));
			Menu::gui.reggedytd = true;
		}
	}

	Hooking::Cleanup();
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)ControlThread, hModule, NULL, NULL);
		break;
	case DLL_THREAD_ATTACH:
		break;
	case DLL_THREAD_DETACH:
		break;
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}