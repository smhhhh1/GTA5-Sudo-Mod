#pragma once
#include "features.h"
#include "script_local.h"
#include"protection.h"

int TimePD = 0;
namespace Features
{
	using namespace Menu;
	bool FreeCamFeaturedUsed = false;
	Cam FreeCamHandle;
	void LocalLoop()
	{
		if (g_Local.GodMode)
		{
			Memory::set_value<bool>({ 0x08 , 0x189 }, 1);
		}
		else { Memory::set_value<bool>({ 0x08 , 0x189 }, 0); }
		if (g_Local.freecambool)
		{
			Memory::set_value<float>({ 0x8,0x30,0x10,0x20,0x70,0x0,0x2C }, -1);
		}
		if (g_Local.FreeCam)
		{
			Vector3 rot = CAM::GET_MISC_CAM_ROT(0);
			Vector3 coord = CAM::GET_MISC_CAM_COORD();
			Vector3 p_coord = { 0, 0, 0 };

			if (CAM::GET_FOLLOW_PED_CAM_VIEW_MODE() == PedCamViewModes::FirstPerson)
			{
				CAM::SET_FOLLOW_PED_CAM_VIEW_MODE(PedCamViewModes::ThirdPersonMedium);
			}
			FreeCamFeaturedUsed = true;
			if (!CAM::DOES_CAM_EXIST(FreeCamHandle))
			{
				FreeCamHandle = CAM::CREATE_CAM("DEFAULT_SCRIPTED_CAMERA", true);
				CAM::SET_CAM_ROT(FreeCamHandle, rot.x, rot.y, rot.z, 0);
				CAM::SET_CAM_COORD(FreeCamHandle, coord.x, coord.y, coord.z);
			}

			CAM::RENDER_SCRIPT_CAMS(true, true, 700, true, true, false);
			CAM::SET_CAM_ACTIVE(FreeCamHandle, 1);
			CAM::SET_CAM_ROT(FreeCamHandle, rot.x, rot.y, rot.z, 0);

			p_coord = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);

			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(PLAYER::PLAYER_PED_ID(), p_coord.x, p_coord.y, p_coord.z, 0, 0, 0);
			PLAYER::DISABLE_PLAYER_FIRING(PLAYER::PLAYER_PED_ID(), true);
			HUD::HIDE_HUD_AND_RADAR_THIS_FRAME();

			float speed = .5f;
			if (PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_SPRINT))
			{
				speed += .3f;
			}

			if (PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_MOVE_UD))
			{
				speed /= -1;
				Vector3 c = MenuFunctions::AddTwoVectors(&CAM::GET_CAM_COORD(FreeCamHandle), &MenuFunctions::MultiplyVector(&MenuFunctions::RotationToDirection(&rot), speed));
				CAM::SET_CAM_COORD(FreeCamHandle, c.x, c.y, c.z);
			}

			if (PAD::IS_DISABLED_CONTROL_PRESSED(0, INPUT_MOVE_UP_ONLY))
			{
				Vector3 c = MenuFunctions::AddTwoVectors(&CAM::GET_CAM_COORD(FreeCamHandle), &MenuFunctions::MultiplyVector(&MenuFunctions::RotationToDirection(&rot), speed));
				CAM::SET_CAM_COORD(FreeCamHandle, c.x, c.y, c.z);
			}
		}
		else
		{
			if (FreeCamFeaturedUsed)
			{
				FreeCamFeaturedUsed = false;
				CAM::RENDER_SCRIPT_CAMS(false, true, 10, false, false, false);
				CAM::SET_CAM_ACTIVE(FreeCamHandle, false);
				CAM::DESTROY_CAM(FreeCamHandle, true);
			}
		}
		if (g_Local.noclipv1)
		{
			Ped playerPed = PLAYER::PLAYER_PED_ID();
			Vector3 pos = ENTITY::GET_ENTITY_COORDS(playerPed, false);
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(playerPed, pos.x, pos.y, pos.z, false, false, false);
			if (GetAsyncKeyState(0x57) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 268)) { //w
				float fivef = 0.5f;
				float heading = ENTITY::GET_ENTITY_HEADING(playerPed);
				float xVec = fivef * sin((heading)) * -1.0f;
				float yVec = fivef * cos((heading));

				ENTITY::GET_ENTITY_HEADING(playerPed);
				pos.x -= xVec, pos.y -= yVec;
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(playerPed, pos.x, pos.y, pos.z, false, false, false);
			}
			if (GetAsyncKeyState(0x53) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 269)) {  //s
				float fivef = 0.5f;
				float heading = ENTITY::GET_ENTITY_HEADING(playerPed);
				float xVec = fivef * sin(MenuFunctions::degToRad(heading)) * -1.0f;
				float yVec = fivef * cos(MenuFunctions::degToRad(heading));
				ENTITY::SET_ENTITY_HEADING(playerPed, heading);

				pos.x += xVec, pos.y += yVec;
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(playerPed, pos.x, pos.y, pos.z, false, false, false);
			}
			if (GetAsyncKeyState(0x41) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 266)) {
				float fivef = 0.5f;
				float heading = ENTITY::GET_ENTITY_HEADING(playerPed);

				ENTITY::SET_ENTITY_HEADING(playerPed, heading + 1.0f);
			}
			if (GetAsyncKeyState(0x44) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 271)) {
				float fivef = 0.5f;
				float heading = ENTITY::GET_ENTITY_HEADING(playerPed);

				ENTITY::SET_ENTITY_HEADING(playerPed, heading - 1.0f);
			}
			if (GetAsyncKeyState(VK_SHIFT) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 206)) {
				float heading = ENTITY::GET_ENTITY_HEADING(playerPed);
				ENTITY::SET_ENTITY_HEADING(playerPed, heading);

				pos.z -= 0.1;
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(playerPed, pos.x, pos.y, pos.z, false, false, false);
			}
			if (GetAsyncKeyState(VK_SPACE) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 205)) {
				float heading = ENTITY::GET_ENTITY_HEADING(playerPed);
				ENTITY::SET_ENTITY_HEADING(playerPed, heading);

				pos.z += 0.1;
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(playerPed, pos.x, pos.y, pos.z, false, false, false);
			}
		}
		if (g_Local.noclipv2)
		{

			static const int controls[] = { 21, 32, 33, 34, 35, 36 };
			static float speed = 20.f;
			static float mult = 0.f;

			static bool bLastNoclip = false;

			static Entity prev = -1;
			static Vector3 rot{};


			bool bNoclip = g_Local.noclipv2;

			Entity ent = PLAYER::PLAYER_PED_ID();
			bool bInVehicle = PED::IS_PED_IN_ANY_VEHICLE(ent, true);
			if (bInVehicle) ent = PED::GET_VEHICLE_PED_IS_IN(ent, false);

			// cleanup when changing entities
			if (prev != ent)
			{
				ENTITY::FREEZE_ENTITY_POSITION(prev, false);
				ENTITY::SET_ENTITY_COLLISION(prev, true, true);

				prev = ent;
			}

			if (bNoclip)
			{
				for (int control : controls)
					PAD::DISABLE_CONTROL_ACTION(0, control, true);

				Vector3 vel = { 0.f, 0.f, 0.f };
				float heading = 0.f;

				// Left Shift
				if (GetAsyncKeyState(VK_SPACE))
					vel.z += speed / 2;
				// Left Control
				if (GetAsyncKeyState(VK_SHIFT))
					vel.z -= speed / 2;
				// Forward
				if (PAD::IS_DISABLED_CONTROL_PRESSED(0, 32))
					vel.y += speed;
				// Backward
				if (PAD::IS_DISABLED_CONTROL_PRESSED(0, 33))
					vel.y -= speed;
				// Left
				if (PAD::IS_DISABLED_CONTROL_PRESSED(0, 34))
					vel.x -= speed;
				// Right
				if (PAD::IS_DISABLED_CONTROL_PRESSED(0, 35))
					vel.x += speed;

				rot = CAM::GET_MISC_CAM_ROT(2);
				ENTITY::SET_ENTITY_ROTATION(ent, 0.f, rot.y, rot.z, 2, 0);
				ENTITY::SET_ENTITY_COLLISION(ent, false, false);
				if (vel.x == 0.f && vel.y == 0.f && vel.z == 0.f)
				{
					// freeze entity to prevent drifting when standing still
					ENTITY::FREEZE_ENTITY_POSITION(ent, true);

					mult = 0.f;
				}
				else
				{
					if (mult < 20.f)
						mult += 0.15f;

					ENTITY::FREEZE_ENTITY_POSITION(ent, false);
					Vector3 pos = (ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), 1));
					Vector3 offset = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(ent, vel.x, vel.y, 0.f);
					vel.x = offset.x - pos.x;
					vel.y = offset.y - pos.y;

					ENTITY::SET_ENTITY_VELOCITY(ent, vel.x * mult, vel.y * mult, vel.z * mult);
				}
			}
			else if (bNoclip != bLastNoclip)
			{

				MenuFunctions::requestControlOfEnt(PLAYER::PLAYER_PED_ID());
				ENTITY::FREEZE_ENTITY_POSITION(ent, false);
				ENTITY::SET_ENTITY_COLLISION(ent, true, false);

			}

			bLastNoclip = bNoclip;


		}
		else
		{
			ENTITY::FREEZE_ENTITY_POSITION(PLAYER::PLAYER_PED_ID(), false);
			ENTITY::SET_ENTITY_COLLISION(PLAYER::PLAYER_PED_ID(), true, false);
			ENTITY::FREEZE_ENTITY_POSITION(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), true), false);
			ENTITY::SET_ENTITY_COLLISION(PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), true), true, false);
		}
		if (g_Local.noragdoll)
		{
			PED::SET_PED_CAN_RAGDOLL(PLAYER::PLAYER_PED_ID(), false);
			PED::SET_PED_CAN_RAGDOLL_FROM_PLAYER_IMPACT(PLAYER::PLAYER_PED_ID(), false);
			PED::SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE(PLAYER::PLAYER_PED_ID(), false);
			PLAYER::GIVE_PLAYER_RAGDOLL_CONTROL(PLAYER::PLAYER_ID(), false);
			PED::SET_PED_RAGDOLL_ON_COLLISION(PLAYER::PLAYER_PED_ID(), false);
		}
		if (g_Local.pengci) {
			PED::SET_PED_CAN_RAGDOLL(PLAYER::PLAYER_PED_ID(), true);
			PED::SET_PED_CAN_RAGDOLL_FROM_PLAYER_IMPACT(PLAYER::PLAYER_PED_ID(), true);
			PED::SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE(PLAYER::PLAYER_PED_ID(), true);
			PLAYER::GIVE_PLAYER_RAGDOLL_CONTROL(PLAYER::PLAYER_ID(), true);
			PED::SET_PED_RAGDOLL_ON_COLLISION(PLAYER::PLAYER_PED_ID(), true);
		}
		if (g_Local.zhuanquan && !PED::IS_PED_IN_ANY_VEHICLE(PLAYER::PLAYER_PED_ID(), false))
		{
			ENTITY::SET_ENTITY_HEADING(PLAYER::PLAYER_PED_ID(), ENTITY::_GET_ENTITY_PHYSICS_HEADING(PLAYER::PLAYER_PED_ID()) + 5);
		}
		if (g_Local.superjump)
		{
			MISC::SET_SUPER_JUMP_THIS_FRAME(PLAYER::PLAYER_PED_ID());
			MISC::SET_SUPER_JUMP_THIS_FRAME(PLAYER::PLAYER_ID());
		}
		if (g_Local.firebreath)
		{
			float XPos = 0.02, YPos = 0.2, ZPos = 0.0, XOff = 90.0, YOff = -100.0, ZOff = 90.0;

			STREAMING::REQUEST_NAMED_PTFX_ASSET("core");
			GRAPHICS::USE_PARTICLE_FX_ASSET("core");
			if ((timeGetTime() - TimePD) > 200)
			{
				int ptfx = GRAPHICS::START_NETWORKED_PARTICLE_FX_NON_LOOPED_ON_PED_BONE("ent_sht_flame", PLAYER::PLAYER_PED_ID(), XPos, YPos, ZPos,
					XOff, YOff, ZOff, SKEL_Head, 1, 1, 1, 1);
				TimePD = timeGetTime();
			}
			STREAMING::REMOVE_PTFX_ASSET();
		}
		g_Local.neverwanted ? PLAYER::CLEAR_PLAYER_WANTED_LEVEL(PLAYER::PLAYER_ID()) : NULL;
		if (g_Local.JibBool)
		{
			STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");// FX Attachment
			GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry2");
			GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_clown_appears", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 28422, 0.2f, 0, 0, 0);
			STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");// FX Attachment
			GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry2");
			GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_clown_appears", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 60309, 0.2f, 0, 0, 0);
			STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");// FX Attachment
			GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry2");
			GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_clown_appears", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 31086, 0.3f, 0, 0, 0);
			STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");// FX Attachment
			GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry2");
			GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_clown_appears", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 52301, 0.2f, 0, 0, 0);
			STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");// FX Attachment
			GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry2");
		}
		if (g_Local.JiBool)
		{
			STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");// FX Attachment
			GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry2");
			GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("muz_clown", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 28422, 0.3f, 0, 0, 0);
			STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");// FX Attachment
			GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry2");
			GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("muz_clown", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 60309, 0.3f, 0, 0, 0);
			STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");// FX Attachment
			GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry2");
			GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("muz_clown", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 31086, 0.4f, 0, 0, 0);
			STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");// FX Attachment
			GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry2");
			GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("muz_clown", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 52301, 0.3f, 0, 0, 0);
			STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");// FX Attachment
			GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("muz_clown");
		}
		if (g_Local.gglow)
		{
			STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry1");// FX Attachment
			GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry1");
			GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_alien_teleport", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 28422, 0.1f, 0, 0, 0);
			STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry1");// FX Attachment
			GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry1");
			GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_alien_teleport", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 60309, 0.1f, 0, 0, 0);
			STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry1");// FX Attachment
			GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry1");
			GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_alien_teleport", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 31086, 0.2f, 0, 0, 0);
			STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry1");// FX Attachment
			GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry1");
			GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_alien_teleport", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 52301, 0.1f, 0, 0, 0);
			STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry1");// FX Attachment
			GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_rcbarry1");
		}
		if (g_Local.chixuranshao)
		{
			STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_agencyheist");// FX Attachment
			GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_agencyheist");
			GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_fbi_dd_breach_smoke", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 0, 0.5f, 0, 0, 0);
			STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_agencyheist");// FX Attachment
			GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_agencyheist");
			GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_fbi_dd_breach_smoke", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 28422, 0.1f, 0, 0, 0);
			STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_agencyheist");// FX Attachment
			GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_agencyheist");
			GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_fbi_dd_breach_smoke", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 60309, 0.1f, 0, 0, 0);
			STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_agencyheist");// FX Attachment
			GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_agencyheist");
			GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_fbi_dd_breach_smoke", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 31086, 0.2f, 0, 0, 0);
			STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_agencyheist");// FX Attachment
			GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_agencyheist");
			GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_fbi_dd_breach_smoke", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 52301, 0.1f, 0, 0, 0);
			STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_agencyheist");// FX Attachment
			GRAPHICS::_USE_PARTICLE_FX_ASSET_NEXT_CALL("scr_agencyheist");
			GRAPHICS::_START_PARTICLE_FX_NON_LOOPED_ON_PED_BONE_2("scr_fbi_dd_breach_smoke", PLAYER::PLAYER_PED_ID(), 0, 0, 0, 0, 0, 0, 14201, 0.1f, 0, 0, 0);
		}
		if (g_Local.superman)
		{
			Ped playerPed = PLAYER::PLAYER_PED_ID();
			if (GetAsyncKeyState(VK_SPACE) || PAD::IS_DISABLED_CONTROL_PRESSED(2, ControlFrontendAccept))
			{
				ENTITY::APPLY_FORCE_TO_ENTITY(playerPed, 3, 0.f, 0.f, 2.5f, 0.f, 0.f, 0.f, 0, true, false, true, false, false);
				WEAPON::GIVE_DELAYED_WEAPON_TO_PED(playerPed, 0xFBAB5776, 0, true);
				WEAPON::SET_CURRENT_PED_WEAPON(playerPed, 0xFBAB5776, true);
			}
			if (PED::IS_PED_RUNNING_RAGDOLL_TASK(playerPed) && PED::IS_PED_FALLING(playerPed) && PED::IS_PED_IN_PARACHUTE_FREE_FALL(playerPed))
			{
				WEAPON::GIVE_DELAYED_WEAPON_TO_PED(playerPed, 0xFBAB5776, 0, true);
				WEAPON::SET_CURRENT_PED_WEAPON(playerPed, 0xFBAB5776, true);
				if (GetAsyncKeyState(VK_KEY_W))
				{
					ENTITY::APPLY_FORCE_TO_ENTITY(playerPed, 3, 0.f, 2.5f, 0.f, 0.f, 0.f, 0.f, 0, true, false, true, false, false);
				}
				if (GetAsyncKeyState(VK_KEY_S))
				{
					ENTITY::APPLY_FORCE_TO_ENTITY(playerPed, 3, 0.f, -2.5f, 0.f, 0.f, 0.f, 0.f, 0, true, false, true, false, false);
				}
				if (GetAsyncKeyState(VK_SHIFT))
				{
					ENTITY::APPLY_FORCE_TO_ENTITY(playerPed, 3, 0.f, 0.f, -2.5f, 0.f, 0.f, 0.f, 0, true, false, true, false, false);
				}
			}
		}
		if (g_Local.walkonwater)
		{
			Player player = PLAYER::PLAYER_ID();
			Ped playerPed = PLAYER::PLAYER_PED_ID();
			DWORD model = ENTITY::GET_ENTITY_MODEL(PLAYER::PLAYER_PED_ID());
			Vector3 pos = ENTITY::GET_ENTITY_COORDS(playerPed, 0);
			float height = 0;
			WATER::_SET_CURRENT_INTENSITY(height);
			Object container = OBJECT::GET_CLOSEST_OBJECT_OF_TYPE(pos.x, pos.y, pos.z, 4.0, MISC::GET_HASH_KEY("prop_container_ld2"), 0, 0, 1);
			if (ENTITY::DOES_ENTITY_EXIST(container) && height > -50.0f)
			{
				Vector3 pRot = ENTITY::GET_ENTITY_ROTATION(playerPed, 0);
				MenuFunctions::requestControlOfEnt(container);
				ENTITY::SET_ENTITY_COORDS(container, pos.x, pos.y, height - 1.5f, 0, 0, 0, 1);
				ENTITY::SET_ENTITY_ROTATION(container, 0, 0, pRot.z, 0, 1);
				Vector3 containerCoords = ENTITY::GET_ENTITY_COORDS(container, 1);
				if (pos.z < containerCoords.z)
				{
					if (!PED::IS_PED_IN_ANY_VEHICLE(playerPed, 0))
					{
						ENTITY::SET_ENTITY_COORDS(playerPed, pos.x, pos.y, containerCoords.z + 2.0f, 0, 0, 0, 1);
					}
					else
					{
						MenuFunctions::requestControlOfEnt(playerPed);
						ENTITY::SET_ENTITY_COORDS(pos.x, pos.y, pos.z, containerCoords.z + 2.0f, 0, 0, 0, 1);
					}
				}
			}
			else
			{
				Hash model = MISC::GET_HASH_KEY("prop_container_ld2");
				STREAMING::REQUEST_MODEL(model);
				while (!STREAMING::HAS_MODEL_LOADED(model))WAIT(0);
				container = OBJECT::CREATE_OBJECT(model, pos.x, pos.y, pos.z, 1, 1, 0);
				MenuFunctions::requestControlOfEnt(container);
				ENTITY::FREEZE_ENTITY_POSITION(container, 1);
				ENTITY::SET_ENTITY_ALPHA(container, 0, 1);
				ENTITY::SET_ENTITY_VISIBLE(container, false, 0);
			}
		}
	}
	void TeleportLoop()
	{
		if (g_Teleport.autoteleport)
		{
			Vector3 coords = MenuFunctions::get_blip_marker();
			if (coords.x == 0 && coords.y == 0)
			{
				return;
			}
			Entity e = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID());
			if (PED::IS_PED_IN_ANY_VEHICLE(e, 0))
			{
				e = PED::GET_VEHICLE_PED_IS_USING(e);
			}
			bool groundFound = false;
			static float groundCheckHeight[] =
			{ 100.0, 150.0, 50.0, 0.0, 200.0, 250.0, 300.0, 350.0, 400.0, 450.0, 500.0, 550.0, 600.0, 650.0, 700.0, 750.0, 800.0 };
			for (int i = 0; i < sizeof(groundCheckHeight) / sizeof(float); i++)
			{
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(e, coords.x, coords.y, groundCheckHeight[i], 0, 0, 1);
				WAIT(150);
				if (MISC::GET_GROUND_Z_FOR_3D_COORD(coords.x, coords.y, groundCheckHeight[i], &coords.z, 0))
				{
					groundFound = true;
					coords.z += 3.0;
					break;
				}
			}
			// if ground not found then set Z in air and give player a parachute
			if (!groundFound)
			{
				coords.z = 1000.0;
				WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), 0xFBAB5776, 1, 0);
			}
			//do it
			MenuFunctions::teleport_to_coords(e, coords);
			HUD::SET_WAYPOINT_OFF();
		}
	}
	void VehicleLoop()
	{
		if (g_Vehicle.xianxiatichu)
		{
			globalHandle(4533757).As<bool>() = true;
		}
		if (g_Vehicle.vehiclegodmode)
		{
			Ped playerPed = PLAYER::PLAYER_PED_ID();
			Vehicle vehicle = PED::GET_VEHICLE_PED_IS_USING(playerPed);
			ENTITY::SET_ENTITY_INVINCIBLE(vehicle, g_Vehicle.vehiclegodmode);
			ENTITY::SET_ENTITY_PROOFS(vehicle, g_Vehicle.vehiclegodmode, g_Vehicle.vehiclegodmode, g_Vehicle.vehiclegodmode, g_Vehicle.vehiclegodmode, g_Vehicle.vehiclegodmode, g_Vehicle.vehiclegodmode, g_Vehicle.vehiclegodmode, g_Vehicle.vehiclegodmode);
			VEHICLE::SET_VEHICLE_STRONG(vehicle, g_Vehicle.vehiclegodmode);
			VEHICLE::SET_VEHICLE_CAN_BREAK(vehicle, !g_Vehicle.vehiclegodmode);
			VEHICLE::SET_VEHICLE_ENGINE_CAN_DEGRADE(vehicle, !g_Vehicle.vehiclegodmode);
			VEHICLE::SET_VEHICLE_CAN_BE_VISIBLY_DAMAGED(vehicle, !g_Vehicle.vehiclegodmode);
		}
		if (g_Vehicle.driveonwater)
		{
			Player player = PLAYER::PLAYER_ID();
			Ped playerPed = PLAYER::PLAYER_PED_ID();
			Vehicle veh = PED::GET_VEHICLE_PED_IS_IN(playerPed, 0);
			DWORD model = ENTITY::GET_ENTITY_MODEL(veh);
			Vector3 pos = ENTITY::GET_ENTITY_COORDS(playerPed, 0);
			float height = 0;
			WATER::_SET_CURRENT_INTENSITY(height);
			if ((!(VEHICLE::IS_THIS_MODEL_A_PLANE(ENTITY::GET_ENTITY_MODEL(veh)))) && WATER::GET_WATER_HEIGHT_NO_WAVES(pos.x, pos.y, pos.z, &height))
			{
				Object container = OBJECT::GET_CLOSEST_OBJECT_OF_TYPE(pos.x, pos.y, pos.z, 4.0, MISC::GET_HASH_KEY("prop_container_ld2"), 0, 0, 1);
				if (ENTITY::DOES_ENTITY_EXIST(container) && height > -50.0f)
				{
					Vector3 pRot = ENTITY::GET_ENTITY_ROTATION(playerPed, 0);
					MenuFunctions::requestControlOfEnt(container);
					ENTITY::SET_ENTITY_COORDS(container, pos.x, pos.y, height - 1.5f, 0, 0, 0, 1);
					ENTITY::SET_ENTITY_ROTATION(container, 0, 0, pRot.z, 0, 1);
					Vector3 containerCoords = ENTITY::GET_ENTITY_COORDS(container, 1);
					if (pos.z < containerCoords.z)
					{
						if (!PED::IS_PED_IN_ANY_VEHICLE(playerPed, 0))
						{
							ENTITY::SET_ENTITY_COORDS(playerPed, pos.x, pos.y, containerCoords.z + 2.0f, 0, 0, 0, 1);
						}
						else
						{
							MenuFunctions::requestControlOfEnt(veh);
							Vector3 vehc = ENTITY::GET_ENTITY_COORDS(veh, 1);
							ENTITY::SET_ENTITY_COORDS(veh, vehc.x, vehc.y, containerCoords.z + 2.0f, 0, 0, 0, 1);
						}
					}
				}
				else
				{
					Hash model = MISC::GET_HASH_KEY("prop_container_ld2");
					STREAMING::REQUEST_MODEL(model);
					while (!STREAMING::HAS_MODEL_LOADED(model))WAIT(0);
					container = OBJECT::CREATE_OBJECT(model, pos.x, pos.y, pos.z, 1, 1, 0);
					MenuFunctions::requestControlOfEnt(container);
					ENTITY::FREEZE_ENTITY_POSITION(container, 1);
					ENTITY::SET_ENTITY_ALPHA(container, 0, 1);
					ENTITY::SET_ENTITY_VISIBLE(container, false, 0);
				}
			}
			else
			{
				Object container = OBJECT::GET_CLOSEST_OBJECT_OF_TYPE(pos.x, pos.y, pos.z, 4.0, MISC::GET_HASH_KEY("prop_container_ld2"), 0, 0, 1);
				if (ENTITY::DOES_ENTITY_EXIST(container))
				{
					MenuFunctions::requestControlOfEnt(container);
					ENTITY::SET_ENTITY_COORDS(container, 0, 0, -1000.0f, 0, 0, 0, 1);
					WAIT(10);
					ENTITY::SET_ENTITY_AS_NO_LONGER_NEEDED(&container);
					ENTITY::DELETE_ENTITY(&container);
					WATER::_RESET_CURRENT_INTENSITY();
				}
			}
		}
		if (g_Vehicle.vehicleboost)
		{
			if (PLAYER::IS_PLAYER_PRESSING_HORN(PLAYER::PLAYER_ID()))
			{
				Vehicle Veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID()), false);
				NETWORK::NETWORK_REQUEST_CONTROL_OF_ENTITY(Veh);
				if (NETWORK::NETWORK_HAS_CONTROL_OF_ENTITY(Veh))
				{
					VEHICLE::SET_VEHICLE_FORWARD_SPEED(Veh, 50);
				}
			}
		}
		if (g_Vehicle.rainbowcar)
		{
			int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
			VEHICLE::SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(VehID, MISC::GET_RANDOM_INT_IN_RANGE(0, 255), MISC::GET_RANDOM_INT_IN_RANGE(0, 255), MISC::GET_RANDOM_INT_IN_RANGE(0, 255));
			VEHICLE::SET_VEHICLE_CUSTOM_SECONDARY_COLOUR(VehID, MISC::GET_RANDOM_INT_IN_RANGE(0, 255), MISC::GET_RANDOM_INT_IN_RANGE(0, 255), MISC::GET_RANDOM_INT_IN_RANGE(0, 255));
			VEHICLE::SET_VEHICLE_TYRE_SMOKE_COLOR(VehID, MISC::GET_RANDOM_INT_IN_RANGE(0, 255), MISC::GET_RANDOM_INT_IN_RANGE(0, 255), MISC::GET_RANDOM_INT_IN_RANGE(0, 255));
			VEHICLE::_IS_VEHICLE_NEON_LIGHT_ENABLED(VehID, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 0, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 1, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 2, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 3, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 4, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 5, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 6, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 7, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHTS_COLOUR(VehID, MISC::GET_RANDOM_INT_IN_RANGE(0, 255), MISC::GET_RANDOM_INT_IN_RANGE(0, 255), MISC::GET_RANDOM_INT_IN_RANGE(0, 255));
		}
		if (g_Vehicle.enginealwayson)
		{
			VEHICLE::SET_VEHICLE_ENGINE_ON(PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID()), true, true, false);
			VEHICLE::SET_VEHICLE_LIGHTS(PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID()), 0);
			VEHICLE::_SET_VEHICLE_LIGHTS_MODE(PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID()), 2);
		}
		if (g_Vehicle.fixcarloop)
		{
			Vehicle veh = PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID());
			if (ENTITY::DOES_ENTITY_EXIST(veh))
			{
				VEHICLE::SET_VEHICLE_FIXED(veh);
				VEHICLE::SET_VEHICLE_DEFORMATION_FIXED(veh);
				VEHICLE::SET_VEHICLE_DIRT_LEVEL(veh, 0);
				VEHICLE::SET_VEHICLE_ENGINE_ON(veh, true, true, true);
			}
		}
		if (g_Vehicle.rainbowsmoke)
		{
			int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
			VEHICLE::SET_VEHICLE_TYRE_SMOKE_COLOR(VehID, MISC::GET_RANDOM_INT_IN_RANGE(0, 255), MISC::GET_RANDOM_INT_IN_RANGE(0, 255), MISC::GET_RANDOM_INT_IN_RANGE(0, 255));
		}
		if (g_Vehicle.rainbowneno)
		{
			int VehID = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
			VEHICLE::_IS_VEHICLE_NEON_LIGHT_ENABLED(VehID, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 0, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 1, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 2, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 3, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 4, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 5, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 6, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHT_ENABLED(VehID, 7, 1);
			VEHICLE::_SET_VEHICLE_NEON_LIGHTS_COLOUR(VehID, MISC::GET_RANDOM_INT_IN_RANGE(0, 255), MISC::GET_RANDOM_INT_IN_RANGE(0, 255), MISC::GET_RANDOM_INT_IN_RANGE(0, 255));
		}
		if (g_Vehicle.flycar)
		{
			int veh = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
			if (veh)
			{
				if (VEHICLE::IS_THIS_MODEL_A_CAR(ENTITY::GET_ENTITY_MODEL(veh)) || VEHICLE::IS_THIS_MODEL_A_BOAT(ENTITY::GET_ENTITY_MODEL(veh)))
				{
					if (PAD::IS_DISABLED_CONTROL_PRESSED(2, INPUT_VEH_FLY_THROTTLE_UP))
					{
						float Speed = ENTITY::GET_ENTITY_SPEED(veh) + 0.4;
						VEHICLE::SET_VEHICLE_FORWARD_SPEED(veh, Speed);
					}

					if (PAD::IS_DISABLED_CONTROL_PRESSED(2, INPUT_VEH_FLY_YAW_LEFT) && (!VEHICLE::IS_VEHICLE_ON_ALL_WHEELS(veh)))
					{
						Vector3 Rot = ENTITY::GET_ENTITY_ROTATION(veh, 2);
						Rot.z = Rot.z + 1.0;
						ENTITY::SET_ENTITY_ROTATION(veh, Rot.x, Rot.y, Rot.z, 2, 1);
					}

					if (PAD::IS_DISABLED_CONTROL_PRESSED(2, INPUT_VEH_FLY_YAW_RIGHT) && (!VEHICLE::IS_VEHICLE_ON_ALL_WHEELS(veh)))
					{
						Vector3 Rot = ENTITY::GET_ENTITY_ROTATION(veh, 2);
						Rot.z = Rot.z - 1.0;
						ENTITY::SET_ENTITY_ROTATION(veh, Rot.x, Rot.y, Rot.z, 2, 1);
					}
				}
			}
		}
		if (g_Vehicle.flycarv2)
		{
			Vehicle veh = PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID());
			Vector3 pos = ENTITY::GET_ENTITY_COORDS(veh, true);
			ENTITY::SET_ENTITY_COORDS_NO_OFFSET(veh, pos.x, pos.y, pos.z, false, false, false);
			if (GetAsyncKeyState(0x57) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 268)) {
				float fivef = 0.5f;
				float heading = ENTITY::GET_ENTITY_HEADING(veh);
				float xVec = fivef * sin((heading)) * -1.0f;
				float yVec = fivef * cos((heading));

				ENTITY::GET_ENTITY_HEADING(veh);
				pos.x -= xVec, pos.y -= yVec;
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(veh, pos.x, pos.y, pos.z, false, false, false);
			}
			if (GetAsyncKeyState(0x53) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 269)) {
				float fivef = 0.5f;
				float heading = ENTITY::GET_ENTITY_HEADING(veh);
				float xVec = fivef * sin(MenuFunctions::degToRad(heading)) * -1.0f;
				float yVec = fivef * cos(MenuFunctions::degToRad(heading));
				ENTITY::SET_ENTITY_HEADING(veh, heading);

				pos.x += xVec, pos.y += yVec;
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(veh, pos.x, pos.y, pos.z, false, false, false);
			}
			if (GetAsyncKeyState(0x41) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 266)) {
				float fivef = 0.5f;
				float heading = ENTITY::GET_ENTITY_HEADING(veh);

				ENTITY::SET_ENTITY_HEADING(veh, heading + 1.0f);
			}
			if (GetAsyncKeyState(0x44) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 271)) {
				float fivef = 0.5f;
				float heading = ENTITY::GET_ENTITY_HEADING(veh);

				ENTITY::SET_ENTITY_HEADING(veh, heading - 1.0f);
			}
			if (GetAsyncKeyState(VK_SHIFT) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 206)) {
				float heading = ENTITY::GET_ENTITY_HEADING(veh);
				ENTITY::SET_ENTITY_HEADING(veh, heading);

				pos.z -= 0.1;
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(veh, pos.x, pos.y, pos.z, false, false, false);
			}
			if (GetAsyncKeyState(VK_SPACE) || PAD::IS_DISABLED_CONTROL_JUST_PRESSED(2, 205)) {
				float heading = ENTITY::GET_ENTITY_HEADING(veh);
				ENTITY::SET_ENTITY_HEADING(veh, heading);

				pos.z += 0.1;
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(veh, pos.x, pos.y, pos.z, false, false, false);
			}
		}
		if (g_Vehicle.invisiblecar)
		{
			ENTITY::SET_ENTITY_VISIBLE(PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID())), false, 0);
		}
		else
		{
			ENTITY::SET_ENTITY_VISIBLE(PED::GET_VEHICLE_PED_IS_USING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID())), true, 0);
		}
		if (g_Vehicle.bulletProofTyres)
		{
			VEHICLE::SET_VEHICLE_WHEELS_CAN_BREAK(PED::GET_VEHICLE_PED_IS_IN(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_ID()), false), !g_Vehicle.bulletProofTyres);
		}
	}
	void WeaponLoop()
	{
		if (g_Weapon.explosiveammo)
		{
			if (ENTITY::DOES_ENTITY_EXIST(PLAYER::PLAYER_PED_ID()) && PED::IS_PED_SHOOTING_IN_AREA)
			{
				Vector3 iCoord;
				if (WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(PLAYER::PLAYER_PED_ID(), &iCoord))
				{
					FIRE::ADD_EXPLOSION(iCoord.x, iCoord.y, iCoord.z, 4, 100, true, false, 0, 0);
				}
			}
		}
		if (g_Weapon.rapidfire)
		{
			Player playerPed = PLAYER::PLAYER_PED_ID();
			if (!PED::IS_PED_IN_ANY_VEHICLE(PLAYER::PLAYER_PED_ID(), 1))
			{
				PLAYER::DISABLE_PLAYER_FIRING(PLAYER::PLAYER_PED_ID(), 1);
				Vector3 MISCCam = CAM::_GET_MISC_CAM_COORDS();
				Vector3 MISCCamRot = CAM::GET_MISC_CAM_ROT(0);
				Vector3 MISCCamDirection = MenuFunctions::RotationToDirection(MISCCamRot);
				Vector3 startCoords = MenuFunctions::addVector(MISCCam, (MenuFunctions::multiplyVector(MISCCamDirection, 1.0f)));
				Vector3 endCoords = MenuFunctions::addVector(startCoords, MenuFunctions::multiplyVector(MISCCamDirection, 500.0f));
				Hash weaponhash;
				WEAPON::GET_CURRENT_PED_WEAPON(playerPed, &weaponhash, 1);
				if (PAD::IS_CONTROL_PRESSED(2, 208) || (GetKeyState(VK_LBUTTON) & 0x8000))
				{
					MISC::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(startCoords.x, startCoords.y, startCoords.z, endCoords.x, endCoords.y, endCoords.z, 50, 1, weaponhash, playerPed, 1, 1, 0xbf800000);
				}
			}
		}
		if (g_Weapon.unlimitedammo)
		{
			WEAPON::SET_PED_INFINITE_AMMO_CLIP(PLAYER::PLAYER_PED_ID(), true);
		}
		if (g_Weapon.oneshoot)
		{
			Pickup temp = 7;
			PLAYER::SET_PLAYER_WEAPON_DAMAGE_MODIFIER(PLAYER::PLAYER_ID(), &temp);
			PLAYER::SET_PLAYER_MELEE_WEAPON_DAMAGE_MODIFIER(PLAYER::PLAYER_ID(), 7.0f);
		}
		else
		{
			Pickup temp = 1;
			PLAYER::SET_PLAYER_WEAPON_DAMAGE_MODIFIER(PLAYER::PLAYER_ID(), &temp);
			PLAYER::SET_PLAYER_MELEE_WEAPON_DAMAGE_MODIFIER(PLAYER::PLAYER_ID(), 1.0f);
		}
		if (g_Weapon.deatheye)
		{
			GRAPHICS::ANIMPOSTFX_PLAY("HeistLocate", 0, false);
			MISC::SET_TIME_SCALE(0.35f);
			PLAYER::SET_PLAYER_WEAPON_DAMAGE_MODIFIER(PLAYER::PLAYER_ID(), 7.0f);
		}
		else { GRAPHICS::ANIMPOSTFX_STOP("HeistLocate"); MISC::SET_TIME_SCALE(1.0f); }
		if (g_Weapon.kickgun)
		{
			if (MenuFunctions::is_ped_shooting(PLAYER::PLAYER_PED_ID())) {
				Vector3 coords;
				if (WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(PLAYER::PLAYER_PED_ID(), &coords))
				{
					STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");
					GRAPHICS::USE_PARTICLE_FX_ASSET("scr_rcbarry2");
					GRAPHICS::START_PARTICLE_FX_NON_LOOPED_AT_COORD("scr_clown_death", coords.x, coords.y, coords.z, 0.f, 0.f, 0.f, 1.f, 0, 0, 0);
				}
			}
		}
		if (g_Weapon.xiaochouchuxian)
		{
			if (MenuFunctions::is_ped_shooting(PLAYER::PLAYER_PED_ID())) {
				Vector3 coords;
				if (WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(PLAYER::PLAYER_PED_ID(), &coords))
				{
					STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_agencyheistb");
					GRAPHICS::USE_PARTICLE_FX_ASSET("scr_agencyheistb");
					GRAPHICS::START_PARTICLE_FX_NON_LOOPED_AT_COORD("scr_agency3b_elec_box", coords.x, coords.y, coords.z, 0.f, 0.f, 0.f, 1.f, 0, 0, 0);
				}
			}
		}
		if (g_Weapon.xingxing)
		{
			if (MenuFunctions::is_ped_shooting(PLAYER::PLAYER_PED_ID())) {
				Vector3 coords;
				if (WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(PLAYER::PLAYER_PED_ID(), &coords))
				{
					STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry2");
					GRAPHICS::USE_PARTICLE_FX_ASSET("scr_rcbarry2");
					GRAPHICS::START_PARTICLE_FX_NON_LOOPED_AT_COORD("scr_clown_appears", coords.x, coords.y, coords.z, 0.f, 0.f, 0.f, 1.f, 0, 0, 0);
				}
			}
		}
		if (g_Weapon.shuihuafeijian)
		{
			if (MenuFunctions::is_ped_shooting(PLAYER::PLAYER_PED_ID())) {
				Vector3 coords;
				if (WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(PLAYER::PLAYER_PED_ID(), &coords))
				{
					STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_fbi5a");
					GRAPHICS::USE_PARTICLE_FX_ASSET("scr_fbi5a");
					GRAPHICS::START_PARTICLE_FX_NON_LOOPED_AT_COORD("scr_fbi5_ped_water_splash", coords.x, coords.y, coords.z, 0.f, 0.f, 0.f, 1.f, 0, 0, 0);
				}
			}
		}
		if (g_Weapon.kachechongzhuang)
		{
			if (MenuFunctions::is_ped_shooting(PLAYER::PLAYER_PED_ID())) {
				Vector3 coords;
				if (WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(PLAYER::PLAYER_PED_ID(), &coords))
				{
					STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_fbi4");
					GRAPHICS::USE_PARTICLE_FX_ASSET("scr_fbi4");
					GRAPHICS::START_PARTICLE_FX_NON_LOOPED_AT_COORD("scr_fbi4_trucks_crash", coords.x, coords.y, coords.z, 0.f, 0.f, 0.f, 1.f, 0, 0, 0);
				}
			}
		}
		if (g_Weapon.waixingrenwajie)
		{
			if (MenuFunctions::is_ped_shooting(PLAYER::PLAYER_PED_ID())) {
				Vector3 coords;
				if (WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(PLAYER::PLAYER_PED_ID(), &coords))
				{
					STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry1");
					GRAPHICS::USE_PARTICLE_FX_ASSET("scr_rcbarry1");
					GRAPHICS::START_PARTICLE_FX_NON_LOOPED_AT_COORD("scr_alien_disintegrate", coords.x, coords.y, coords.z, 0.f, 0.f, 0.f, 1.f, 0, 0, 0);
				}
			}
		}
		if (g_Weapon.waixingrenchuansong)
		{
			if (MenuFunctions::is_ped_shooting(PLAYER::PLAYER_PED_ID())) {
				Vector3 coords;
				if (WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(PLAYER::PLAYER_PED_ID(), &coords))
				{
					STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_rcbarry1");
					GRAPHICS::USE_PARTICLE_FX_ASSET("scr_rcbarry1");
					GRAPHICS::START_PARTICLE_FX_NON_LOOPED_AT_COORD("scr_alien_teleport", coords.x, coords.y, coords.z, 0.f, 0.f, 0.f, 1.f, 0, 0, 0);
				}
			}
		}
		if (g_Weapon.jujiyingxiang)
		{
			if (MenuFunctions::is_ped_shooting(PLAYER::PLAYER_PED_ID())) {
				Vector3 coords;
				if (WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(PLAYER::PLAYER_PED_ID(), &coords))
				{
					STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_martin1");
					GRAPHICS::USE_PARTICLE_FX_ASSET("scr_martin1");
					GRAPHICS::START_PARTICLE_FX_NON_LOOPED_AT_COORD("scr_sol1_sniper_impact", coords.x, coords.y, coords.z, 0.f, 0.f, 0.f, 1.f, 0, 0, 0);
				}
			}
		}
		if (g_Weapon.yanhua)
		{
			if (MenuFunctions::is_ped_shooting(PLAYER::PLAYER_PED_ID())) {
				Vector3 coords;
				if (WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(PLAYER::PLAYER_PED_ID(), &coords))
				{
					STREAMING::REQUEST_NAMED_PTFX_ASSET("proj_xmas_firework");
					GRAPHICS::USE_PARTICLE_FX_ASSET("proj_xmas_firework");
					GRAPHICS::START_PARTICLE_FX_NON_LOOPED_AT_COORD("scr_firework_xmas_burst_rgw", coords.x, coords.y, coords.z, 0.f, 0.f, 0.f, 1.f, 0, 0, 0);
				}
			}
		}
		if (g_Weapon.jujiyingxiang)
		{
			if (MenuFunctions::is_ped_shooting(PLAYER::PLAYER_PED_ID())) {
				Vector3 coords;
				if (WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(PLAYER::PLAYER_PED_ID(), &coords))
				{
					STREAMING::REQUEST_NAMED_PTFX_ASSET("scr_martin1");
					GRAPHICS::USE_PARTICLE_FX_ASSET("scr_martin1");
					GRAPHICS::START_PARTICLE_FX_NON_LOOPED_AT_COORD("scr_sol1_sniper_impact", coords.x, coords.y, coords.z, 0.f, 0.f, 0.f, 1.f, 0, 0, 0);
				}
			}
		}
		if (g_Weapon.zimiaonpc)
		{
			const int ElementAmount = 15;
			const int ArrSize = ElementAmount * 2 + 2;
			Ped* peds = new Ped[ArrSize];
			peds[0] = ElementAmount;
			int PedFound = PED::GET_PED_NEARBY_PEDS(PLAYER::PLAYER_PED_ID(), peds, -1);
			for (int i = 0; i < PedFound; i++)
			{
				int OffsetID = i * 2 + 2;
				if (ENTITY::DOES_ENTITY_EXIST(peds[OffsetID]) && PLAYER::PLAYER_PED_ID() != peds[OffsetID])
				{
					if (GetAsyncKeyState(VK_RBUTTON))
					{
						Vector3 targetPos = ENTITY::GET_ENTITY_COORDS(peds[OffsetID], true);
						float screenX, screenY;
						BOOL onScreen = GRAPHICS::GET_SCREEN_COORD_FROM_WORLD_COORD(targetPos.x, targetPos.y, targetPos.z, &screenX, &screenY);
						Player playerPed = PLAYER::PLAYER_PED_ID();
						if (ENTITY::IS_ENTITY_VISIBLE(peds[OffsetID]) && onScreen)
						{
							if (ENTITY::HAS_ENTITY_CLEAR_LOS_TO_ENTITY(peds[OffsetID], peds[OffsetID], 17))
							{
								Vector3 targetCoords = PED::GET_PED_BONE_COORDS(peds[OffsetID], 31086, 0, 0, 0);
								PED::SET_PED_SHOOTS_AT_COORD(playerPed, targetCoords.x, targetCoords.y, targetCoords.z, 1);
							}
						}
					}
				}
			}
			delete[] peds;
		}
		if (g_Weapon.zimiaowanjia)
		{
			Ped PedID = PLAYER::PLAYER_PED_ID();
			Player player = PLAYER::PLAYER_ID();

			for (int i = 0; i < 32; i++)
			{
				if (i != player)
				{
					if (GetAsyncKeyState(VK_RBUTTON))
					{
						Ped targetPed = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
						Vector3 targetPos = ENTITY::GET_ENTITY_COORDS(targetPed, true);
						BOOL exists = ENTITY::DOES_ENTITY_EXIST(targetPed);
						BOOL dead = PLAYER::IS_PLAYER_DEAD(targetPed);

						if (exists && !dead)
						{
							float screenX, screenY;
							BOOL onScreen = GRAPHICS::GET_SCREEN_COORD_FROM_WORLD_COORD(targetPos.x, targetPos.y, targetPos.z, &screenX, &screenY);
							if (ENTITY::IS_ENTITY_VISIBLE(targetPed) && onScreen)
							{
								if (ENTITY::HAS_ENTITY_CLEAR_LOS_TO_ENTITY(PedID, targetPed, 17))
								{
									Vector3 targetCoords = PED::GET_PED_BONE_COORDS(targetPed, 31086, 0, 0, 0);
									PED::SET_PED_SHOOTS_AT_COORD(PedID, targetCoords.x, targetCoords.y, targetCoords.z, 1);
								}
							}
						}
					}
				}
			}
		}
		if (g_Weapon.tankeqiang)
		{
			BOOL bPlayerExists = ENTITY::DOES_ENTITY_EXIST(PLAYER::PLAYER_PED_ID());
			Ped playerPed = PLAYER::PLAYER_PED_ID();
			FLOAT heading = ENTITY::GET_ENTITY_HEADING(playerPed);
			STREAMING::REQUEST_MODEL(0x2EA68690);
			Vector3 rot = CAM::GET_MISC_CAM_ROT(0);
			Vector3 dir = MenuFunctions::rot_to_direction(&rot);
			Vector3 camPosition = CAM::GET_MISC_CAM_COORD();
			Vector3 playerPosition = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), 1);
			float spawnDistance = MenuFunctions::get_distance(&camPosition, &playerPosition);
			spawnDistance += 5;
			Vector3 spawnPosition = MenuFunctions::add(&camPosition, &MenuFunctions::multiply(&dir, spawnDistance));

			if (bPlayerExists)
			{
				if (PED::IS_PED_SHOOTING(playerPed))
				{
					Vector3 playerOffset = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(playerPed, 0, 5, 0);
					if (PED::IS_PED_ON_FOOT(playerPed))
					{
						STREAMING::REQUEST_MODEL(0x2EA68690);
						while (!STREAMING::HAS_MODEL_LOADED(0x2EA68690)) WAIT(0);
						{
							Vehicle veh = VEHICLE::CREATE_VEHICLE(0x2EA68690, spawnPosition.x, spawnPosition.y, spawnPosition.z, heading, 1, 1);
							VEHICLE::SET_VEHICLE_FORWARD_SPEED(veh, 120.0);
							STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(0x2EA68690);
							ENTITY::SET_VEHICLE_AS_NO_LONGER_NEEDED(&veh);
						}

					}
				}
			}
		}
		if (g_Weapon.teleportgun)
		{
			if (ENTITY::DOES_ENTITY_EXIST(PLAYER::PLAYER_PED_ID()) && PED::IS_PED_SHOOTING_IN_AREA)
			{
				Vector3 mCoord;
				if (WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(PLAYER::PLAYER_PED_ID(), &mCoord))
				{
					ENTITY::SET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), mCoord.x, mCoord.y, mCoord.z + 1, 0, 0, 1, 1);
				}
			}
		}
		if (g_Weapon.deletegun)
		{
			if (ENTITY::DOES_ENTITY_EXIST(PLAYER::PLAYER_PED_ID()) && PED::IS_PED_SHOOTING_IN_AREA)
			{
				Vector3 iCoords;
				if (WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(PLAYER::PLAYER_PED_ID(), &iCoords))
				{
					MISC::_CLEAR_AREA_OF_EVERYTHING(iCoords.x, iCoords.y, iCoords.z, 2, 0, 0, 0, 0);
				}
			}
		}
		if (g_Weapon.airstrikegun)
		{

			int playerPed = 0;
			Vector3 coords;
			if (WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(PLAYER::PLAYER_PED_ID(), &coords))
			{
				Hash airStrike = MISC::GET_HASH_KEY("WEAPON_AIRSTRIKE_ROCKET");
				WEAPON::REQUEST_WEAPON_ASSET(airStrike, 31, false);
				while (!WEAPON::HAS_WEAPON_ASSET_LOADED(airStrike))
					WAIT(0);
				MISC::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(coords.x, coords.y, coords.z + 30.f, coords.x, coords.y, coords.z, 250, 1, airStrike, playerPed, 1, 0, 0xbf800000);
			}
		}
		if (g_Weapon.fireworkammo)
		{
			float startDistance = MenuFunctions::distanceBetween(CAM::GET_MISC_CAM_COORD(), ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true));
			float endDistance = MenuFunctions::distanceBetween(CAM::GET_MISC_CAM_COORD(), ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true));
			startDistance += 0.25;
			endDistance += 1000.0;
			if (PED::IS_PED_ON_FOOT(PLAYER::PLAYER_PED_ID()) && MenuFunctions::is_ped_shooting(PLAYER::PLAYER_PED_ID()))
			{
				Hash weaponAssetRocket = MISC::GET_HASH_KEY("WEAPON_FIREWORK"); //WEAPON_FIREWORK
				if (!WEAPON::HAS_WEAPON_ASSET_LOADED(weaponAssetRocket))
				{
					WEAPON::REQUEST_WEAPON_ASSET(weaponAssetRocket, 31, false);
				}
				MISC::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), startDistance)).x, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), startDistance)).y, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), startDistance)).z, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), endDistance)).x, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), endDistance)).y, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), endDistance)).z, 250, 1, weaponAssetRocket, PLAYER::PLAYER_PED_ID(), 1, 0, -1.0);
			}
		}
		if (g_Weapon.firegun)
		{
			Hash fire = 615608432;
			float startDistance = MenuFunctions::distanceBetween(CAM::GET_MISC_CAM_COORD(), ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true));
			float endDistance = MenuFunctions::distanceBetween(CAM::GET_MISC_CAM_COORD(), ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true));
			startDistance += 0.25;
			endDistance += 1000.0;
			if (PED::IS_PED_ON_FOOT(PLAYER::PLAYER_PED_ID()) && MenuFunctions::is_ped_shooting(PLAYER::PLAYER_PED_ID()))
			{
				if (!WEAPON::HAS_WEAPON_ASSET_LOADED(fire))
				{
					WEAPON::REQUEST_WEAPON_ASSET(fire, 31, false);
				}
				MISC::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), startDistance)).x, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), startDistance)).y, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), startDistance)).z, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), endDistance)).x, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), endDistance)).y, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), endDistance)).z, 250, 1, fire, PLAYER::PLAYER_PED_ID(), 1, 0, -1.0);
			}
		}
		if (g_Weapon.jiaqiandaiqiang)
		{
			if (MenuFunctions::is_ped_shooting(PLAYER::PLAYER_PED_ID()))
			{
				Vector3 pos;
				if (WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(PLAYER::PLAYER_PED_ID(), &pos))
				{
					OBJECT::CREATE_OBJECT(MISC::GET_HASH_KEY("prop_money_bag_01"), pos.x, pos.y, pos.z, true, 1, 0);
				}
			}
		}
		if (g_Weapon.xinxiqiang)
		{
			Entity entity;
			if (PLAYER::GET_ENTITY_PLAYER_IS_FREE_AIMING_AT(PLAYER::PLAYER_ID(), &entity))
			{
				if (ENTITY::IS_ENTITY_AN_OBJECT(entity) || ENTITY::IS_ENTITY_A_PED(entity) || ENTITY::IS_ENTITY_A_VEHICLE(entity))
				{
					Hash hash = ENTITY::GET_ENTITY_MODEL(entity);
					std::ostringstream model_hash;
					model_hash << "ģ�� hash: " << hash;
					MenuFunctions::Notify((char*)model_hash.str().c_str());
				}
			}
		}
		if (g_Weapon.toucheqiang)
		{
			Vector3 pos;
			if (WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(PLAYER::PLAYER_PED_ID(), &pos))
			{
				Vehicle veh = VEHICLE::GET_CLOSEST_VEHICLE(pos.x, pos.y, pos.z, 100.0f, 0, 71);
				PED::SET_PED_INTO_VEHICLE(PLAYER::PLAYER_PED_ID(), veh, -1);
			}
		}
		if (g_Weapon.rocketgun)
		{
			float startDistance = MenuFunctions::distanceBetween(CAM::GET_MISC_CAM_COORD(), ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true));
			float endDistance = MenuFunctions::distanceBetween(CAM::GET_MISC_CAM_COORD(), ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true));
			startDistance += 0.25;
			endDistance += 1000.0;
			if (PED::IS_PED_ON_FOOT(PLAYER::PLAYER_PED_ID()) && MenuFunctions::is_ped_shooting(PLAYER::PLAYER_PED_ID()))
			{
				Hash rocket = 0xA284510B;
				if (!WEAPON::HAS_WEAPON_ASSET_LOADED(rocket))
				{
					WEAPON::REQUEST_WEAPON_ASSET(rocket, 31, false);
				}
				MISC::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), startDistance)).x, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), startDistance)).y, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), startDistance)).z, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), endDistance)).x, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), endDistance)).y, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), endDistance)).z, 250, 1, rocket, PLAYER::PLAYER_PED_ID(), 1, 0, -1.0);
			}
		}
		if (g_Weapon.RPGgun)
		{
			float startDistance = MenuFunctions::distanceBetween(CAM::GET_MISC_CAM_COORD(), ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true));
			float endDistance = MenuFunctions::distanceBetween(CAM::GET_MISC_CAM_COORD(), ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true));
			startDistance += 0.25;
			endDistance += 1000.0;
			if (PED::IS_PED_ON_FOOT(PLAYER::PLAYER_PED_ID()) && MenuFunctions::is_ped_shooting(PLAYER::PLAYER_PED_ID()))
			{
				Hash RPG = 1672152130;
				if (!WEAPON::HAS_WEAPON_ASSET_LOADED(RPG))
				{
					WEAPON::REQUEST_WEAPON_ASSET(RPG, 31, false);
				}
				MISC::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), startDistance)).x, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), startDistance)).y, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), startDistance)).z, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), endDistance)).x, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), endDistance)).y, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), endDistance)).z, 250, 1, RPG, PLAYER::PLAYER_PED_ID(), 1, 0, -1.0);
			}
		}
		if (g_Weapon.grvgun)
		{
			Entity EntityTarget;
			Hash equippedWeapon;
			WEAPON::GET_CURRENT_PED_WEAPON(PLAYER::PLAYER_PED_ID(), &equippedWeapon, 1);
			Player player = PLAYER::PLAYER_ID();
			Ped playerPed = PLAYER::PLAYER_PED_ID();

			Vector3 rot = CAM::GET_MISC_CAM_ROT(0);
			Vector3 dir = MenuFunctions::RotationToDirection(rot);
			Vector3 camPosition = CAM::GET_MISC_CAM_COORD();
			Vector3 playerPosition = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), 1);
			float spawnDistance = MenuFunctions::get_distance(&camPosition, &playerPosition);
			spawnDistance += 6;
			Vector3 spawnPosition = MenuFunctions::add(&camPosition, &MenuFunctions::multiply(&dir, spawnDistance));

			Player tempPed = PLAYER::PLAYER_ID();
			if (PLAYER::GET_ENTITY_PLAYER_IS_FREE_AIMING_AT(PLAYER::PLAYER_ID(), &EntityTarget) && GetAsyncKeyState(VK_RBUTTON))
			{
				Vector3 EntityTargetPos = ENTITY::GET_ENTITY_COORDS(EntityTarget, 0);
				PLAYER::DISABLE_PLAYER_FIRING(tempPed, true);
				if (ENTITY::IS_ENTITY_A_PED(EntityTarget) && PED::IS_PED_IN_ANY_VEHICLE(EntityTarget, 1))
				{
					EntityTarget = PED::GET_VEHICLE_PED_IS_IN(EntityTarget, 0);
				}

				MenuFunctions::requestControlOfEnt(EntityTarget);

				if (ENTITY::IS_ENTITY_A_VEHICLE(EntityTarget))
					ENTITY::SET_ENTITY_HEADING(
						EntityTarget, ENTITY::GET_ENTITY_HEADING(tempPed));

				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(EntityTarget, spawnPosition.x, spawnPosition.y, spawnPosition.z, 0, 0, 0);

				if (GetAsyncKeyState(VK_LBUTTON))
				{
					ENTITY::SET_ENTITY_HEADING(EntityTarget, ENTITY::GET_ENTITY_HEADING(tempPed));
					ENTITY::APPLY_FORCE_TO_ENTITY(EntityTarget, 1, dir.x * 10000.0f, dir.y * 10000.0f, dir.z * 10000.0f, 0.0f, 0.0f, 0.0f, 0, 0, 1, 1, 0, 1);
				}
			}
			if (!PLAYER::GET_ENTITY_PLAYER_IS_FREE_AIMING_AT(PLAYER::PLAYER_ID(), &EntityTarget))
			{
				g_Weapon.grvgun = true;
			}
		}
		if (g_Weapon.smokegun)
		{
			Hash smoke = -1600701090;
			float startDistance = MenuFunctions::distanceBetween(CAM::GET_MISC_CAM_COORD(), ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true));
			float endDistance = MenuFunctions::distanceBetween(CAM::GET_MISC_CAM_COORD(), ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true));
			startDistance += 0.25;
			endDistance += 1000.0;
			if (PED::IS_PED_ON_FOOT(PLAYER::PLAYER_PED_ID()) && MenuFunctions::is_ped_shooting(PLAYER::PLAYER_PED_ID()))
			{
				if (!WEAPON::HAS_WEAPON_ASSET_LOADED(smoke))
				{
					WEAPON::REQUEST_WEAPON_ASSET(smoke, 31, false);
				}
				MISC::SHOOT_SINGLE_BULLET_BETWEEN_COORDS(MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), startDistance)).x, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), startDistance)).y, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), startDistance)).z, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), endDistance)).x, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), endDistance)).y, MenuFunctions::add(&CAM::GET_MISC_CAM_COORD(), &MenuFunctions::multiply(&MenuFunctions::rotDirection(&CAM::GET_MISC_CAM_ROT(0)), endDistance)).z, 250, 1, smoke, PLAYER::PLAYER_PED_ID(), 1, 0, -1.0);
			}
		}
		if (g_Weapon.rainbowgun)
		{
			Ped playerPed = PLAYER::PLAYER_PED_ID();
			static LPCSTR weaponNames[] = {
				"WEAPON_KNIFE", "WEAPON_NIGHTSTICK", "WEAPON_HAMMER", "WEAPON_BAT", "WEAPON_GOLFCLUB", "WEAPON_CROWBAR",
				"WEAPON_PISTOL", "WEAPON_COMBATPISTOL", "WEAPON_APPISTOL", "WEAPON_PISTOL50", "WEAPON_MICROSMG", "WEAPON_SMG",
				"WEAPON_ASSAULTSMG", "WEAPON_ASSAULTRIFLE", "WEAPON_CARBINERIFLE", "WEAPON_ADVANCEDRIFLE", "WEAPON_MG",
				"WEAPON_COMBATMG", "WEAPON_PUMPSHOTGUN", "WEAPON_SAWNOFFSHOTGUN", "WEAPON_ASSAULTSHOTGUN", "WEAPON_BULLPUPSHOTGUN",
				"WEAPON_STUNGUN", "WEAPON_SNIPERRIFLE", "WEAPON_HEAVYSNIPER", "WEAPON_GRENADELAUNCHER", "WEAPON_GRENADELAUNCHER_SMOKE",
				"WEAPON_RPG", "WEAPON_MINIGUN", "WEAPON_GRENADE", "WEAPON_STICKYBOMB", "WEAPON_SMOKEGRENADE", "WEAPON_BZGAS",
				"WEAPON_MOLOTOV", "WEAPON_FIREEXTINGUISHER", "WEAPON_PETROLCAN",
				"WEAPON_SNSPISTOL", "WEAPON_SPECIALCARBINE", "WEAPON_HEAVYPISTOL", "WEAPON_BULLPUPRIFLE", "WEAPON_HOMINGLAUNCHER",
				"WEAPON_PROXMINE", "WEAPON_SNOWBALL", "WEAPON_VINTAGEPISTOL", "WEAPON_DAGGER", "WEAPON_FIREWORK", "WEAPON_MUSKET",
				"WEAPON_MARKSMANRIFLE", "WEAPON_HEAVYSHOTGUN", "WEAPON_GUSENBERG", "WEAPON_HATCHET", "WEAPON_RAILGUN", "WEAPON_FLAREGUN",
				"WEAPON_KNUCKLE", "GADGET_NIGHTVISION", "GADGET_PARACHUTE", "WEAPON_MARKSMANPISTOL", "", ""
			};
			for (int i = 0; i < sizeof(weaponNames) / sizeof(weaponNames[0]); i++)
			{
				if (WEAPON::HAS_PED_GOT_WEAPON(playerPed, MISC::GET_HASH_KEY((char*)weaponNames[i]), 0))
				{
					WEAPON::SET_PED_WEAPON_TINT_INDEX(playerPed, MISC::GET_HASH_KEY((char*)weaponNames[i]), rand() % 8);
				}
			}
		}
		if (g_Weapon.fireshoot)
		{
			Ped PedID = PLAYER::PLAYER_PED_ID();
			Vector3 pos;
			WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(PedID, &pos);
			Ped player = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_PED_ID());
			FIRE::ADD_EXPLOSION(pos.x, pos.y, pos.z, ExplosionTypeFlame, 5.f, true, false, 0.f, 0);
		}
		if (g_Weapon.watershoot)
		{
			Ped PedID = PLAYER::PLAYER_PED_ID();
			Vector3 pos;
			WEAPON::GET_PED_LAST_WEAPON_IMPACT_COORD(PedID, &pos);
			Ped player = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(PLAYER::PLAYER_PED_ID());
			FIRE::ADD_EXPLOSION(pos.x, pos.y, pos.z, 13, 5.f, true, false, 0.f, 0);
		}
		if (g_Weapon.zaijuqiang)
		{
			BOOL bPlayerExists = ENTITY::DOES_ENTITY_EXIST(PLAYER::PLAYER_PED_ID());
			Ped playerPed = PLAYER::PLAYER_PED_ID();
			FLOAT heading = ENTITY::GET_ENTITY_HEADING(playerPed);
			STREAMING::REQUEST_MODEL(0xE644E480);
			Vector3 rot = CAM::GET_MISC_CAM_ROT(0);
			Vector3 dir = MenuFunctions::rot_to_direction(&rot);
			Vector3 camPosition = CAM::GET_MISC_CAM_COORD();
			Vector3 playerPosition = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), 1);
			float spawnDistance = MenuFunctions::get_distance(&camPosition, &playerPosition);
			spawnDistance += 5;
			Vector3 spawnPosition = MenuFunctions::add(&camPosition, &MenuFunctions::multiply(&dir, spawnDistance));

			if (bPlayerExists)
			{
				if (PED::IS_PED_SHOOTING(playerPed))
				{
					Vector3 playerOffset = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(playerPed, 0, 5, 0);
					if (PED::IS_PED_ON_FOOT(playerPed))
					{
						STREAMING::REQUEST_MODEL(0xE644E480);
						while (!STREAMING::HAS_MODEL_LOADED(0xE644E480)) WAIT(0);
						{
							Vehicle veh = VEHICLE::CREATE_VEHICLE(0xE644E480, spawnPosition.x, spawnPosition.y, spawnPosition.z, heading, 1, 1);
							VEHICLE::SET_VEHICLE_FORWARD_SPEED(veh, 120.0);
							STREAMING::SET_MODEL_AS_NO_LONGER_NEEDED(0xE644E480);
							ENTITY::SET_VEHICLE_AS_NO_LONGER_NEEDED(&veh);
						}

					}
				}
			}
		}
		g_Weapon.boxgun ? MenuFunctions::shootobj("prop_mb_sandblock_01") : NULL;
		g_Weapon.Forstingun ? MenuFunctions::shootobj("prop_mp_Forstin_01") : NULL;
		g_Weapon.Forstin2gun ? MenuFunctions::shootobj("prop_mp_Forstin_01b") : NULL;
		g_Weapon.containergun ? MenuFunctions::shootobj("prop_container_01d") : NULL;
		g_Weapon.containergun2 ? MenuFunctions::shootobj("prop_container_03mb") : NULL;
		g_Weapon.containergun3 ? MenuFunctions::shootobj("prop_container_05a") : NULL;
		g_Weapon.lampgun ? MenuFunctions::shootobj("prop_streetlight_04") : NULL;
	}
	void Plistsloop()
	{
		if (g_Plists.spectate)
		{
			NETWORK::NETWORK_SET_IN_SPECTATOR_MODE(true, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
		}
		else
		{
			NETWORK::NETWORK_SET_IN_SPECTATOR_MODE(false, PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer));
		}
		g_Plists.freezeplayer ? BRAIN::CLEAR_PED_TASKS_IMMEDIATELY(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer)) : NULL;
		if (g_Plists.fireloop)
		{
			owned_explossion_bypass(true);
			Player selectPlayer = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer);
			MenuFunctions::ExplosionPlayer(selectPlayer, 5, eExplosionType::ExplosionTypeFlame, 0, false, true);
			owned_explossion_bypass(false);
		}
		if (g_Plists.waterloop)
		{
			owned_explossion_bypass(true);
			Player selectPlayer = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer);
			MenuFunctions::ExplosionPlayer(selectPlayer, 5, eExplosionType::ExplosionTypeWaterHydrant, 0, false, true);
			owned_explossion_bypass(false);
		}
		if (g_Plists.explosionloop)
		{
			owned_explossion_bypass(true);
			Player selectPlayer = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer);
			MenuFunctions::ExplosionPlayer(selectPlayer, 65535, eExplosionType::ExplosionTypeGrenadeL, 2, false, true);
			owned_explossion_bypass(false);
		}
		if (g_Plists.FPSdrop)
		{
			model_spawn_bypass(true);
			//model_check_bypass(true);
			Hash Scrap = -2130482718;
			Hash TowTruck = -1323100960;
			if (MenuFunctions::checkModel(Scrap)) {
				Vector3 coords = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), 0, 0, 13);
				VEHICLE::CREATE_VEHICLE(Scrap, coords.x, coords.y, coords.z, ENTITY::GET_ENTITY_HEADING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer)), true, true);
			}
			if (MenuFunctions::checkModel(TowTruck)) {
				Vector3 coords = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer), 0, 0, 13);
				VEHICLE::CREATE_VEHICLE(TowTruck, coords.x, coords.y, coords.z, ENTITY::GET_ENTITY_HEADING(PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(Online::g_SelectedPlayer)), true, true);
			}
			model_spawn_bypass(false);
			//model_check_bypass(false);
		}
	}
	void Sessionloop()
	{
		if (g_Session.blockobjCrash)
		{
			BlockObjectCrash(true);
		}
		if (g_Session.blockPedCrash)
		{
			BlockPedCrash(true);
		}
		if (g_Session.blockvehCrash)
		{
			BlockVehicleCrash(true);
		}
		if (g_Session.blockallentity)
		{
			BlockAllEntity(true);
		}
		if (g_Session.antiattachment)
		{
			AntiAttachment(true);
		}
		if (g_Session.anticage)
		{
			AntiCage(true);
		}
		if (g_Session.anticeokick)
		{
			AntiCeoKick(true);
		}
		if (g_Session.antiapartmenttp)
		{
			AntiApartmentTP(true);
		}
		if (g_Session.antidrop)
		{
			AntiDrop(true);
		}
		if (g_Session.antiexplosion)
		{
			AntiExplosion(true);
		}
		if (g_Session.antifire)
		{
			AntiFire(true);
		}
		if (g_Session.antifreeze)
		{
			AntiFreeze(true);
		}
		if (g_Session.antigiveweapon)
		{
			AntiGiveWeapon(true);
		}
		if (g_Session.antiinvite)
		{
			AntiInvite(true);
			NETWORK::NETWORK_BLOCK_INVITES(true);
		}
		if (g_Session.antikick)
		{
			AntiKick(true);
		}
		if (g_Session.antiPTFX)
		{
			AntiPTFX(true);
		}
		if (g_Session.antiremotebounty)
		{
			AntiRemoteBounty(true);
		}
		if (g_Session.antiremoteforcemission)
		{
			antiRemoteForceMission(true);
		}
		if (g_Session.antiremotevehkick)
		{
			antiRemoteVehicleKick(true);
		}
		if (g_Session.antiremoveweapon)
		{
			AntiRemoveWeapon(true);
		}
		if (g_Session.antireport)
		{
			AntiReport(true);
		}
		if (g_Session.antirequsetcontrol)
		{
			AntiRequestControl(true);
		}
		if (g_Session.antiSPKick)
		{
			AntiSPKick(true);
		}
		if (g_Session.antistar)
		{
			AntiStars(true);
		}
		if (g_Session.antistat)
		{
			AntiStat(true);
		}
		if (g_Session.antivotekick)
		{
			AntiVoteKick(true);
		}
		if (g_Session.zhengfa)
		{
			globalHandle(2657589 + 1 + PLAYER::PLAYER_ID() * 466 + 213).As<int>() = 1;
			globalHandle(2672505).At(58).As<int>() = NETWORK::GET_NETWORK_TIME() + 10;
		}
		else
		{
			globalHandle(2657589 + 1 + PLAYER::PLAYER_ID() * 466 + 213).As<int>() = 0;
			globalHandle(2672505).At(58).As<int>() = 0;
		}
		if (g_Session.frashrun)
		{
			Vector3 cooords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), 0);
			GRAPHICS::DRAW_LIGHT_WITH_RANGE(cooords.x, cooords.y, cooords.z, MISC::GET_RANDOM_INT_IN_RANGE(0, 255), MISC::GET_RANDOM_INT_IN_RANGE(0, 255), MISC::GET_RANDOM_INT_IN_RANGE(0, 255), 25.0f, 100.0f);
		}
		if (g_Session.siwangshexian)
		{
			const int numElements1 = 10;
			const int arrSize = numElements1 * 2 + 2;
			Ped ped[arrSize];
			ped[0] = numElements1;
			int count = PED::GET_PED_NEARBY_PEDS(PLAYER::PLAYER_PED_ID(), ped, 1);
			if (ped != NULL)
			{
				for (int i = 1; i <= count; i++)
				{
					int offsettedID = i;
					Vector3 Pos = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
					Vector3 Pos2 = ENTITY::GET_ENTITY_COORDS(ped[offsettedID], true);
					GRAPHICS::DRAW_LINE(Pos.x, Pos.y, Pos.z, Pos2.x, Pos2.y, Pos2.z, 133, 8, 255, 255);
					FIRE::ADD_EXPLOSION(Pos2.x, Pos2.y, Pos2.z, 2, 5, 1, 0, 0, 0);
				}
			}
		}
		if (g_Session.elingqishi)
		{
			g_Local.GodMode = true;
			MenuFunctions::ghost_rider_player();
			MenuFunctions::ghost_rider_vehicle();
		}
		if (g_Session.ESPname)
		{
			Player playerPed = PLAYER::PLAYER_PED_ID();
			for (int i = 0; i < 32; i++)
			{
				Player playerHandle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
				Vector3 handleCoords = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(playerHandle, 0, 0, 0);
				Vector3 playerCoords = ENTITY::GET_ENTITY_COORDS(playerPed, 0);
				const char* Name = PLAYER::GET_PLAYER_NAME(PLAYER::INT_TO_PLAYERINDEX(i));

				if (ENTITY::DOES_ENTITY_EXIST(playerHandle))
				{
					float x1;
					float y1;

					BOOL screenCoords = GRAPHICS::GET_SCREEN_COORD_FROM_WORLD_COORD(handleCoords.x, handleCoords.y, handleCoords.z, &x1, &y1);

					std::string playerName = PLAYER::GET_PLAYER_NAME(PLAYER::INT_TO_PLAYERINDEX(i));

					std::string nameSetupRed = "~HUD_COLOUR_RED~" + playerName;
					std::string nameSetupGreen = "~HUD_COLOUR_BLUE~" + playerName;

					char* playerInfoRed = new char[nameSetupRed.length() + 1];
					char* playerInfoGreen = new char[nameSetupGreen.length() + 1];

					std::strcpy(playerInfoRed, nameSetupRed.c_str());
					std::strcpy(playerInfoGreen, nameSetupGreen.c_str());

					HUD::SET_TEXT_FONT(7);
					HUD::SET_TEXT_SCALE(0.0, 0.40);
					HUD::SET_TEXT_COLOUR(0, 255, 0, 255);
					HUD::SET_TEXT_CENTRE(0);
					HUD::SET_TEXT_DROPSHADOW(0, 0, 0, 0, 0);
					HUD::SET_TEXT_EDGE(0, 0, 0, 0, 0);
					HUD::BEGIN_TEXT_COMMAND_DISPLAY_TEXT((char*)"STRING");
					if (ENTITY::HAS_ENTITY_CLEAR_LOS_TO_ENTITY(playerPed, playerHandle, 17))
					{
						HUD::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(playerInfoGreen);
					}
					else
					{
						HUD::ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(playerInfoRed);
					}
					HUD::END_TEXT_COMMAND_DISPLAY_TEXT(x1, y1, 0);
					HUD::SET_TEXT_OUTLINE();
					HUD::SET_TEXT_DROPSHADOW(5, 0, 78, 255, 255);
				}
			}
		}
		if (g_Session.espbox)
		{
			Player playerPed = PLAYER::PLAYER_PED_ID();
			for (int i = 0; i < 32; i++)
			{
				Player playerHandle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
				Vector3 handleCoords = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(playerHandle, 0, 0, 0);
				const char* Name = PLAYER::GET_PLAYER_NAME(PLAYER::INT_TO_PLAYERINDEX(i));

				if (ENTITY::DOES_ENTITY_EXIST(playerHandle))
				{
					GRAPHICS::DRAW_LINE(handleCoords.x + 0.5, handleCoords.y + 0.5, handleCoords.z + 0.75, handleCoords.x + 0.5, handleCoords.y - 0.5, handleCoords.z + 0.75, 80, 200, 80, 255); // top Box
					GRAPHICS::DRAW_LINE(handleCoords.x + 0.5, handleCoords.y - 0.5, handleCoords.z + 0.75, handleCoords.x - 0.5, handleCoords.y - 0.5, handleCoords.z + 0.75, 80, 200, 80, 255);
					GRAPHICS::DRAW_LINE(handleCoords.x - 0.5, handleCoords.y - 0.5, handleCoords.z + 0.75, handleCoords.x - 0.5, handleCoords.y + 0.5, handleCoords.z + 0.75, 80, 200, 80, 255);
					GRAPHICS::DRAW_LINE(handleCoords.x - 0.5, handleCoords.y + 0.5, handleCoords.z + 0.75, handleCoords.x + 0.5, handleCoords.y + 0.5, handleCoords.z + 0.75, 80, 200, 80, 255);

					GRAPHICS::DRAW_LINE(handleCoords.x + 0.5, handleCoords.y + 0.5, handleCoords.z - 0.75, handleCoords.x + 0.5, handleCoords.y - 0.5, handleCoords.z - 0.75, 80, 200, 80, 255); // bottom Box
					GRAPHICS::DRAW_LINE(handleCoords.x + 0.5, handleCoords.y - 0.5, handleCoords.z - 0.75, handleCoords.x - 0.5, handleCoords.y - 0.5, handleCoords.z - 0.75, 80, 200, 80, 255);
					GRAPHICS::DRAW_LINE(handleCoords.x - 0.5, handleCoords.y - 0.5, handleCoords.z - 0.75, handleCoords.x - 0.5, handleCoords.y + 0.5, handleCoords.z - 0.75, 80, 200, 80, 255);
					GRAPHICS::DRAW_LINE(handleCoords.x - 0.5, handleCoords.y + 0.5, handleCoords.z - 0.75, handleCoords.x + 0.5, handleCoords.y + 0.5, handleCoords.z - 0.75, 80, 200, 80, 255);

					GRAPHICS::DRAW_LINE(handleCoords.x + 0.5, handleCoords.y + 0.5, handleCoords.z - 0.75, handleCoords.x + 0.5, handleCoords.y + 0.5, handleCoords.z + 0.75, 80, 200, 80, 255); // bottom Box
					GRAPHICS::DRAW_LINE(handleCoords.x + 0.5, handleCoords.y - 0.5, handleCoords.z - 0.75, handleCoords.x + 0.5, handleCoords.y - 0.5, handleCoords.z + 0.75, 80, 200, 80, 255);
					GRAPHICS::DRAW_LINE(handleCoords.x - 0.5, handleCoords.y - 0.5, handleCoords.z - 0.75, handleCoords.x - 0.5, handleCoords.y - 0.5, handleCoords.z + 0.75, 80, 200, 80, 255);
					GRAPHICS::DRAW_LINE(handleCoords.x - 0.5, handleCoords.y + 0.5, handleCoords.z - 0.75, handleCoords.x - 0.5, handleCoords.y + 0.5, handleCoords.z + 0.75, 80, 200, 80, 255);
				}
			}
		}
		if (g_Session.espline)
		{
			Player playerPed = PLAYER::PLAYER_PED_ID();
			for (int i = 0; i < 32; i++)
			{
				Player playerHandle = PLAYER::GET_PLAYER_PED_SCRIPT_INDEX(i);
				Vector3 handleCoords = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(playerHandle, 0, 0, 0);
				Vector3 locationOne = ENTITY::GET_ENTITY_COORDS(playerHandle, false);
				Vector3 locationTwo = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), false);
				GRAPHICS::DRAW_LINE(locationOne.x, locationOne.y, locationOne.z, locationTwo.x, locationTwo.y, locationTwo.z, 255, 0, 0, 255);
			}
		}
		if (g_Session.afk)
		{
			if (globalHandle(1653913).At(1156).As<int>() != -1)
				globalHandle(1653913).At(1156).As<int>() = -1;
			if (globalHandle(1653913).At(1172).As<int>() != -1)
				globalHandle(1653913).At(1172).As<int>() = -1;
		}
		if (g_Session.luodi)
		{
			if (GetAsyncKeyState(gui.selectKey))
			{
				SCRIPT::SHUTDOWN_LOADING_SCREEN();
			}
		}
		if (g_Session.qingqiujiaru)
		{
			NETWORK::NETWORK_SESSION_BLOCK_JOIN_REQUESTS(g_Session.qingqiujiaru);
			NETWORK::NETWORK_SESSION_CANCEL_INVITE();
		}
	}
	void WorldLoop()
	{
		if (g_World.gravity)
		{
			MISC::SET_GRAVITY_LEVEL(3);
		}
		else
		{
			MISC::SET_GRAVITY_LEVEL(0);
		}
		if (g_World.explodnearcar)
		{
			const int ElementAmount = 10;
			const int ArrSize = ElementAmount * 2 + 2;

			Vehicle* vehs = new Vehicle[ArrSize];
			vehs[0] = ElementAmount;
			int VehFound = PED::GET_PED_NEARBY_VEHICLES(PLAYER::PLAYER_PED_ID(), vehs);

			for (int i = 0; i < VehFound; i++)
			{
				int OffsetID = i * 2 + 2;
				if (vehs[OffsetID] != PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false))
				{
					MenuFunctions::requestControlOfEnt(vehs[OffsetID]);
					Vector3 coords = ENTITY::GET_ENTITY_COORDS(vehs[OffsetID], false);
					FIRE::ADD_EXPLOSION(coords.x, coords.y, coords.z, 0, 1000.f, true, false, 0.f, 0);
				}
			}
			delete vehs;
		}
		if (g_World.boostnearcar)
		{
			const int ElementAmount = 10;
			const int ArrSize = ElementAmount * 2 + 2;
			Vehicle* vehs = new Vehicle[ArrSize];
			vehs[0] = ElementAmount;
			int VehFound = PED::GET_PED_NEARBY_VEHICLES(PLAYER::PLAYER_PED_ID(), vehs);
			for (int i = 0; i < VehFound; i++)
			{
				int OffsetID = i * 2 + 2;
				if (vehs[OffsetID] != PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false))
				{
					//RequestControlOfEntity(vehs[OffsetID]);
					ENTITY::APPLY_FORCE_TO_ENTITY(vehs[OffsetID], 1, 0, 200, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1);
				}
			}
			delete vehs;
		}
		if (g_World.deletenearcar)
		{
			const int ElementAmount = 10;
			const int ArrSize = ElementAmount * 2 + 2;
			Vehicle* vehs = new Vehicle[ArrSize];
			vehs[0] = ElementAmount;
			int VehFound = PED::GET_PED_NEARBY_VEHICLES(PLAYER::PLAYER_PED_ID(), vehs);
			for (int i = 0; i < VehFound; i++)
			{
				int OffsetID = i * 2 + 2;
				if (vehs[OffsetID] != PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), false))
				{
					ENTITY::SET_ENTITY_COORDS(vehs[OffsetID], 6400.f, 6400.f, 0.f, false, false, false, false);
				}
			}
			delete vehs;
		}
		if (g_World.explodnearped)
		{
			const int ElementAmount = 10;
			const int ArrSize = ElementAmount * 2 + 2;

			Ped* peds = new Ped[ArrSize];
			peds[0] = ElementAmount;

			int PedFound = PED::GET_PED_NEARBY_PEDS(PLAYER::PLAYER_PED_ID(), peds, -1);

			for (int i = 0; i < PedFound; i++)
			{
				int OffsetID = i * 2 + 2;
				MenuFunctions::RequestNetworkControlOfEntity(peds[OffsetID]);
				if (ENTITY::DOES_ENTITY_EXIST(peds[OffsetID]) && PLAYER::PLAYER_PED_ID() != peds[OffsetID])
				{
					Vector3 pos = ENTITY::GET_ENTITY_COORDS(peds[OffsetID], false);
					FIRE::ADD_EXPLOSION(pos.x, pos.y, pos.z, 0, 1000.f, true, false, 0.f, false);
				}
			}
		}
		if (g_World.killpeds)
		{
			const int ElementAmount = 10;
			const int ArrSize = ElementAmount * 2 + 2;

			Ped* peds = new Ped[ArrSize];
			peds[0] = ElementAmount;

			int PedFound = PED::GET_PED_NEARBY_PEDS(PLAYER::PLAYER_PED_ID(), peds, -1);

			for (int i = 0; i < PedFound; i++)
			{
				int OffsetID = i * 2 + 2;
				MenuFunctions::RequestNetworkControlOfEntity(peds[OffsetID]);
				if (ENTITY::DOES_ENTITY_EXIST(peds[OffsetID]) && PLAYER::PLAYER_PED_ID() != peds[OffsetID])
				{
					PED::APPLY_DAMAGE_TO_PED(peds[OffsetID], 1000, false);
				}
			}
		}
		if (g_World.deleteNPC)
		{
			const int ElementAmount = 10;
			const int ArrSize = ElementAmount * 2 + 2;
			Ped* peds = new Ped[ArrSize];
			peds[0] = ElementAmount;
			int PedFound = PED::GET_PED_NEARBY_PEDS(PLAYER::PLAYER_PED_ID(), peds, -1);
			for (int i = 0; i < PedFound; i++)
			{
				int OffsetID = i * 2 + 2;
				MenuFunctions::RequestNetworkControlOfEntity(peds[OffsetID]);
				if (ENTITY::DOES_ENTITY_EXIST(peds[OffsetID]) && PLAYER::PLAYER_PED_ID() != peds[OffsetID])
				{
					ENTITY::SET_ENTITY_COORDS(peds[OffsetID], 6400.f, 6400.f, 0.f, false, false, false, false);
				}
			}
			delete peds;
		}
	}
	void MiscLoop()
	{
		HUD::SET_RADAR_ZOOM(g_Misc.ditudaxiao);
		if (g_Misc.disablephone)
			MOBILE::DESTROY_MOBILE_PHONE();
		if (g_Misc.aimcross)
		{
			MenuFunctions::setupdraw(1);
			HUD::SET_TEXT_FONT(6);
			HUD::SET_TEXT_SCALE(0.5f, 0.5f);
			HUD::SET_TEXT_COLOUR(255, 255, 255, 255);
			HUD::SET_TEXT_CENTRE(1);
			MenuFunctions::drawstring("+", 0.5f, 0.48f);
		}
		if (g_Misc.displaycoord)
		{
			Vector3 coords = ENTITY::GET_ENTITY_COORDS(PLAYER::PLAYER_PED_ID(), true);
			char out[32];
			sprintf(out,u8"X��: %d Y��: %d Z��: %d", (int)coords.x + 1200, (int)coords.y, (int)coords.z);
			Menu::draw.Text(out, { 255, 255, 255, 255 }, { 0.50f, 0.90f }, { 0.36f, 0.36f }, true);
		}
		if (g_Misc.displayfps)
		{
			static int		iFrames = 0;
			static clock_t	clockFrames = clock();
			static float	iFps;
			iFrames++;
			clock_t dif = clock() - clockFrames;
			if (dif > 500)
			{
				iFps = iFrames / (dif / 1000.f);
				iFrames = 0;
				clockFrames = clock();
			}

			std::string str = std::to_string(iFps);
			while (str.size() > str.find(".")) { str.pop_back(); }
			std::string MessageString = "FPS: " + str;
			gui.FPS(MessageString, { 255, 255, 255, 255 }, { 0.50f, 0.002f }, { 0.30f, 0.30f }, false, false);
		}
		if (g_Misc.SpeedoBool)
		{
			if (PED::IS_PED_IN_ANY_VEHICLE(PLAYER::PLAYER_PED_ID(), 0))
			{
				float speed = ENTITY::GET_ENTITY_SPEED(PED::GET_VEHICLE_PED_IS_USING(PLAYER::PLAYER_PED_ID())) * 3.6f;

				if (g_Misc.SpeedoBool)
					speed = speed * .621f;
				char msg[0xFF];
				if (g_Misc.SpeedoBool)
				{
					sprintf_s(msg, StringToChar((std::string)"%i" + (std::string)"KM/H"), (int)speed);
				}
				else
				{
					sprintf_s(msg, StringToChar((std::string)"%i" + (std::string)"KM/H"), (int)speed);
				}
				MenuFunctions::drawstring(msg, .80f, .80f);
			}
		}
		if (g_Misc.hidehud)
		{
			HUD::HIDE_HUD_AND_RADAR_THIS_FRAME();
		}
	}
	void RecoveryLoop()
	{
		if (g_Recovery.tianjipaotuikuan)
		{
			globalHandle(1968313).As<int>() = 2;
		}
		if (g_Recovery.xunhuanshua)
		{
			if (GetTickCount64() - TimePD < 50000) return;
			globalHandle(1968313).As<int>() = 1;  //дֵΪ1  ��Ϊ50w //дֵΪ3  ��Ϊ75w  
			WAIT(20);
			globalHandle(1968313).As<int>() = 0;

			TimePD = GetTickCount64();
		}
		if (g_Recovery.qiwuxunhuanshua)
		{
			if (GetTickCount64() - TimePD < 50000) return;
			globalHandle(1968313).As<int>() = 3;  //дֵΪ1  ��Ϊ50w //дֵΪ3  ��Ϊ75w  
			WAIT(20);
			globalHandle(1968313).As<int>() = 0;

			TimePD = GetTickCount64();
		}
		if (g_Recovery.jiechulaohuji)
		{
			if (GetTickCount64() - TimePD < 500) return;
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MPPLY_CASINO_CHIPS_WON_GD"), 0, true);
			TimePD = GetTickCount64();
		}
	}
	void TaskLoop()
	{
		if (g_Task.gaichepushouru)
		{
			globalHandle(262145).At(31249).As<int>() = 1000000;
			globalHandle(262145).At(31249).At(1).As<int>() = 1000000;
			globalHandle(262145).At(31249).At(2).As<int>() = 1000000;
			globalHandle(262145).At(31249).At(3).As<int>() = 1000000;
			globalHandle(262145).At(31249).At(4).As<int>() = 1000000;
			globalHandle(262145).At(31249).At(5).As<int>() = 1000000;
			globalHandle(262145).At(31249).At(6).As<int>() = 1000000;
			globalHandle(262145).At(31249).At(7).As<int>() = 1000000;
			globalHandle(262145).At(31038).As<int>() = 0;
		}
		if (g_Task.quanfushouru)
		{
			globalHandle(1937658).At(3008).At(1).As<int>() = 5961;
		}
		if (g_Task.quanfuzhiwensuo)
		{
			script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 11757 + 24, 7);
		}
		if (g_Task.quanfuzuankong)
		{
			script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 10058 + 11, 100);
		}
		if (g_Task.tpyshouru)
		{
			script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 19707 + 2686, 1850000);
		}
		if (g_Task.tpyzhiwensuo)
		{
			script_local::script_local(script_local::GetLocalScript("FM_Mission_Controller"), 9764, 9);
		}
		if (g_Task.fenhongbaifenbi)
		{
			globalHandle(262145).At(9084).As<int>() = 100;
			globalHandle(262145).At(9186).As<int>() = 0;
			globalHandle(262145).At(9187).As<int>() = 0;
		}
		if (g_Task.swscisha)
		{
			globalHandle(262145).At(31701).As<int>() = 0;
			globalHandle(262145).At(31701).As<int>() = 0;
		}
		else
		{
			globalHandle(262145).At(31701).As<int>() = 300000;
			globalHandle(262145).At(31701).As<int>() = 500;
		}
		if (g_Task.swsanbao)
		{
			globalHandle(262145).At(31781).As<int>() = 0;
		}
		else
		{
			globalHandle(262145).At(31781).As<int>() = 1200000;
		}
		if (g_Task.swsshouru)
		{
			globalHandle(262145).At(31747).As<int>() = 2000000;
		}
	}
	void UnlockLoop()
	{
		if (g_Unlock.shengdanjie)
		{
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_DISABLE_SNOWBALLS"), 9393, true);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_ENABLE_CLEAR_STRUCT_ON_TRAN_FAIL"), 9400, true);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_MAX_NUMBER_OF_SNOWBALLS"), 9401, true);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_PICK_UP_NUMBER_OF_SNOWBALLS"), 9402, true);

			STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_DISABLE_SNOWBALLS"), 9393, true);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_ENABLE_CLEAR_STRUCT_ON_TRAN_FAIL"), 9400, true);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_MAX_NUMBER_OF_SNOWBALLS"), 9401, true);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_PICK_UP_NUMBER_OF_SNOWBALLS"), 9402, true);
		}
		if (g_Unlock.duliri)
		{
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_INDEPENDENCE_DAY_DEACTIVATE_FIREWORKS_LAUNCHER"), 8268, true);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_TOGGLE_ACTIVATE_MONSTER_TRUCK"), 8274, true);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_UNLOCKINDEPENDENCE_BEER_HAT_1"), 8297, true);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP0_UNLOCKINDEPENDENCE_STATUE_HAPPINESS_SHIRT"), 8303, true);

			STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_INDEPENDENCE_DAY_DEACTIVATE_FIREWORKS_LAUNCHER"), 8268, true);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_TOGGLE_ACTIVATE_MONSTER_TRUCK"), 8274, true);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_UNLOCKINDEPENDENCE_BEER_HAT_1"), 8297, true);
			STATS::STAT_SET_INT(MISC::GET_HASH_KEY((char*)"MP1_UNLOCKINDEPENDENCE_STATUE_HAPPINESS_SHIRT"), 8303, true);

			globalHandle(262145).At(8259).As<int>() = 1;
		}
	}
	void SettingsLoop()
	{
		if (g_Settings.endxiezai)
		{
			if (GetAsyncKeyState(VK_END)) { g_running = false; }
		}
		if (g_Settings.delzisha)
		{
			if (GetAsyncKeyState(VK_DELETE)) { ENTITY::SET_ENTITY_HEALTH(PLAYER::PLAYER_PED_ID(), 0); }
		}
		if (g_Settings.chuansongdaohangdian)
		{
			if (GetAsyncKeyState(VK_F5))
			{
				if (HUD::DOES_BLIP_EXIST(HUD::GET_FIRST_BLIP_INFO_ID(8)))
				{
					Vector3 coords = MenuFunctions::get_blip_marker();
					Entity e = PLAYER::PLAYER_PED_ID();
					if (PED::IS_PED_IN_ANY_VEHICLE(e, 0))
					{
						e = PED::GET_VEHICLE_PED_IS_USING(e);
					}
					bool groundFound = false;
					static float groundCheckHeight[] =
					{ 100.0, 150.0, 50.0, 0.0, 200.0, 250.0, 300.0, 350.0, 400.0, 450.0, 500.0, 550.0, 600.0, 650.0, 700.0, 750.0, 800.0 };
					for (int i = 0; i < sizeof(groundCheckHeight) / sizeof(float); i++)
					{
						ENTITY::SET_ENTITY_COORDS_NO_OFFSET(e, coords.x, coords.y, groundCheckHeight[i], 0, 0, 1);
						WAIT(100);
						if (MISC::GET_GROUND_Z_FOR_3D_COORD(coords.x, coords.y, groundCheckHeight[i], &coords.z, 0))
						{
							groundFound = true;
							coords.z += 3.0;
							break;
						}
					}
					if (!groundFound)
					{
						coords.z = 1000.0;
						WEAPON::GIVE_DELAYED_WEAPON_TO_PED(PLAYER::PLAYER_PED_ID(), 0xFBAB5776, 1, 0);
					}
					MenuFunctions::teleport_to_coords(e, coords);
				}
				else
					MenuFunctions::Notify((char*)"δ�ҵ���ǵ�");
			}
		}
		if (g_Settings.chuansongmubiaodian)
		{
			if (GetAsyncKeyState(VK_F5))
				MenuFunctions::teleportToObjective();
		}
		if (g_Settings.chuansongdaohujing)
		{
			if (GetAsyncKeyState(VK_F6))
			{
				Vector3 Coords;
				Coords.x = 1561.2369; Coords.y = 385.8771; Coords.z = -49.689915;
				MenuFunctions::ChangeCoords(Coords);
				STATS::STAT_SET_INT(MISC::GET_HASH_KEY("H4_PROGRESS"), 131055, true);
			}
		}
		if (g_Settings.xiangqianchuansong)
		{
			if (GetAsyncKeyState(VK_F3))
			{
				Vector3 Coords = ENTITY::GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(PLAYER::PLAYER_PED_ID(), 0.0, 3.0, 0.0);
				int player = PLAYER::PLAYER_PED_ID();
				if (PED::IS_PED_IN_ANY_VEHICLE(player, 0))
					player = PED::GET_VEHICLE_PED_IS_IN(PLAYER::PLAYER_PED_ID(), 0);
				ENTITY::SET_ENTITY_COORDS_NO_OFFSET(player, Coords.x, Coords.y, Coords.z, 0, 0, 1);
			}
		}
	}
}